<?php
/**
 * Script de instalación automatizada para Charolais Store
 * Este script configura la aplicación automáticamente
 */

// Verificar si ya está instalado
if (file_exists('includes/config.php') && !isset($_GET['force'])) {
    die('La aplicación ya está instalada. Agrega ?force=1 para forzar la reinstalación.');
}

$step = $_GET['step'] ?? 1;
$errors = [];
$success = [];

// Procesar formulario de configuración
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'] ?? '';
    $db_name = $_POST['db_name'] ?? '';
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';
    $app_url = $_POST['app_url'] ?? '';
    $stripe_pk = $_POST['stripe_pk'] ?? '';
    $stripe_sk = $_POST['stripe_sk'] ?? '';
    $admin_user = $_POST['admin_user'] ?? '';
    $admin_pass = $_POST['admin_pass'] ?? '';
    $admin_email = $_POST['admin_email'] ?? '';
    
    // Validar datos
    if (empty($db_host) || empty($db_name) || empty($db_user)) {
        $errors[] = 'Todos los campos de base de datos son requeridos';
    }
    
    if (empty($app_url)) {
        $errors[] = 'La URL de la aplicación es requerida';
    }
    
    if (empty($admin_user) || empty($admin_pass) || empty($admin_email)) {
        $errors[] = 'Los datos del administrador son requeridos';
    }
    
    if (strlen($admin_pass) < 8) {
        $errors[] = 'La contraseña del administrador debe tener al menos 8 caracteres';
    }
    
    // Si no hay errores, proceder con la instalación
    if (empty($errors)) {
        try {
            // Probar conexión a base de datos
            $pdo = new PDO("mysql:host=$db_host;charset=utf8mb4", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Crear base de datos si no existe
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db_name`");
            
            // Crear estructura de tablas
            createTables($pdo);
            
            // Crear archivo de configuración
            createConfigFile($db_host, $db_name, $db_user, $db_pass, $app_url, $stripe_pk, $stripe_sk);
            
            // Crear administrador
            createAdmin($pdo, $admin_user, $admin_pass, $admin_email);
            
            // Crear directorios necesarios
            createDirectories();
            
            // Instalar dependencias
            installDependencies();
            
            $success[] = 'Instalación completada exitosamente';
            $step = 3;
            
        } catch (Exception $e) {
            $errors[] = 'Error durante la instalación: ' . $e->getMessage();
        }
    }
}

function createTables($pdo) {
    $tables = [
        // Tabla de administradores
        "CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            email VARCHAR(100),
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de categorías
        "CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de productos
        "CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            category_id INT,
            stock_quantity INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            rating DECIMAL(3,2) DEFAULT 0,
            reviews_count INT DEFAULT 0,
            sort_order INT DEFAULT 0,
            stripe_price_id VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
        )",
        
        // Tabla de imágenes de productos
        "CREATE TABLE IF NOT EXISTS product_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        )",
        
        // Tabla de variantes de productos
        "CREATE TABLE IF NOT EXISTS product_variants (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            variant_name VARCHAR(100) NOT NULL,
            sku VARCHAR(100),
            price_override DECIMAL(10,2),
            stock_quantity INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        )",
        
        // Tabla de imágenes de variantes
        "CREATE TABLE IF NOT EXISTS variant_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            variant_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE
        )",
        
        // Tabla de órdenes
        "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            stripe_session_id VARCHAR(255),
            customer_email VARCHAR(100),
            customer_name VARCHAR(100),
            total_amount DECIMAL(10,2) NOT NULL,
            shipping_amount DECIMAL(10,2) DEFAULT 0,
            status ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
            shipping_address TEXT,
            billing_address TEXT,
            is_first_purchase BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de items de órdenes
        "CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            product_id INT,
            variant_id INT,
            product_name VARCHAR(200) NOT NULL,
            variant_name VARCHAR(100),
            quantity INT NOT NULL,
            unit_price DECIMAL(10,2) NOT NULL,
            total_price DECIMAL(10,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE SET NULL
        )",
        
        // Tabla de configuraciones del sistema
        "CREATE TABLE IF NOT EXISTS system_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) UNIQUE NOT NULL,
            setting_value TEXT,
            description VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de logs de actividad
        "CREATE TABLE IF NOT EXISTS activity_logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            action VARCHAR(100) NOT NULL,
            details TEXT,
            user_id INT,
            ip_address VARCHAR(45),
            user_agent TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )"
    ];
    
    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }
}

function createConfigFile($db_host, $db_name, $db_user, $db_pass, $app_url, $stripe_pk, $stripe_sk) {
    $config_content = "<?php
/**
 * Configuración principal de Charolais Store
 * Generado automáticamente por el instalador
 */

// Configuración de la aplicación
define('APP_NAME', 'Charolais Store');
define('APP_VERSION', '1.0.0');
define('APP_URL', '$app_url');

// Configuración de base de datos MySQL
define('DB_HOST', '$db_host');
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASS', '$db_pass');
define('DB_CHARSET', 'utf8mb4');

// Configuración de Stripe
define('STRIPE_PUBLISHABLE_KEY', '$stripe_pk');
define('STRIPE_SECRET_KEY', '$stripe_sk');
define('STRIPE_WEBHOOK_SECRET', '');

// Configuración de sesiones
define('SESSION_NAME', 'charolais_session');
define('SESSION_LIFETIME', 86400);
define('SESSION_SECURE', true);
define('SESSION_HTTP_ONLY', true);

// Configuración de archivos
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024);
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// Configuración de envío
define('FREE_SHIPPING_FIRST_PURCHASE', true);
define('STANDARD_SHIPPING_COST', 150);
define('STANDARD_SHIPPING_PERCENTAGE', 0.10);

// Configuración de seguridad
define('CSRF_TOKEN_NAME', 'charolais_csrf');
define('PASSWORD_MIN_LENGTH', 8);
define('LOGIN_MAX_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900);

// Configuración de errores
define('DISPLAY_ERRORS', false);
define('LOG_ERRORS', true);
define('ERROR_LOG_FILE', __DIR__ . '/../logs/error.log');

// Configuración de timezone
date_default_timezone_set('America/Mexico_City');

// Configuración de idioma
setlocale(LC_ALL, 'es_MX.UTF-8');

// Configuración de memoria
ini_set('memory_limit', '256M');
ini_set('max_execution_time', 300);

// Configuración de sesiones
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', SESSION_SECURE ? 1 : 0);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);

// Configuración de errores
if (DISPLAY_ERRORS) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

if (LOG_ERRORS) {
    ini_set('log_errors', 1);
    ini_set('error_log', ERROR_LOG_FILE);
}

// Crear directorio de logs si no existe
\$log_dir = dirname(ERROR_LOG_FILE);
if (!is_dir(\$log_dir)) {
    mkdir(\$log_dir, 0755, true);
}

// Crear directorio de uploads si no existe
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

// Configuración de headers de seguridad
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Configuración de CORS
header('Access-Control-Allow-Origin: ' . APP_URL);
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Función para obtener configuración del sistema
function getSystemSetting(\$key, \$default = null) {
    global \$pdo;
    
    try {
        \$stmt = \$pdo->prepare('SELECT setting_value FROM system_settings WHERE setting_key = ?');
        \$stmt->execute([\$key]);
        \$result = \$stmt->fetch(PDO::FETCH_ASSOC);
        
        return \$result ? \$result['setting_value'] : \$default;
    } catch (Exception \$e) {
        error_log('Error getting system setting: ' . \$e->getMessage());
        return \$default;
    }
}

// Función para actualizar configuración del sistema
function updateSystemSetting(\$key, \$value) {
    global \$pdo;
    
    try {
        \$stmt = \$pdo->prepare('
            INSERT INTO system_settings (setting_key, setting_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ');
        return \$stmt->execute([\$key, \$value]);
    } catch (Exception \$e) {
        error_log('Error updating system setting: ' . \$e->getMessage());
        return false;
    }
}

// Función para validar email
function isValidEmail(\$email) {
    return filter_var(\$email, FILTER_VALIDATE_EMAIL) !== false;
}

// Función para sanitizar input
function sanitizeInput(\$input) {
    return htmlspecialchars(trim(\$input), ENT_QUOTES, 'UTF-8');
}

// Función para generar token CSRF
function generateCSRFToken() {
    if (!isset(\$_SESSION[CSRF_TOKEN_NAME])) {
        \$_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return \$_SESSION[CSRF_TOKEN_NAME];
}

// Función para validar token CSRF
function validateCSRFToken(\$token) {
    return isset(\$_SESSION[CSRF_TOKEN_NAME]) && hash_equals(\$_SESSION[CSRF_TOKEN_NAME], \$token);
}

// Función para redireccionar
function redirect(\$url) {
    header('Location: \$url');
    exit();
}

// Función para respuesta JSON
function jsonResponse(\$data, \$status = 200) {
    http_response_code(\$status);
    header('Content-Type: application/json');
    echo json_encode(\$data, JSON_UNESCAPED_UNICODE);
    exit();
}

// Función para error JSON
function jsonError(\$message, \$status = 400) {
    jsonResponse(['error' => \$message], \$status);
}

// Función para éxito JSON
function jsonSuccess(\$data = null, \$message = 'Success') {
    \$response = ['success' => true, 'message' => \$message];
    if (\$data !== null) {
        \$response['data'] = \$data;
    }
    jsonResponse(\$response);
}

// Función para log de actividad
function logActivity(\$action, \$details = '', \$user_id = null) {
    global \$pdo;
    
    try {
        \$stmt = \$pdo->prepare('
            INSERT INTO activity_logs (action, details, user_id, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?)
        ');
        
        \$stmt->execute([
            \$action,
            \$details,
            \$user_id,
            \$_SERVER['REMOTE_ADDR'] ?? 'unknown',
            \$_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);
    } catch (Exception \$e) {
        error_log('Error logging activity: ' . \$e->getMessage());
    }
}

// Función para formatear precio
function formatPrice(\$price) {
    return '\$' . number_format(\$price, 2, '.', ',') . ' MXN';
}

// Función para formatear fecha
function formatDate(\$date, \$format = 'd/m/Y H:i') {
    return date(\$format, strtotime(\$date));
}

// Función para generar SKU único
function generateSKU(\$prefix = 'CH') {
    return \$prefix . strtoupper(substr(md5(uniqid()), 0, 8));
}

// Función para validar imagen
function isValidImage(\$file) {
    \$allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    \$max_size = MAX_FILE_SIZE;
    
    return in_array(\$file['type'], \$allowed_types) && \$file['size'] <= \$max_size;
}

// Función para subir imagen
function uploadImage(\$file, \$directory = UPLOAD_DIR) {
    if (!isValidImage(\$file)) {
        return false;
    }
    
    \$extension = pathinfo(\$file['name'], PATHINFO_EXTENSION);
    \$filename = uniqid() . '.' . \$extension;
    \$filepath = \$directory . \$filename;
    
    if (move_uploaded_file(\$file['tmp_name'], \$filepath)) {
        return \$filename;
    }
    
    return false;
}

// Función para eliminar imagen
function deleteImage(\$filename, \$directory = UPLOAD_DIR) {
    \$filepath = \$directory . \$filename;
    if (file_exists(\$filepath)) {
        return unlink(\$filepath);
    }
    return false;
}

// Función para verificar si es primera compra
function isFirstPurchase(\$email) {
    global \$pdo;
    
    try {
        \$stmt = \$pdo->prepare('SELECT COUNT(*) FROM orders WHERE customer_email = ? AND status = \"paid\"');
        \$stmt->execute([\$email]);
        return \$stmt->fetchColumn() == 0;
    } catch (Exception \$e) {
        error_log('Error checking first purchase: ' . \$e->getMessage());
        return true;
    }
}

// Función para calcular envío
function calculateShipping(\$subtotal, \$isFirstPurchase = false) {
    if (\$isFirstPurchase && FREE_SHIPPING_FIRST_PURCHASE) {
        return 0;
    }
    
    \$standard_cost = STANDARD_SHIPPING_COST;
    \$percentage_cost = \$subtotal * STANDARD_SHIPPING_PERCENTAGE;
    
    return max(\$standard_cost, \$percentage_cost);
}

// Configuración de sesión
session_name(SESSION_NAME);
session_start();

// Verificar si la sesión ha expirado
if (isset(\$_SESSION['last_activity']) && (time() - \$_SESSION['last_activity'] > SESSION_LIFETIME)) {
    session_unset();
    session_destroy();
    session_start();
}

\$_SESSION['last_activity'] = time();
?>";

    file_put_contents('includes/config.php', $config_content);
}

function createAdmin($pdo, $username, $password, $email) {
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash, email) VALUES (?, ?, ?)");
    $stmt->execute([$username, $password_hash, $email]);
}

function createDirectories() {
    $directories = ['uploads', 'logs', 'database'];
    
    foreach ($directories as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}

function installDependencies() {
    if (file_exists('composer.json')) {
        exec('composer install --no-dev --optimize-autoloader', $output, $return);
        return $return === 0;
    }
    return true;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalador - Charolais Store</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            min-height: 100vh;
        }
        .installer-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
        }
        .step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 10px;
            font-weight: bold;
        }
        .step.active {
            background: #28a745;
            color: white;
        }
        .step.completed {
            background: #6c757d;
            color: white;
        }
        .step.pending {
            background: #e9ecef;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="installer-card p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-hat-cowboy fa-3x text-primary mb-3"></i>
                        <h1>Instalador de Charolais Store</h1>
                        <p class="text-muted">Configuración automática de la tienda</p>
                    </div>
                    
                    <!-- Indicador de pasos -->
                    <div class="step-indicator">
                        <div class="step <?php echo $step >= 1 ? 'active' : 'pending'; ?>">1</div>
                        <div class="step <?php echo $step >= 2 ? 'active' : 'pending'; ?>">2</div>
                        <div class="step <?php echo $step >= 3 ? 'active' : 'pending'; ?>">3</div>
                    </div>
                    
                    <!-- Mensajes de error -->
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <h5><i class="fas fa-exclamation-triangle"></i> Errores encontrados:</h5>
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Mensajes de éxito -->
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success">
                            <h5><i class="fas fa-check-circle"></i> ¡Instalación exitosa!</h5>
                            <ul class="mb-0">
                                <?php foreach ($success as $msg): ?>
                                    <li><?php echo htmlspecialchars($msg); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($step == 1): ?>
                        <!-- Paso 1: Información del sistema -->
                        <div class="text-center">
                            <h3>Verificación del Sistema</h3>
                            <p>Verificando requisitos del servidor...</p>
                            
                            <div class="row text-start">
                                <div class="col-md-6">
                                    <h5>Requisitos del Servidor</h5>
                                    <ul class="list-unstyled">
                                        <li>
                                            <i class="fas fa-<?php echo version_compare(PHP_VERSION, '7.4.0', '>=') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            PHP 7.4+ (<?php echo PHP_VERSION; ?>)
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('pdo') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión PDO
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('pdo_mysql') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión PDO MySQL
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('json') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión JSON
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('curl') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión cURL
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('gd') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión GD
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h5>Permisos de Archivos</h5>
                                    <ul class="list-unstyled">
                                        <li>
                                            <i class="fas fa-<?php echo is_writable('.') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Directorio actual escribible
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo function_exists('mkdir') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Función mkdir disponible
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo function_exists('file_put_contents') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Función file_put_contents disponible
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <a href="?step=2" class="btn btn-primary btn-lg">
                                    Continuar <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                        
                    <?php elseif ($step == 2): ?>
                        <!-- Paso 2: Configuración -->
                        <form method="POST" action="?step=2">
                            <h3>Configuración de la Aplicación</h3>
                            <p class="text-muted">Completa la información necesaria para configurar tu tienda.</p>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>Base de Datos</h5>
                                    <div class="mb-3">
                                        <label class="form-label">Host de MySQL</label>
                                        <input type="text" class="form-control" name="db_host" value="localhost" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Nombre de la Base de Datos</label>
                                        <input type="text" class="form-control" name="db_name" value="charolais_store" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Usuario MySQL</label>
                                        <input type="text" class="form-control" name="db_user" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Contraseña MySQL</label>
                                        <input type="password" class="form-control" name="db_pass">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <h5>Aplicación</h5>
                                    <div class="mb-3">
                                        <label class="form-label">URL de la Aplicación</label>
                                        <input type="url" class="form-control" name="app_url" 
                                               value="<?php echo 'https://' . ($_SERVER['HTTP_HOST'] ?? 'localhost'); ?>" required>
                                        <small class="text-muted">Ejemplo: https://tudominio.com</small>
                                    </div>
                                    
                                    <h5>Stripe (Opcional)</h5>
                                    <div class="mb-3">
                                        <label class="form-label">Clave Pública de Stripe</label>
                                        <input type="text" class="form-control" name="stripe_pk" placeholder="pk_test_...">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Clave Secreta de Stripe</label>
                                        <input type="password" class="form-control" name="stripe_sk" placeholder="sk_test_...">
                                    </div>
                                    
                                    <h5>Administrador</h5>
                                    <div class="mb-3">
                                        <label class="form-label">Usuario Administrador</label>
                                        <input type="text" class="form-control" name="admin_user" value="admin" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Contraseña</label>
                                        <input type="password" class="form-control" name="admin_pass" required>
                                        <small class="text-muted">Mínimo 8 caracteres</small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Email</label>
                                        <input type="email" class="form-control" name="admin_email" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4 text-center">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-cog"></i> Instalar Aplicación
                                </button>
                            </div>
                        </form>
                        
                    <?php elseif ($step == 3): ?>
                        <!-- Paso 3: Instalación completada -->
                        <div class="text-center">
                            <i class="fas fa-check-circle fa-5x text-success mb-4"></i>
                            <h3>¡Instalación Completada!</h3>
                            <p class="lead">Tu tienda Charolais Store está lista para usar.</p>
                            
                            <div class="alert alert-info">
                                <h5>Información de Acceso</h5>
                                <p><strong>Panel de Administración:</strong> <a href="admin/" target="_blank"><?php echo $_POST['app_url'] ?? 'APP_URL'; ?>/admin/</a></p>
                                <p><strong>Usuario:</strong> <?php echo htmlspecialchars($_POST['admin_user'] ?? 'admin'); ?></p>
                                <p><strong>Contraseña:</strong> La que configuraste durante la instalación</p>
                            </div>
                            
                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <a href="admin/" class="btn btn-primary btn-lg w-100 mb-3">
                                        <i class="fas fa-cog"></i> Ir al Panel de Admin
                                    </a>
                                </div>
                                <div class="col-md-6">
                                    <a href="/" class="btn btn-outline-primary btn-lg w-100 mb-3">
                                        <i class="fas fa-home"></i> Ver Tienda
                                    </a>
                                </div>
                            </div>
                            
                            <div class="alert alert-warning mt-4">
                                <h6><i class="fas fa-exclamation-triangle"></i> Importante</h6>
                                <ul class="text-start mb-0">
                                    <li>Elimina el archivo <code>install.php</code> por seguridad</li>
                                    <li>Configura las claves de Stripe en el panel de admin</li>
                                    <li>Cambia la contraseña del administrador</li>
                                    <li>Configura SSL en tu hosting</li>
                                </ul>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 