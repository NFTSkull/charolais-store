// Configuración para cPanel - Charolais Store
// Este archivo contiene las variables de entorno y configuración para producción

const cPanelConfig = {
    // Variables de entorno para cPanel
    environment: {
        NODE_ENV: 'production',
        PORT: process.env.PORT || 3000,
        SESSION_SECRET: 'charolais_production_secret_key_2024_secure_random_string',
        BASE_URL: 'https://tudominio.com', // Cambiar por tu dominio real
    },
    
    // Configuración de Stripe (usar claves de producción)
    stripe: {
        secretKey: 'sk_live_...', // Reemplazar con tu clave secreta de producción
        publishableKey: 'pk_live_...', // Reemplazar con tu clave pública de producción
        webhookSecret: 'whsec_...', // Reemplazar con tu webhook secret
    },
    
    // Configuración de la aplicación
    app: {
        name: 'Charolais Store',
        version: '1.0.0',
        description: 'Tienda online de productos cowboy/western',
        author: 'Charolais Store',
        contact: 'contacto@charolais.com',
    },
    
    // Configuración de base de datos
    database: {
        path: './database/charolais.db',
        backupPath: './backups/',
    },
    
    // Configuración de archivos
    uploads: {
        path: './uploads/',
        maxSize: 5 * 1024 * 1024, // 5MB
        allowedTypes: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
    },
    
    // Configuración de envío
    shipping: {
        freeFirstPurchase: true,
        standardCost: 150, // MXN
        standardPercentage: 0.10, // 10% del subtotal
        allowedCountries: ['MX'],
    },
    
    // Configuración de seguridad
    security: {
        sessionTimeout: 24 * 60 * 60 * 1000, // 24 horas
        maxLoginAttempts: 5,
        lockoutDuration: 15 * 60 * 1000, // 15 minutos
    }
};

// Función para generar variables de entorno para cPanel
function generateEnvironmentVariables() {
    console.log('🔧 Generando variables de entorno para cPanel...\n');
    
    const envVars = [
        `NODE_ENV=${cPanelConfig.environment.NODE_ENV}`,
        `PORT=${cPanelConfig.environment.PORT}`,
        `SESSION_SECRET=${cPanelConfig.environment.SESSION_SECRET}`,
        `BASE_URL=${cPanelConfig.environment.BASE_URL}`,
        `STRIPE_SECRET_KEY=${cPanelConfig.stripe.secretKey}`,
        `STRIPE_PUBLISHABLE_KEY=${cPanelConfig.stripe.publishableKey}`,
        `STRIPE_WEBHOOK_SECRET=${cPanelConfig.stripe.webhookSecret}`,
    ];
    
    console.log('📋 Variables de entorno para configurar en cPanel:');
    console.log('='.repeat(60));
    envVars.forEach(envVar => {
        console.log(envVar);
    });
    console.log('='.repeat(60));
    
    return envVars;
}

// Función para verificar configuración
function verifyConfig() {
    console.log('🔍 Verificando configuración para cPanel...\n');
    
    const checks = [
        {
            name: 'Variables de entorno',
            check: () => cPanelConfig.environment.NODE_ENV === 'production',
            message: '✅ Configuración de producción'
        },
        {
            name: 'Claves de Stripe',
            check: () => cPanelConfig.stripe.secretKey.startsWith('sk_live_'),
            message: '⚠️ Usar claves de PRODUCCIÓN de Stripe'
        },
        {
            name: 'URL base',
            check: () => cPanelConfig.environment.BASE_URL.includes('https://'),
            message: '✅ URL base con HTTPS'
        },
        {
            name: 'Session secret',
            check: () => cPanelConfig.environment.SESSION_SECRET.length > 20,
            message: '✅ Session secret seguro'
        }
    ];
    
    checks.forEach(check => {
        if (check.check()) {
            console.log(`✅ ${check.name}: ${check.message}`);
        } else {
            console.log(`❌ ${check.name}: ${check.message}`);
        }
    });
}

// Función para generar archivo .env
function generateEnvFile() {
    const envContent = generateEnvironmentVariables().join('\n');
    
    try {
        fs.writeFileSync('.env.production', envContent);
        console.log('\n📄 Archivo .env.production generado');
        console.log('💡 Usar este archivo como referencia para configurar variables en cPanel');
    } catch (error) {
        console.log('❌ Error generando archivo .env.production:', error.message);
    }
}

// Función para generar instrucciones de instalación
function generateInstallInstructions() {
    console.log('\n📋 INSTRUCCIONES DE INSTALACIÓN EN CPANEL');
    console.log('='.repeat(60));
    
    const instructions = [
        '1. Crear aplicación Node.js en cPanel:',
        '   - Node.js version: 18.x o superior',
        '   - Application mode: Production',
        '   - Application root: /home/username/charolais-store',
        '   - Application URL: https://tudominio.com',
        '   - Application startup file: server.js',
        '',
        '2. Configurar variables de entorno en cPanel:',
        '   - Ir a Node.js App Manager',
        '   - Hacer clic en "Environment Variables"',
        '   - Agregar cada variable del archivo .env.production',
        '',
        '3. Subir archivos:',
        '   - Usar File Manager o FTP',
        '   - Subir toda la carpeta charolais-store',
        '   - Verificar permisos (755 para carpetas, 644 para archivos)',
        '',
        '4. Instalar dependencias:',
        '   - En cPanel Terminal o SSH:',
        '   - cd /home/username/charolais-store',
        '   - npm install --production',
        '',
        '5. Iniciar aplicación:',
        '   - En Node.js App Manager:',
        '   - Hacer clic en "Run NPM Install"',
        '   - Hacer clic en "Restart App"',
        '',
        '6. Verificar funcionamiento:',
        '   - Frontend: https://tudominio.com',
        '   - Admin: https://tudominio.com/admin',
        '   - API: https://tudominio.com/api/products',
        '',
        '7. Configurar SSL/HTTPS:',
        '   - En cPanel SSL/TLS Status',
        '   - Instalar certificado SSL',
        '',
        '8. Configurar dominio:',
        '   - En cPanel Domains',
        '   - Apuntar dominio a la carpeta de la aplicación'
    ];
    
    instructions.forEach(instruction => {
        console.log(instruction);
    });
}

// Función principal
function main() {
    console.log('🚀 Configuración para cPanel - Charolais Store');
    console.log('='.repeat(60));
    
    verifyConfig();
    generateEnvironmentVariables();
    generateEnvFile();
    generateInstallInstructions();
    
    console.log('\n🎯 CONFIGURACIÓN COMPLETADA');
    console.log('='.repeat(60));
    console.log('✅ Archivo de configuración generado');
    console.log('✅ Variables de entorno listas');
    console.log('✅ Instrucciones de instalación creadas');
    console.log('\n📋 Próximos pasos:');
    console.log('1. Revisar y actualizar las claves de Stripe');
    console.log('2. Cambiar BASE_URL por tu dominio real');
    console.log('3. Seguir las instrucciones de instalación');
    console.log('4. Hacer backup antes de migrar');
}

// Exportar configuración
module.exports = {
    cPanelConfig,
    generateEnvironmentVariables,
    verifyConfig,
    generateEnvFile,
    generateInstallInstructions,
    main
};

// Ejecutar si se llama directamente
if (require.main === module) {
    const fs = require('fs');
    main();
} 