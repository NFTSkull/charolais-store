# 🚀 GUÍA DE DEPLOYMENT - CHAROLAIS EN cPANEL

## 📦 **CONTENIDO DEL PAQUETE**

### ✅ **Archivos Incluidos en el ZIP:**

#### **🌐 Frontend (Cliente):**
- `index.html` - Página principal de la tienda
- `styles.css` - Estilos completos + responsivo móvil
- `script.js` - JavaScript con selector de variantes
- `cancel.html` - Página de cancelación de pago
- `success.html` - Página de éxito de pago

#### **⚙️ Backend (Servidor):**
- `server.js` - Servidor Node.js completo
- `package.json` - Dependencias del proyecto
- `charolais.db` - Base de datos SQLite con productos y variantes

#### **🛠️ Panel de Administración:**
- `admin-variants.html` - Gestión de productos y variantes
- `admin-orders.html` - Gestión de órdenes y notificaciones
- `admin.js` - JavaScript del panel de admin

#### **📁 Recursos:**
- `uploads/` - Carpeta con imágenes de productos
- Archivos de configuración y scripts

---

## 🌐 **PASOS PARA SUBIR A cPANEL**

### **1. 📋 REQUISITOS PREVIOS:**
- ✅ Hosting con **Node.js habilitado**
- ✅ Acceso a **cPanel**
- ✅ Dominio configurado
- ✅ Stripe account activo

### **2. 🔧 PREPARACIÓN EN cPANEL:**

#### **Paso 1: Habilitar Node.js**
1. En cPanel, busca "**Node.js**" o "**Node.js Selector**"
2. Crea una nueva aplicación Node.js
3. Selecciona versión **16.x** o **18.x**
4. Directorio de aplicación: `public_html` (o subdirectorio)
5. Archivo de inicio: `server.js`

#### **Paso 2: Subir Archivos**
1. En cPanel, abre "**Administrador de archivos**"
2. Ve a `public_html` (o tu directorio de aplicación)
3. Sube el archivo `charolais-cpanel.zip`
4. **Extrae** todos los archivos

#### **Paso 3: Instalar Dependencias**
1. En cPanel, abre "**Terminal**" (si está disponible)
2. Navega a tu directorio: `cd public_html`
3. Ejecuta: `npm install`

### **3. ⚙️ CONFIGURACIÓN DE VARIABLES:**

#### **En cPanel → Variables de Entorno:**
```
NODE_ENV=production
PORT=3000
STRIPE_SECRET_KEY=sk_live_tu_clave_secreta_de_stripe
STRIPE_WEBHOOK_SECRET=whsec_tu_webhook_secret
BASE_URL=https://tudominio.com
```

### **4. 🔗 CONFIGURAR WEBHOOKS DE STRIPE:**

#### **En Stripe Dashboard:**
1. Ve a **Developers** → **Webhooks**
2. Crea nuevo endpoint: `https://tudominio.com/webhook`
3. Selecciona eventos:
   - `checkout.session.completed`
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
4. Copia el **webhook secret** y agrégalo a las variables de entorno

---

## 🛒 **FUNCIONAMIENTO DEL PANEL DE ADMIN**

### **✅ RESPUESTA A TU PREGUNTA:**
**"¿Se va a reflejar automáticamente en el sitio web?"**

**¡SÍ! Todo funciona automáticamente:**

#### **🔄 Cambios Inmediatos:**
- ✅ **Agregar productos** → Aparecen instantáneamente en la tienda
- ✅ **Cambiar precios** → Se actualizan en tiempo real
- ✅ **Modificar stock** → Se refleja inmediatamente
- ✅ **Agregar variantes** → Selector de colores aparece automáticamente
- ✅ **Subir imágenes** → Se muestran al instante

#### **🔔 Notificaciones Automáticas:**
- ✅ **Nueva venta** → Notificación instantánea en el panel
- ✅ **Stock bajo** → Alerta automática
- ✅ **Pago fallido** → Notificación inmediata

### **🌐 Accesos del Panel:**
- **Panel Productos:** `https://tudominio.com/admin-variants`
- **Panel Órdenes:** `https://tudominio.com/admin-orders`

---

## 💳 **CONFIGURACIÓN DE STRIPE PARA PRODUCCIÓN**

### **1. Cambiar a Claves Live:**
En `server.js`, línea 2:
```javascript
// Cambiar de test a live
const stripe = require('stripe')('sk_live_TU_CLAVE_SECRETA_REAL');
```

En `script.js`, línea 13:
```javascript
// Cambiar de test a live
this.stripe = Stripe('pk_live_TU_CLAVE_PUBLICA_REAL');
```

### **2. Configurar URLs de Éxito/Cancelación:**
Las URLs se configuran automáticamente según tu dominio.

---

## 🔒 **SEGURIDAD Y RENDIMIENTO**

### **✅ Configuraciones Importantes:**

#### **1. Variables de Entorno:**
```
WEBHOOK_SECRET=tu_webhook_secret_real
ADMIN_PASSWORD=contraseña_segura_admin
DATABASE_BACKUP=habilitado
```

#### **2. Permisos de Archivos:**
- `charolais.db` → 644 (lectura/escritura)
- `uploads/` → 755 (subida de imágenes)
- `server.js` → 644

#### **3. Backup Automático:**
- Configura backup diario de `charolais.db`
- Backup semanal de carpeta `uploads/`

---

## 📊 **FUNCIONALIDADES QUE TENDRÁS EN VIVO:**

### **🛒 Para Clientes:**
- ✅ Tienda completa con productos
- ✅ Selector de variantes de color
- ✅ Carrito de compras
- ✅ Pago seguro con Stripe
- ✅ Envío GRATIS
- ✅ Responsive móvil

### **⚙️ Para Administradores:**
- ✅ Panel de gestión de productos
- ✅ Control de inventario en tiempo real
- ✅ Dashboard de órdenes y ventas
- ✅ Notificaciones automáticas
- ✅ Estadísticas de ventas
- ✅ Acceso desde cualquier dispositivo

---

## 🎯 **RESULTADO FINAL:**

**Una vez subido a cPanel tendrás:**

### **🌐 Sitio Web Público:**
- `https://tudominio.com` - Tienda para clientes

### **⚙️ Paneles de Administración:**
- `https://tudominio.com/admin-variants` - Gestión de productos
- `https://tudominio.com/admin-orders` - Gestión de órdenes

### **💰 Sistema Completo:**
- **Procesamiento de pagos** en tiempo real
- **Gestión de inventario** automática
- **Notificaciones de ventas** instantáneas
- **Reducción de stock** automática
- **Panel móvil** para gestionar desde celular

---

## 📞 **SOPORTE POST-DEPLOYMENT:**

### **🔍 Verificaciones:**
1. **Probar compra completa** con tarjeta de prueba
2. **Verificar webhooks** en Stripe
3. **Probar panel de admin** desde móvil
4. **Confirmar notificaciones** de ventas

### **🛠️ Mantenimiento:**
- **Backup diario** de base de datos
- **Actualizar precios** desde el panel
- **Agregar productos** según necesites
- **Revisar órdenes** diariamente

---

**¡Tu tienda estará completamente operativa y lista para recibir clientes reales! 🤠💰🚀** 