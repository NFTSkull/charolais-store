# Guía de Migración a cPanel - Charolais Store

## 📋 Checklist Pre-Migración

### ✅ Verificaciones Completadas:
- [x] Backend Node.js/Express funcionando
- [x] Admin panel con CRUD completo de productos
- [x] Sistema de imágenes con preview y eliminación
- [x] Variantes de productos (colores) implementadas
- [x] Carrito de compras con variantes
- [x] Checkout con Stripe configurado
- [x] Envío gratis en primera compra
- [x] Páginas de éxito y cancelación
- [x] Base de datos SQLite con productos y categorías
- [x] Autenticación de admin funcionando

### 🔧 Configuración de Producción:
- [x] Variables de entorno para Stripe
- [x] Configuración de sesiones seguras
- [x] Manejo de imágenes para producción
- [x] URLs públicas para Stripe

## 🚀 Pasos para Migración a cPanel

### 1. Preparación de Archivos
```bash
# Estructura de archivos para subir:
charolais-store/
├── server.js
├── package.json
├── database/
│   └── charolais.db
├── uploads/
│   └── (todas las imágenes)
├── public/
│   ├── css/
│   ├── js/
│   └── images/
└── views/
    └── (archivos HTML)
```

### 2. Configuración en cPanel

#### A. Crear Aplicación Node.js
1. Ir a "Setup Node.js App" en cPanel
2. Crear nueva aplicación:
   - **Node.js version**: 18.x o superior
   - **Application mode**: Production
   - **Application root**: /home/username/charolais-store
   - **Application URL**: https://tudominio.com
   - **Application startup file**: server.js

#### B. Variables de Entorno
Configurar en cPanel:
```
NODE_ENV=production
STRIPE_SECRET_KEY=sk_live_...
STRIPE_PUBLISHABLE_KEY=pk_live_...
SESSION_SECRET=tu_session_secret_seguro
```

#### C. Configurar Dominio
1. Apuntar dominio a la carpeta de la aplicación
2. Configurar SSL/HTTPS
3. Configurar redirección de www a no-www (opcional)

### 3. Subida de Archivos

#### Opción A: File Manager de cPanel
1. Crear carpeta `charolais-store` en public_html
2. Subir todos los archivos via File Manager
3. Asegurar permisos correctos (755 para carpetas, 644 para archivos)

#### Opción B: FTP/SFTP
```bash
# Usar cliente FTP para subir archivos
# Host: tu-dominio.com
# Usuario: tu-usuario-cpanel
# Puerto: 21 (FTP) o 22 (SFTP)
```

### 4. Instalación de Dependencias
En cPanel Terminal o SSH:
```bash
cd /home/username/charolais-store
npm install --production
```

### 5. Configuración de Base de Datos
- La base de datos SQLite se subirá con los archivos
- Verificar permisos de escritura en carpeta `database/`
- Hacer backup de la base de datos actual

### 6. Configuración de Imágenes
- Subir carpeta `uploads/` completa
- Verificar permisos de escritura (755)
- Las imágenes serán accesibles via: `https://tudominio.com/uploads/imagen.jpg`

### 7. Iniciar Aplicación
1. En cPanel Node.js App Manager:
   - Hacer clic en "Run NPM Install"
   - Hacer clic en "Restart App"

### 8. Verificaciones Post-Migración

#### A. Funcionalidades Críticas:
- [ ] Página principal carga correctamente
- [ ] Productos se muestran con imágenes
- [ ] Variantes de productos funcionan
- [ ] Carrito de compras funciona
- [ ] Admin panel accesible y funcional
- [ ] Stripe checkout funciona
- [ ] Imágenes se cargan correctamente

#### B. URLs de Verificación:
- Frontend: https://tudominio.com
- Admin Panel: https://tudominio.com/admin
- API Products: https://tudominio.com/api/products
- API Categories: https://tudominio.com/api/categories

#### C. Logs y Debugging:
- Revisar logs en cPanel Error Logs
- Verificar Node.js App logs
- Probar endpoints críticos

## 🔒 Configuración de Seguridad

### Variables de Entorno de Producción:
```javascript
// En server.js ya configurado para detectar producción
if (process.env.NODE_ENV === 'production') {
  app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { 
      secure: true,
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 horas
    }
  }));
}
```

### Configuración de Stripe para Producción:
- Usar claves `sk_live_` y `pk_live_`
- Configurar webhook endpoint en Stripe Dashboard
- Verificar dominio en Stripe

## 📞 Soporte Post-Migración

### Problemas Comunes:
1. **Error 500**: Revisar logs de Node.js en cPanel
2. **Imágenes no cargan**: Verificar permisos de carpeta uploads/
3. **Stripe no funciona**: Verificar claves de producción
4. **Admin no accede**: Verificar configuración de sesiones

### Comandos Útiles en cPanel:
```bash
# Ver logs de la aplicación
tail -f /home/username/logs/nodejs.log

# Reiniciar aplicación
# Usar botón "Restart App" en Node.js App Manager

# Verificar procesos
ps aux | grep node
```

## 🎯 Próximos Pasos

1. **Backup**: Hacer backup completo antes de migrar
2. **Pruebas**: Probar en subdominio primero (opcional)
3. **DNS**: Configurar DNS para apuntar al nuevo servidor
4. **SSL**: Configurar certificado SSL
5. **Monitoreo**: Configurar monitoreo de la aplicación

---

**Nota**: Esta guía asume que tienes acceso completo a cPanel. Si necesitas ayuda específica con tu proveedor de hosting, consulta su documentación. 