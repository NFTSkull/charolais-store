const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

console.log('💾 Creando Backup Pre-Migración - Charolais Store');
console.log('='.repeat(60));

// Configuración de backup
const backupConfig = {
    sourceDir: '.',
    backupDir: './backups',
    timestamp: new Date().toISOString().replace(/[:.]/g, '-'),
    excludeFiles: [
        'node_modules',
        '.git',
        '.DS_Store',
        '*.log',
        'backups',
        '*.zip',
        'test-*.js',
        'test-*.html'
    ]
};

// Función para crear directorio de backup
function createBackupDirectory() {
    const backupPath = path.join(backupConfig.backupDir, backupConfig.timestamp);
    
    if (!fs.existsSync(backupConfig.backupDir)) {
        fs.mkdirSync(backupConfig.backupDir, { recursive: true });
        console.log('✅ Directorio de backups creado');
    }
    
    if (!fs.existsSync(backupPath)) {
        fs.mkdirSync(backupPath, { recursive: true });
        console.log('✅ Directorio de backup específico creado');
    }
    
    return backupPath;
}

// Función para copiar archivos
function copyFile(source, destination) {
    try {
        const destDir = path.dirname(destination);
        if (!fs.existsSync(destDir)) {
            fs.mkdirSync(destDir, { recursive: true });
        }
        fs.copyFileSync(source, destination);
        return true;
    } catch (error) {
        console.log(`❌ Error copiando ${source}: ${error.message}`);
        return false;
    }
}

// Función para verificar si un archivo debe ser excluido
function shouldExcludeFile(filePath) {
    const fileName = path.basename(filePath);
    const relativePath = path.relative(backupConfig.sourceDir, filePath);
    
    return backupConfig.excludeFiles.some(pattern => {
        if (pattern.includes('*')) {
            const regex = new RegExp(pattern.replace('*', '.*'));
            return regex.test(fileName) || regex.test(relativePath);
        }
        return fileName === pattern || relativePath.includes(pattern);
    });
}

// Función para copiar directorio recursivamente
function copyDirectory(source, destination) {
    if (!fs.existsSync(destination)) {
        fs.mkdirSync(destination, { recursive: true });
    }
    
    const items = fs.readdirSync(source);
    
    for (const item of items) {
        const sourcePath = path.join(source, item);
        const destPath = path.join(destination, item);
        
        if (shouldExcludeFile(sourcePath)) {
            console.log(`⏭️ Excluyendo: ${sourcePath}`);
            continue;
        }
        
        const stat = fs.statSync(sourcePath);
        
        if (stat.isDirectory()) {
            copyDirectory(sourcePath, destPath);
        } else {
            copyFile(sourcePath, destPath);
        }
    }
}

// Función para crear backup de la base de datos
function backupDatabase(backupPath) {
    console.log('\n🗄️ Creando backup de la base de datos...');
    
    const dbPath = 'database/charolais.db';
    const backupDbPath = path.join(backupPath, 'database', 'charolais.db');
    
    if (fs.existsSync(dbPath)) {
        if (copyFile(dbPath, backupDbPath)) {
            console.log('✅ Base de datos respaldada');
            
            // Verificar integridad del backup
            const stats = fs.statSync(backupDbPath);
            console.log(`📊 Tamaño del backup: ${(stats.size / 1024 / 1024).toFixed(2)} MB`);
        } else {
            console.log('❌ Error respaldando base de datos');
        }
    } else {
        console.log('⚠️ Base de datos no encontrada');
    }
}

// Función para crear backup de imágenes
function backupImages(backupPath) {
    console.log('\n📸 Creando backup de imágenes...');
    
    const uploadsPath = 'uploads';
    const backupUploadsPath = path.join(backupPath, 'uploads');
    
    if (fs.existsSync(uploadsPath)) {
        copyDirectory(uploadsPath, backupUploadsPath);
        
        const images = fs.readdirSync(uploadsPath).filter(file => 
            file.match(/\.(jpg|jpeg|png|gif|webp)$/i)
        );
        
        console.log(`✅ ${images.length} imágenes respaldadas`);
    } else {
        console.log('⚠️ Carpeta de imágenes no encontrada');
    }
}

// Función para crear archivo de información del backup
function createBackupInfo(backupPath) {
    const backupInfo = {
        timestamp: new Date().toISOString(),
        version: '1.0.0',
        description: 'Backup pre-migración a cPanel',
        files: {
            server: fs.existsSync('server.js'),
            package: fs.existsSync('package.json'),
            database: fs.existsSync('database/charolais.db'),
            uploads: fs.existsSync('uploads'),
            public: fs.existsSync('public'),
            views: fs.existsSync('views')
        },
        stats: {
            totalFiles: 0,
            totalSize: 0
        }
    };
    
    // Contar archivos y tamaño
    function countFiles(dir) {
        if (!fs.existsSync(dir)) return;
        
        const items = fs.readdirSync(dir);
        for (const item of items) {
            const itemPath = path.join(dir, item);
            const stat = fs.statSync(itemPath);
            
            if (stat.isDirectory()) {
                countFiles(itemPath);
            } else {
                backupInfo.stats.totalFiles++;
                backupInfo.stats.totalSize += stat.size;
            }
        }
    }
    
    countFiles(backupPath);
    
    // Escribir archivo de información
    const infoPath = path.join(backupPath, 'backup-info.json');
    fs.writeFileSync(infoPath, JSON.stringify(backupInfo, null, 2));
    
    console.log('✅ Información de backup creada');
    console.log(`📊 Total de archivos: ${backupInfo.stats.totalFiles}`);
    console.log(`📊 Tamaño total: ${(backupInfo.stats.totalSize / 1024 / 1024).toFixed(2)} MB`);
}

// Función para crear archivo ZIP del backup
function createZipBackup(backupPath) {
    console.log('\n📦 Creando archivo ZIP del backup...');
    
    const zipPath = path.join(backupConfig.backupDir, `charolais-backup-${backupConfig.timestamp}.zip`);
    
    // Usar zip command si está disponible
    const zipCommand = `cd "${backupPath}" && zip -r "${zipPath}" .`;
    
    exec(zipCommand, (error, stdout, stderr) => {
        if (error) {
            console.log('⚠️ No se pudo crear ZIP (zip command no disponible)');
            console.log('💡 El backup está disponible en formato de carpetas');
        } else {
            console.log('✅ Archivo ZIP creado');
            console.log(`📁 Ubicación: ${zipPath}`);
        }
    });
}

// Función principal
function main() {
    console.log('🚀 Iniciando proceso de backup...\n');
    
    // Crear directorio de backup
    const backupPath = createBackupDirectory();
    console.log(`📁 Backup path: ${backupPath}\n`);
    
    // Copiar archivos principales
    console.log('📁 Copiando archivos principales...');
    const mainFiles = [
        'server.js',
        'package.json',
        'package-lock.json',
        'README.md',
        'cpanel-deployment.md',
        'cpanel-setup.js',
        'verify-production-ready.js'
    ];
    
    let copiedFiles = 0;
    mainFiles.forEach(file => {
        if (fs.existsSync(file)) {
            if (copyFile(file, path.join(backupPath, file))) {
                copiedFiles++;
            }
        }
    });
    console.log(`✅ ${copiedFiles} archivos principales copiados`);
    
    // Copiar carpetas importantes
    console.log('\n📂 Copiando carpetas...');
    const importantDirs = ['public', 'views', 'database'];
    
    importantDirs.forEach(dir => {
        if (fs.existsSync(dir)) {
            copyDirectory(dir, path.join(backupPath, dir));
            console.log(`✅ Carpeta ${dir} copiada`);
        } else {
            console.log(`⚠️ Carpeta ${dir} no encontrada`);
        }
    });
    
    // Backup específico de base de datos
    backupDatabase(backupPath);
    
    // Backup específico de imágenes
    backupImages(backupPath);
    
    // Crear información del backup
    createBackupInfo(backupPath);
    
    // Crear ZIP (opcional)
    createZipBackup(backupPath);
    
    console.log('\n' + '='.repeat(60));
    console.log('🎉 BACKUP COMPLETADO EXITOSAMENTE');
    console.log('='.repeat(60));
    console.log(`📁 Ubicación: ${backupPath}`);
    console.log(`⏰ Timestamp: ${backupConfig.timestamp}`);
    console.log('\n📋 El backup incluye:');
    console.log('✅ Archivos del servidor');
    console.log('✅ Base de datos SQLite');
    console.log('✅ Imágenes de productos');
    console.log('✅ Configuración de producción');
    console.log('✅ Documentación de migración');
    console.log('\n🚀 Ahora puedes proceder con la migración a cPanel');
    console.log('📋 Consulta cpanel-deployment.md para instrucciones');
    console.log('='.repeat(60));
}

// Ejecutar si se llama directamente
if (require.main === module) {
    main();
}

module.exports = {
    backupConfig,
    createBackupDirectory,
    copyFile,
    copyDirectory,
    backupDatabase,
    backupImages,
    createBackupInfo,
    createZipBackup,
    main
}; 