const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

console.log('🔍 Verificación Pre-Migración - Charolais Store');
console.log('==============================================\n');

// 1. Verificar estructura de archivos
console.log('📁 Verificando estructura de archivos...');
const requiredFiles = [
    'server.js',
    'package.json',
    'database/charolais.db',
    'public/css/styles.css',
    'public/js/main.js',
    'public/js/admin.js',
    'views/index.html',
    'views/admin.html',
    'views/success.html',
    'views/cancel.html'
];

let filesOK = true;
requiredFiles.forEach(file => {
    if (fs.existsSync(file)) {
        console.log(`✅ ${file}`);
    } else {
        console.log(`❌ ${file} - FALTANTE`);
        filesOK = false;
    }
});

// 2. Verificar carpeta de uploads
console.log('\n📸 Verificando imágenes...');
if (fs.existsSync('uploads')) {
    const images = fs.readdirSync('uploads').filter(file => 
        file.match(/\.(jpg|jpeg|png|gif|webp)$/i)
    );
    console.log(`✅ Carpeta uploads existe con ${images.length} imágenes`);
    
    if (images.length > 0) {
        console.log(`📋 Imágenes encontradas: ${images.slice(0, 5).join(', ')}${images.length > 5 ? '...' : ''}`);
    }
} else {
    console.log('❌ Carpeta uploads no existe');
    filesOK = false;
}

// 3. Verificar base de datos
console.log('\n🗄️ Verificando base de datos...');
if (fs.existsSync('database/charolais.db')) {
    const db = new sqlite3.Database('database/charolais.db');
    
    db.all("SELECT name FROM sqlite_master WHERE type='table'", (err, tables) => {
        if (err) {
            console.log('❌ Error accediendo a la base de datos');
        } else {
            console.log(`✅ Base de datos accesible con ${tables.length} tablas`);
            console.log(`📋 Tablas: ${tables.map(t => t.name).join(', ')}`);
            
            // Verificar productos
            db.get("SELECT COUNT(*) as count FROM products", (err, result) => {
                if (err) {
                    console.log('❌ Error contando productos');
                } else {
                    console.log(`✅ ${result.count} productos en la base de datos`);
                }
                
                // Verificar categorías
                db.get("SELECT COUNT(*) as count FROM categories", (err, result) => {
                    if (err) {
                        console.log('❌ Error contando categorías');
                    } else {
                        console.log(`✅ ${result.count} categorías en la base de datos`);
                    }
                    
                    // Verificar variantes
                    db.get("SELECT COUNT(*) as count FROM product_variants", (err, result) => {
                        if (err) {
                            console.log('❌ Error contando variantes');
                        } else {
                            console.log(`✅ ${result.count} variantes de productos`);
                        }
                        
                        db.close();
                        console.log('\n🎯 Verificación de base de datos completada');
                    });
                });
            });
        }
    });
} else {
    console.log('❌ Base de datos no encontrada');
    filesOK = false;
}

// 4. Verificar package.json
console.log('\n📦 Verificando dependencias...');
try {
    const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
    console.log(`✅ Package.json válido - Versión: ${packageJson.version}`);
    console.log(`📋 Dependencias: ${Object.keys(packageJson.dependencies).length} instaladas`);
    console.log(`📋 Scripts disponibles: ${Object.keys(packageJson.scripts).join(', ')}`);
} catch (error) {
    console.log('❌ Error leyendo package.json');
    filesOK = false;
}

// 5. Verificar configuración de producción
console.log('\n⚙️ Verificando configuración de producción...');
try {
    const serverContent = fs.readFileSync('server.js', 'utf8');
    
    // Verificar configuración de sesiones
    if (serverContent.includes('NODE_ENV === \'production\'')) {
        console.log('✅ Configuración de sesiones para producción detectada');
    } else {
        console.log('⚠️ Configuración de sesiones para producción no encontrada');
    }
    
    // Verificar manejo de imágenes para Stripe (debe estar comentado)
    if (serverContent.includes('// TEMPORAL: Remover imágenes para probar')) {
        console.log('✅ Manejo de imágenes para Stripe correctamente comentado');
    } else {
        console.log('⚠️ Manejo de imágenes para Stripe no está comentado');
    }
    
    // Verificar rutas de API
    if (serverContent.includes('/api/products') && serverContent.includes('/api/categories')) {
        console.log('✅ Rutas de API configuradas');
    } else {
        console.log('⚠️ Rutas de API no encontradas');
    }
    
    // Verificar configuración de envío gratis
    if (serverContent.includes('Envío GRATIS (Primera compra)')) {
        console.log('✅ Configuración de envío gratis implementada');
    } else {
        console.log('⚠️ Configuración de envío gratis no encontrada');
    }
    
} catch (error) {
    console.log('❌ Error leyendo server.js');
    filesOK = false;
}

// 6. Verificar archivos de frontend
console.log('\n🌐 Verificando archivos de frontend...');
const frontendFiles = [
    'public/css/styles.css',
    'public/js/main.js',
    'public/js/admin.js',
    'views/index.html',
    'views/admin.html'
];

frontendFiles.forEach(file => {
    if (fs.existsSync(file)) {
        const stats = fs.statSync(file);
        console.log(`✅ ${file} (${(stats.size / 1024).toFixed(1)} KB)`);
    } else {
        console.log(`❌ ${file} - FALTANTE`);
        filesOK = false;
    }
});

// 7. Verificar variables de entorno
console.log('\n🔐 Verificando variables de entorno...');
const envVars = ['NODE_ENV', 'STRIPE_SECRET_KEY', 'STRIPE_PUBLISHABLE_KEY', 'SESSION_SECRET'];
envVars.forEach(envVar => {
    if (process.env[envVar]) {
        console.log(`✅ ${envVar} configurada`);
    } else {
        console.log(`⚠️ ${envVar} no configurada (se configurará en cPanel)`);
    }
});

// 8. Verificar estructura de carpetas
console.log('\n📂 Verificando estructura de carpetas...');
const requiredFolders = ['public', 'public/css', 'public/js', 'views', 'database', 'uploads'];
requiredFolders.forEach(folder => {
    if (fs.existsSync(folder)) {
        console.log(`✅ ${folder}/`);
    } else {
        console.log(`❌ ${folder}/ - FALTANTE`);
        filesOK = false;
    }
});

// Resumen final
console.log('\n' + '='.repeat(50));
console.log('📊 RESUMEN DE VERIFICACIÓN');
console.log('='.repeat(50));

if (filesOK) {
    console.log('🎉 ¡SISTEMA LISTO PARA MIGRACIÓN!');
    console.log('\n✅ Todos los archivos críticos están presentes');
    console.log('✅ Base de datos accesible y funcional');
    console.log('✅ Configuración de producción implementada');
    console.log('✅ Frontend y backend sincronizados');
    console.log('✅ Imágenes para Stripe correctamente manejadas');
    
    console.log('\n🚀 PRÓXIMOS PASOS:');
    console.log('1. Hacer backup completo del proyecto');
    console.log('2. Subir archivos a cPanel');
    console.log('3. Configurar variables de entorno en cPanel');
    console.log('4. Instalar dependencias en producción');
    console.log('5. Iniciar aplicación Node.js');
    console.log('6. Verificar funcionalidades post-migración');
    
} else {
    console.log('⚠️ PROBLEMAS DETECTADOS');
    console.log('Por favor, resuelve los problemas marcados con ❌ antes de migrar');
}

console.log('\n📋 Consulta cpanel-deployment.md para instrucciones detalladas');
console.log('='.repeat(50)); 