<?php
// 🚀 CHAROLAIS - PANEL DE ADMINISTRACIÓN
// ====================================
require_once '../config.php';
checkAdminAuth();

// Obtener estadísticas básicas
try {
    $db = Database::getInstance()->getConnection();
    
    // Contar productos
    $stmt = $db->query("SELECT COUNT(*) as total FROM products WHERE is_active = 1");
    $totalProducts = $stmt->fetch()['total'];
    
    // Contar órdenes del mes
    $stmt = $db->query("SELECT COUNT(*) as total FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)");
    $ordersThisMonth = $stmt->fetch()['total'];
    
    // Productos con stock bajo
    $stmt = $db->query("SELECT COUNT(*) as total FROM products WHERE stock_quantity <= " . LOW_STOCK_ALERT . " AND is_active = 1");
    $lowStockProducts = $stmt->fetch()['total'];
    
    // Ventas del mes
    $stmt = $db->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM orders WHERE status = 'completed' AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)");
    $salesThisMonth = $stmt->fetch()['total'];
    
} catch (Exception $e) {
    $totalProducts = 0;
    $ordersThisMonth = 0;
    $lowStockProducts = 0;
    $salesThisMonth = 0;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤠 Panel Admin - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            min-height: 100vh;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            color: #8B4513;
            font-size: 2.5em;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logout-btn {
            background: #dc3545;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
        }

        .logout-btn:hover {
            background: #c82333;
            transform: translateY(-2px);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .stat-card {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            text-align: center;
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card .icon {
            font-size: 3em;
            margin-bottom: 15px;
            color: #8B4513;
        }

        .stat-card .number {
            font-size: 2.5em;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .stat-card .label {
            color: #7f8c8d;
            font-size: 1.1em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .actions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .action-card {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .action-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 35px rgba(0, 0, 0, 0.2);
        }

        .action-card .icon {
            font-size: 4em;
            margin-bottom: 20px;
            color: #8B4513;
        }

        .action-card h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 1.5em;
        }

        .action-card p {
            color: #7f8c8d;
            line-height: 1.6;
        }

        .recent-section {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            margin-bottom: 30px;
        }

        .recent-section h3 {
            color: #8B4513;
            margin-bottom: 20px;
            font-size: 1.8em;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid #dc3545;
        }

        .success {
            background: #d4edda;
            color: #155724;
            border-left-color: #28a745;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }

            .header h1 {
                font-size: 2em;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .actions-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>
                <i class="fas fa-hat-cowboy"></i>
                Panel de Administración
            </h1>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
            </a>
        </div>

        <!-- Alertas -->
        <?php if ($lowStockProducts > 0): ?>
        <div class="alert">
            <i class="fas fa-exclamation-triangle"></i>
            <strong>¡Atención!</strong> Tienes <?php echo $lowStockProducts; ?> producto(s) con stock bajo.
        </div>
        <?php endif; ?>

        <!-- Estadísticas -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="icon">
                    <i class="fas fa-box"></i>
                </div>
                <div class="number"><?php echo number_format($totalProducts); ?></div>
                <div class="label">Productos</div>
            </div>

            <div class="stat-card">
                <div class="icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="number"><?php echo number_format($ordersThisMonth); ?></div>
                <div class="label">Órdenes este mes</div>
            </div>

            <div class="stat-card">
                <div class="icon">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="number"><?php echo formatPrice($salesThisMonth); ?></div>
                <div class="label">Ventas del mes</div>
            </div>

            <div class="stat-card">
                <div class="icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <div class="number"><?php echo number_format($lowStockProducts); ?></div>
                <div class="label">Stock bajo</div>
            </div>
        </div>

        <!-- Acciones principales -->
        <div class="actions-grid">
            <div class="action-card" onclick="location.href='productos.php'">
                <div class="icon">
                    <i class="fas fa-tshirt"></i>
                </div>
                <h3>Gestionar Productos</h3>
                <p>Agregar, editar y administrar tu catálogo de productos western</p>
            </div>

            <div class="action-card" onclick="location.href='ordenes.php'">
                <div class="icon">
                    <i class="fas fa-receipt"></i>
                </div>
                <h3>Ver Órdenes</h3>
                <p>Administrar pedidos, cambiar estados y seguimiento</p>
            </div>

            <div class="action-card" onclick="location.href='configuracion.php'">
                <div class="icon">
                    <i class="fas fa-cogs"></i>
                </div>
                <h3>Configuración</h3>
                <p>Ajustes generales, Stripe, notificaciones y más</p>
            </div>

            <div class="action-card" onclick="window.open('<?php echo SITE_URL; ?>', '_blank')">
                <div class="icon">
                    <i class="fas fa-external-link-alt"></i>
                </div>
                <h3>Ver Tienda</h3>
                <p>Visitar la tienda como la ven tus clientes</p>
            </div>
        </div>

        <!-- Actividad reciente -->
        <div class="recent-section">
            <h3>
                <i class="fas fa-clock"></i>
                Acceso Rápido
            </h3>
            <div class="actions-grid">
                <div class="action-card" onclick="location.href='productos.php?action=new'">
                    <div class="icon">
                        <i class="fas fa-plus"></i>
                    </div>
                    <h3>Nuevo Producto</h3>
                    <p>Agregar rápidamente un producto al catálogo</p>
                </div>

                <div class="action-card" onclick="location.href='ordenes.php?filter=pending'">
                    <div class="icon">
                        <i class="fas fa-hourglass-half"></i>
                    </div>
                    <h3>Órdenes Pendientes</h3>
                    <p>Ver pedidos que requieren atención</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Auto-refresh stats every 5 minutes
        setInterval(() => {
            location.reload();
        }, 300000);

        // Welcome message
        console.log('🤠 ¡Bienvenido al Panel Admin de Charolais!');
    </script>
</body>
</html> 