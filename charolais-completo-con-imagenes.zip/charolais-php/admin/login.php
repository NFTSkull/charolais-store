<?php
// 🚀 CHAROLAIS - LOGIN ADMIN
// =========================
require_once '../config.php';

// Si ya está logueado, redirigir
if (isAdminLoggedIn()) {
    header('Location: index.php');
    exit;
}

$error = '';
$success = '';

// Procesar login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    
    if (empty($password)) {
        $error = 'Por favor ingresa la contraseña';
    } elseif ($password === ADMIN_PASSWORD) {
        session_start();
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_login_time'] = time();
        
        // Log del acceso
        logError("Admin login exitoso desde IP: " . $_SERVER['REMOTE_ADDR']);
        
        header('Location: index.php');
        exit;
    } else {
        $error = 'Contraseña incorrecta';
        logError("Intento de login fallido desde IP: " . $_SERVER['REMOTE_ADDR']);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤠 Admin Login - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .login-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 50px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 450px;
            text-align: center;
            backdrop-filter: blur(10px);
        }

        .logo {
            font-size: 5em;
            color: #8B4513;
            margin-bottom: 20px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
        }

        .title {
            color: #8B4513;
            font-size: 2.5em;
            font-weight: bold;
            margin-bottom: 10px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }

        .subtitle {
            color: #666;
            font-size: 1.2em;
            margin-bottom: 40px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .form-group {
            margin-bottom: 30px;
            text-align: left;
        }

        .form-group label {
            display: block;
            color: #333;
            font-weight: bold;
            margin-bottom: 10px;
            font-size: 1.1em;
        }

        .form-group input {
            width: 100%;
            padding: 15px 20px;
            border: 2px solid #ddd;
            border-radius: 10px;
            font-size: 1.1em;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.9);
        }

        .form-group input:focus {
            border-color: #8B4513;
            outline: none;
            box-shadow: 0 0 10px rgba(139, 69, 19, 0.3);
            background: white;
        }

        .login-btn {
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.2em;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .login-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(139, 69, 19, 0.4);
        }

        .login-btn:active {
            transform: translateY(0);
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .alert.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .footer {
            margin-top: 40px;
            color: #666;
            font-size: 0.9em;
        }

        .footer a {
            color: #8B4513;
            text-decoration: none;
            font-weight: bold;
        }

        .footer a:hover {
            text-decoration: underline;
        }

        .security-info {
            background: rgba(139, 69, 19, 0.1);
            padding: 20px;
            border-radius: 10px;
            margin-top: 30px;
            border-left: 4px solid #8B4513;
        }

        .security-info h4 {
            color: #8B4513;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .security-info p {
            color: #666;
            font-size: 0.9em;
            line-height: 1.5;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 30px 20px;
            }

            .logo {
                font-size: 4em;
            }

            .title {
                font-size: 2em;
            }

            .subtitle {
                font-size: 1em;
            }
        }

        /* Animaciones */
        .login-container {
            animation: slideIn 0.5s ease-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <!-- Logo y título -->
        <div class="logo">
            <i class="fas fa-hat-cowboy"></i>
        </div>
        <h1 class="title">Charolais</h1>
        <p class="subtitle">Panel de Administración</p>

        <!-- Alertas -->
        <?php if ($error): ?>
        <div class="alert error">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>

        <?php if ($success): ?>
        <div class="alert success">
            <i class="fas fa-check-circle"></i>
            <?php echo htmlspecialchars($success); ?>
        </div>
        <?php endif; ?>

        <!-- Formulario de login -->
        <form method="POST" action="">
            <div class="form-group">
                <label for="password">
                    <i class="fas fa-lock"></i> Contraseña de Administrador
                </label>
                <input type="password" 
                       id="password" 
                       name="password" 
                       placeholder="Ingresa tu contraseña"
                       required
                       autocomplete="current-password">
            </div>

            <button type="submit" class="login-btn">
                <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
            </button>
        </form>

        <!-- Información de seguridad -->
        <div class="security-info">
            <h4>
                <i class="fas fa-shield-alt"></i>
                Acceso Seguro
            </h4>
            <p>
                Este panel está protegido. Todos los intentos de acceso son registrados. 
                Si olvidaste tu contraseña, contacta al desarrollador.
            </p>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>
                <a href="<?php echo SITE_URL; ?>">
                    <i class="fas fa-arrow-left"></i> Volver a la tienda
                </a>
            </p>
            <p style="margin-top: 10px;">
                <small>© <?php echo date('Y'); ?> <?php echo SITE_NAME; ?></small>
            </p>
        </div>
    </div>

    <script>
        // Auto-focus en el campo de contraseña
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('password').focus();
        });

        // Manejar Enter en el formulario
        document.getElementById('password').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                this.closest('form').submit();
            }
        });

        // Mensaje de bienvenida en consola
        console.log('🤠 Sistema de administración Charolais');
        console.log('🔒 Acceso restringido solo para administradores');
    </script>
</body>
</html> 