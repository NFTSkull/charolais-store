<?php
// 🚀 CHAROLAIS - API DE PRODUCTOS (PHP)
// ===================================
require_once '../config.php';

// Manejar CORS y métodos HTTP
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Obtener método y parámetros
$method = $_SERVER['REQUEST_METHOD'];
$path = $_SERVER['REQUEST_URI'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    $db = Database::getInstance()->getConnection();

    switch ($method) {
        case 'GET':
            handleGet($db);
            break;
        case 'POST':
            handlePost($db, $input);
            break;
        case 'PUT':
            handlePut($db, $input);
            break;
        case 'DELETE':
            handleDelete($db);
            break;
        default:
            jsonResponse(['error' => 'Método no permitido'], 405);
    }
} catch (Exception $e) {
    logError("Error en API productos: " . $e->getMessage());
    jsonResponse(['error' => 'Error interno del servidor'], 500);
}

// ==========================================
// 📋 GET - OBTENER PRODUCTOS
// ==========================================
function handleGet($db) {
    $action = $_GET['action'] ?? 'list';

    switch ($action) {
        case 'list':
            getProductsList($db);
            break;
        case 'detail':
            getProductDetail($db);
            break;
        case 'variants':
            getProductVariants($db);
            break;
        case 'search':
            searchProducts($db);
            break;
        default:
            jsonResponse(['error' => 'Acción no válida'], 400);
    }
}

function getProductsList($db) {
    $query = "
        SELECT 
            p.id,
            p.name,
            p.description,
            p.price,
            p.image_url,
            p.category,
            p.has_variants,
            p.stock_quantity,
            p.featured,
            COALESCE(SUM(pv.stock_quantity), p.stock_quantity) as total_stock
        FROM products p
        LEFT JOIN product_variants pv ON p.id = pv.product_id AND pv.is_active = 1
        WHERE p.is_active = 1
        GROUP BY p.id
        ORDER BY p.featured DESC, p.name ASC
    ";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    $products = $stmt->fetchAll();

    // Obtener variantes para productos que las tienen
    foreach ($products as &$product) {
        if ($product['has_variants']) {
            $product['variants'] = getVariantsForProduct($db, $product['id']);
        }
    }

    jsonResponse(['products' => $products]);
}

function getProductDetail($db) {
    $id = $_GET['id'] ?? null;
    if (!$id) {
        jsonResponse(['error' => 'ID de producto requerido'], 400);
    }

    $query = "
        SELECT 
            p.*,
            COALESCE(SUM(pv.stock_quantity), p.stock_quantity) as total_stock
        FROM products p
        LEFT JOIN product_variants pv ON p.id = pv.product_id AND pv.is_active = 1
        WHERE p.id = ? AND p.is_active = 1
        GROUP BY p.id
    ";
    
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);
    $product = $stmt->fetch();

    if (!$product) {
        jsonResponse(['error' => 'Producto no encontrado'], 404);
    }

    // Obtener variantes si las tiene
    if ($product['has_variants']) {
        $product['variants'] = getVariantsForProduct($db, $product['id']);
    }

    jsonResponse(['product' => $product]);
}

function getProductVariants($db) {
    $productId = $_GET['product_id'] ?? null;
    if (!$productId) {
        jsonResponse(['error' => 'ID de producto requerido'], 400);
    }

    $variants = getVariantsForProduct($db, $productId);
    jsonResponse(['variants' => $variants]);
}

function getVariantsForProduct($db, $productId) {
    $query = "
        SELECT 
            pv.id,
            pv.variant_name,
            pv.price,
            pv.stock_quantity,
            pv.sku,
            GROUP_CONCAT(
                CONCAT(va.attribute_name, ':', va.attribute_value) 
                SEPARATOR ';'
            ) as attributes
        FROM product_variants pv
        LEFT JOIN variant_attributes va ON pv.id = va.variant_id
        WHERE pv.product_id = ? AND pv.is_active = 1
        GROUP BY pv.id
        ORDER BY pv.variant_name
    ";
    
    $stmt = $db->prepare($query);
    $stmt->execute([$productId]);
    $variants = $stmt->fetchAll();

    // Procesar atributos
    foreach ($variants as &$variant) {
        $variant['attributes'] = [];
        if ($variant['attributes']) {
            $attrs = explode(';', $variant['attributes']);
            foreach ($attrs as $attr) {
                if (strpos($attr, ':') !== false) {
                    list($name, $value) = explode(':', $attr, 2);
                    $variant['attributes'][$name] = $value;
                }
            }
        }
    }

    return $variants;
}

function searchProducts($db) {
    $query = $_GET['q'] ?? '';
    $category = $_GET['category'] ?? '';
    
    $sql = "
        SELECT 
            p.id,
            p.name,
            p.description,
            p.price,
            p.image_url,
            p.category,
            p.has_variants,
            COALESCE(SUM(pv.stock_quantity), p.stock_quantity) as total_stock
        FROM products p
        LEFT JOIN product_variants pv ON p.id = pv.product_id AND pv.is_active = 1
        WHERE p.is_active = 1
    ";
    
    $params = [];
    
    if ($query) {
        $sql .= " AND (p.name LIKE ? OR p.description LIKE ?)";
        $params[] = "%$query%";
        $params[] = "%$query%";
    }
    
    if ($category) {
        $sql .= " AND p.category = ?";
        $params[] = $category;
    }
    
    $sql .= " GROUP BY p.id ORDER BY p.featured DESC, p.name ASC";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll();
    
    jsonResponse(['products' => $products]);
}

// ==========================================
// ➕ POST - CREAR PRODUCTO
// ==========================================
function handlePost($db, $input) {
    $action = $input['action'] ?? 'create';

    switch ($action) {
        case 'create':
            createProduct($db, $input);
            break;
        case 'create_variant':
            createVariant($db, $input);
            break;
        default:
            jsonResponse(['error' => 'Acción no válida'], 400);
    }
}

function createProduct($db, $input) {
    // Validar datos requeridos
    $required = ['name', 'price'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            jsonResponse(['error' => "Campo $field es requerido"], 400);
        }
    }

    $query = "
        INSERT INTO products (name, description, price, image_url, category, has_variants, stock_quantity, featured)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ";
    
    $params = [
        $input['name'],
        $input['description'] ?? '',
        $input['price'],
        $input['image_url'] ?? '',
        $input['category'] ?? 'General',
        $input['has_variants'] ?? 0,
        $input['stock_quantity'] ?? 0,
        $input['featured'] ?? 0
    ];
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    
    $productId = $db->lastInsertId();
    
    jsonResponse([
        'success' => true,
        'message' => 'Producto creado exitosamente',
        'product_id' => $productId
    ]);
}

function createVariant($db, $input) {
    $required = ['product_id', 'variant_name', 'price', 'stock_quantity'];
    foreach ($required as $field) {
        if (!isset($input[$field])) {
            jsonResponse(['error' => "Campo $field es requerido"], 400);
        }
    }

    // Crear variante
    $query = "
        INSERT INTO product_variants (product_id, variant_name, price, stock_quantity, sku)
        VALUES (?, ?, ?, ?, ?)
    ";
    
    $sku = $input['sku'] ?? generateId(10);
    
    $stmt = $db->prepare($query);
    $stmt->execute([
        $input['product_id'],
        $input['variant_name'],
        $input['price'],
        $input['stock_quantity'],
        $sku
    ]);
    
    $variantId = $db->lastInsertId();
    
    // Agregar atributos si existen
    if (isset($input['attributes']) && is_array($input['attributes'])) {
        foreach ($input['attributes'] as $name => $value) {
            $attrQuery = "INSERT INTO variant_attributes (variant_id, attribute_name, attribute_value) VALUES (?, ?, ?)";
            $attrStmt = $db->prepare($attrQuery);
            $attrStmt->execute([$variantId, $name, $value]);
        }
    }
    
    // Marcar producto como que tiene variantes
    $updateQuery = "UPDATE products SET has_variants = 1 WHERE id = ?";
    $updateStmt = $db->prepare($updateQuery);
    $updateStmt->execute([$input['product_id']]);
    
    jsonResponse([
        'success' => true,
        'message' => 'Variante creada exitosamente',
        'variant_id' => $variantId
    ]);
}

// ==========================================
// ✏️ PUT - ACTUALIZAR PRODUCTO
// ==========================================
function handlePut($db, $input) {
    $action = $input['action'] ?? 'update';

    switch ($action) {
        case 'update':
            updateProduct($db, $input);
            break;
        case 'update_variant':
            updateVariant($db, $input);
            break;
        case 'update_stock':
            updateStock($db, $input);
            break;
        default:
            jsonResponse(['error' => 'Acción no válida'], 400);
    }
}

function updateProduct($db, $input) {
    $id = $input['id'] ?? null;
    if (!$id) {
        jsonResponse(['error' => 'ID de producto requerido'], 400);
    }

    $fields = [];
    $params = [];
    
    $allowedFields = ['name', 'description', 'price', 'image_url', 'category', 'stock_quantity', 'featured', 'is_active'];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $fields[] = "$field = ?";
            $params[] = $input[$field];
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['error' => 'No hay campos para actualizar'], 400);
    }
    
    $params[] = $id;
    
    $query = "UPDATE products SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    
    jsonResponse([
        'success' => true,
        'message' => 'Producto actualizado exitosamente'
    ]);
}

function updateVariant($db, $input) {
    $id = $input['id'] ?? null;
    if (!$id) {
        jsonResponse(['error' => 'ID de variante requerido'], 400);
    }

    $fields = [];
    $params = [];
    
    $allowedFields = ['variant_name', 'price', 'stock_quantity', 'is_active'];
    
    foreach ($allowedFields as $field) {
        if (isset($input[$field])) {
            $fields[] = "$field = ?";
            $params[] = $input[$field];
        }
    }
    
    if (empty($fields)) {
        jsonResponse(['error' => 'No hay campos para actualizar'], 400);
    }
    
    $params[] = $id;
    
    $query = "UPDATE product_variants SET " . implode(', ', $fields) . " WHERE id = ?";
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    
    jsonResponse([
        'success' => true,
        'message' => 'Variante actualizada exitosamente'
    ]);
}

function updateStock($db, $input) {
    $variantId = $input['variant_id'] ?? null;
    $productId = $input['product_id'] ?? null;
    $quantity = $input['quantity'] ?? null;
    
    if (!$quantity || (!$variantId && !$productId)) {
        jsonResponse(['error' => 'Parámetros insuficientes'], 400);
    }
    
    if ($variantId) {
        $query = "UPDATE product_variants SET stock_quantity = stock_quantity - ? WHERE id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$quantity, $variantId]);
    } else {
        $query = "UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?";
        $stmt = $db->prepare($query);
        $stmt->execute([$quantity, $productId]);
    }
    
    jsonResponse([
        'success' => true,
        'message' => 'Stock actualizado exitosamente'
    ]);
}

// ==========================================
// 🗑️ DELETE - ELIMINAR PRODUCTO
// ==========================================
function handleDelete($db) {
    $id = $_GET['id'] ?? null;
    $type = $_GET['type'] ?? 'product';
    
    if (!$id) {
        jsonResponse(['error' => 'ID requerido'], 400);
    }
    
    if ($type === 'variant') {
        $query = "UPDATE product_variants SET is_active = 0 WHERE id = ?";
        $message = 'Variante eliminada exitosamente';
    } else {
        $query = "UPDATE products SET is_active = 0 WHERE id = ?";
        $message = 'Producto eliminado exitosamente';
    }
    
    $stmt = $db->prepare($query);
    $stmt->execute([$id]);
    
    jsonResponse([
        'success' => true,
        'message' => $message
    ]);
}

?> 