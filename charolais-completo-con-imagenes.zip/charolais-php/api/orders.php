<?php
// 🚀 CHAROLAIS - API DE ÓRDENES (PHP)
// ==================================
require_once '../config.php';

// Manejar CORS y métodos HTTP
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Obtener método y parámetros
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

try {
    $db = Database::getInstance()->getConnection();

    switch ($method) {
        case 'GET':
            handleGet($db);
            break;
        case 'POST':
            handlePost($db, $input);
            break;
        case 'PUT':
            handlePut($db, $input);
            break;
        default:
            jsonResponse(['error' => 'Método no permitido'], 405);
    }
} catch (Exception $e) {
    logError("Error en API órdenes: " . $e->getMessage());
    jsonResponse(['error' => 'Error interno del servidor'], 500);
}

// ==========================================
// 📋 GET - OBTENER ÓRDENES
// ==========================================
function handleGet($db) {
    $action = $_GET['action'] ?? 'list';

    switch ($action) {
        case 'list':
            getOrdersList($db);
            break;
        case 'detail':
            getOrderDetail($db);
            break;
        case 'stats':
            getOrderStats($db);
            break;
        default:
            jsonResponse(['error' => 'Acción no válida'], 400);
    }
}

function getOrdersList($db) {
    $filter = $_GET['filter'] ?? '';
    $limit = intval($_GET['limit'] ?? 50);
    
    $whereClause = '';
    $params = [];
    
    if ($filter) {
        switch ($filter) {
            case 'pending':
                $whereClause = 'WHERE status = ?';
                $params[] = 'pending';
                break;
            case 'completed':
                $whereClause = 'WHERE status = ?';
                $params[] = 'completed';
                break;
            case 'today':
                $whereClause = 'WHERE DATE(created_at) = CURDATE()';
                break;
            case 'week':
                $whereClause = 'WHERE created_at >= DATE_SUB(NOW(), INTERVAL 1 WEEK)';
                break;
        }
    }
    
    $query = "
        SELECT 
            id,
            stripe_session_id,
            customer_email,
            customer_name,
            total_amount,
            status,
            shipping_address,
            created_at,
            updated_at
        FROM orders 
        $whereClause
        ORDER BY created_at DESC 
        LIMIT ?
    ";
    
    $params[] = $limit;
    
    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $orders = $stmt->fetchAll();

    // Obtener items para cada orden
    foreach ($orders as &$order) {
        $order['items'] = getOrderItems($db, $order['id']);
        $order['formatted_total'] = formatPrice($order['total_amount']);
        $order['formatted_date'] = date('d/m/Y H:i', strtotime($order['created_at']));
    }

    jsonResponse(['orders' => $orders]);
}

function getOrderDetail($db) {
    $id = $_GET['id'] ?? null;
    if (!$id) {
        jsonResponse(['error' => 'ID de orden requerido'], 400);
    }

    $stmt = $db->prepare("SELECT * FROM orders WHERE id = ?");
    $stmt->execute([$id]);
    $order = $stmt->fetch();

    if (!$order) {
        jsonResponse(['error' => 'Orden no encontrada'], 404);
    }

    // Obtener items
    $order['items'] = getOrderItems($db, $order['id']);
    
    // Formatear datos
    $order['formatted_total'] = formatPrice($order['total_amount']);
    $order['formatted_date'] = date('d/m/Y H:i', strtotime($order['created_at']));
    
    // Decodificar dirección si está en JSON
    if ($order['shipping_address'] && is_string($order['shipping_address'])) {
        $order['shipping_address'] = json_decode($order['shipping_address'], true);
    }

    jsonResponse(['order' => $order]);
}

function getOrderItems($db, $orderId) {
    $stmt = $db->prepare("
        SELECT 
            oi.*,
            p.name as product_name,
            p.image_url as product_image
        FROM order_items oi
        LEFT JOIN products p ON oi.product_id = p.id
        WHERE oi.order_id = ?
        ORDER BY oi.id
    ");
    $stmt->execute([$orderId]);
    $items = $stmt->fetchAll();
    
    foreach ($items as &$item) {
        $item['formatted_price'] = formatPrice($item['price']);
        $item['formatted_total'] = formatPrice($item['price'] * $item['quantity']);
    }
    
    return $items;
}

function getOrderStats($db) {
    // Órdenes del día
    $stmt = $db->query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()");
    $todayOrders = $stmt->fetch()['count'];

    // Ventas del día
    $stmt = $db->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM orders WHERE DATE(created_at) = CURDATE() AND status = 'completed'");
    $todaySales = $stmt->fetch()['total'];

    // Órdenes pendientes
    $stmt = $db->query("SELECT COUNT(*) as count FROM orders WHERE status = 'pending'");
    $pendingOrders = $stmt->fetch()['count'];

    // Órdenes del mes
    $stmt = $db->query("SELECT COUNT(*) as count FROM orders WHERE MONTH(created_at) = MONTH(NOW()) AND YEAR(created_at) = YEAR(NOW())");
    $monthOrders = $stmt->fetch()['count'];

    jsonResponse([
        'stats' => [
            'today_orders' => $todayOrders,
            'today_sales' => $todaySales,
            'pending_orders' => $pendingOrders,
            'month_orders' => $monthOrders,
            'formatted_today_sales' => formatPrice($todaySales)
        ]
    ]);
}

// ==========================================
// ➕ POST - CREAR ORDEN / WEBHOOK
// ==========================================
function handlePost($db, $input) {
    $action = $input['action'] ?? $_GET['action'] ?? 'create';

    switch ($action) {
        case 'create':
            createOrder($db, $input);
            break;
        case 'webhook':
            handleStripeWebhook($db);
            break;
        default:
            jsonResponse(['error' => 'Acción no válida'], 400);
    }
}

function createOrder($db, $input) {
    // Validar datos requeridos
    $required = ['stripe_session_id', 'customer_email', 'total_amount', 'items'];
    foreach ($required as $field) {
        if (!isset($input[$field]) || empty($input[$field])) {
            jsonResponse(['error' => "Campo $field es requerido"], 400);
        }
    }

    try {
        $db->beginTransaction();

        // Crear orden
        $stmt = $db->prepare("
            INSERT INTO orders (
                stripe_session_id, 
                customer_email, 
                customer_name, 
                total_amount, 
                status, 
                shipping_address,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, NOW())
        ");

        $shippingAddress = isset($input['shipping_address']) ? json_encode($input['shipping_address']) : null;
        
        $stmt->execute([
            $input['stripe_session_id'],
            $input['customer_email'],
            $input['customer_name'] ?? '',
            $input['total_amount'],
            'pending',
            $shippingAddress
        ]);

        $orderId = $db->lastInsertId();

        // Crear items de la orden
        foreach ($input['items'] as $item) {
            $stmt = $db->prepare("
                INSERT INTO order_items (
                    order_id, 
                    product_id, 
                    variant_id, 
                    quantity, 
                    price, 
                    product_name,
                    variant_name
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $orderId,
                $item['product_id'],
                $item['variant_id'] ?? null,
                $item['quantity'],
                $item['price'],
                $item['product_name'] ?? '',
                $item['variant_name'] ?? ''
            ]);

            // Actualizar stock
            if (isset($item['variant_id']) && $item['variant_id']) {
                $stmt = $db->prepare("UPDATE product_variants SET stock_quantity = stock_quantity - ? WHERE id = ?");
                $stmt->execute([$item['quantity'], $item['variant_id']]);
            } else {
                $stmt = $db->prepare("UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?");
                $stmt->execute([$item['quantity'], $item['product_id']]);
            }
        }

        $db->commit();

        // Enviar notificación
        sendOrderNotification($orderId, $input);

        jsonResponse(['success' => true, 'order_id' => $orderId]);

    } catch (Exception $e) {
        $db->rollBack();
        logError("Error creando orden: " . $e->getMessage());
        jsonResponse(['error' => 'Error al crear la orden'], 500);
    }
}

function handleStripeWebhook($db) {
    $payload = file_get_contents('php://input');
    $sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

    // Verificar webhook de Stripe
    try {
        // Aquí normalmente verificarías la firma del webhook
        // Por simplicidad, procesamos directamente
        $event = json_decode($payload, true);

        switch ($event['type']) {
            case 'checkout.session.completed':
                handleCheckoutCompleted($db, $event['data']['object']);
                break;
            case 'payment_intent.succeeded':
                handlePaymentSucceeded($db, $event['data']['object']);
                break;
        }

        jsonResponse(['received' => true]);

    } catch (Exception $e) {
        logError("Error en webhook: " . $e->getMessage());
        jsonResponse(['error' => 'Error procesando webhook'], 400);
    }
}

function handleCheckoutCompleted($db, $session) {
    $stmt = $db->prepare("UPDATE orders SET status = 'completed' WHERE stripe_session_id = ?");
    $stmt->execute([$session['id']]);

    // Log de la transacción completada
    logError("Orden completada: " . $session['id']);
}

function handlePaymentSucceeded($db, $paymentIntent) {
    // Lógica adicional para pagos exitosos
    logError("Pago exitoso: " . $paymentIntent['id']);
}

// ==========================================
// 🔄 PUT - ACTUALIZAR ORDEN
// ==========================================
function handlePut($db, $input) {
    $action = $input['action'] ?? 'update_status';

    switch ($action) {
        case 'update_status':
            updateOrderStatus($db, $input);
            break;
        default:
            jsonResponse(['error' => 'Acción no válida'], 400);
    }
}

function updateOrderStatus($db, $input) {
    $orderId = $input['order_id'] ?? null;
    $status = $input['status'] ?? null;

    if (!$orderId || !$status) {
        jsonResponse(['error' => 'ID de orden y estado son requeridos'], 400);
    }

    $validStatuses = ['pending', 'processing', 'shipped', 'completed', 'cancelled'];
    if (!in_array($status, $validStatuses)) {
        jsonResponse(['error' => 'Estado no válido'], 400);
    }

    $stmt = $db->prepare("UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?");
    
    if ($stmt->execute([$status, $orderId])) {
        jsonResponse(['success' => true, 'message' => 'Estado actualizado']);
    } else {
        jsonResponse(['error' => 'Error al actualizar el estado'], 500);
    }
}

// ==========================================
// 🔔 NOTIFICACIONES
// ==========================================
function sendOrderNotification($orderId, $orderData) {
    $subject = "🤠 Nueva Orden #$orderId - " . SITE_NAME;
    
    $message = "
        <h3>¡Nueva orden recibida!</h3>
        <p><strong>Orden #:</strong> $orderId</p>
        <p><strong>Cliente:</strong> {$orderData['customer_email']}</p>
        <p><strong>Total:</strong> " . formatPrice($orderData['total_amount']) . "</p>
        <p><strong>Fecha:</strong> " . date('d/m/Y H:i') . "</p>
        
        <h4>Productos:</h4>
        <ul>
    ";
    
    foreach ($orderData['items'] as $item) {
        $message .= "<li>{$item['product_name']} x {$item['quantity']} - " . formatPrice($item['price']) . "</li>";
    }
    
    $message .= "
        </ul>
        <p><a href='" . SITE_URL . "/admin/ordenes.php?id=$orderId'>Ver orden completa</a></p>
    ";
    
    sendNotificationEmail($subject, $message);
}

?> 