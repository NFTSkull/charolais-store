<?php
// 🚀 CHAROLAIS - STRIPE CHECKOUT API
// =================================
require_once '../config.php';

// Headers CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Método no permitido'], 405);
}

// Obtener datos del carrito
$input = json_decode(file_get_contents('php://input'), true);
$cart = $input['cart'] ?? [];

if (empty($cart)) {
    jsonResponse(['error' => 'Carrito vacío'], 400);
}

try {
    // Verificar productos y calcular total
    $db = Database::getInstance()->getConnection();
    $lineItems = [];
    $total = 0;

    foreach ($cart as $item) {
        // Verificar que el producto existe y tiene stock
        $stmt = $db->prepare("SELECT * FROM products WHERE id = ? AND is_active = 1");
        $stmt->execute([$item['id']]);
        $product = $stmt->fetch();

        if (!$product) {
            jsonResponse(['error' => "Producto {$item['id']} no encontrado"], 400);
        }

        if ($product['stock_quantity'] < $item['quantity']) {
            jsonResponse(['error' => "Stock insuficiente para {$product['name']}"], 400);
        }

        // Agregar al checkout de Stripe
        $lineItems[] = [
            'price_data' => [
                'currency' => 'mxn',
                'product_data' => [
                    'name' => $product['name'],
                    'description' => $product['description'] ?? '',
                    'images' => $product['image_url'] ? [SITE_URL . '/' . $product['image_url']] : [],
                    'metadata' => [
                        'product_id' => $product['id'],
                        'category' => $product['category']
                    ]
                ],
                'unit_amount' => intval($product['price'] * 100), // Stripe usa centavos
            ],
            'quantity' => intval($item['quantity']),
        ];

        $total += $product['price'] * $item['quantity'];
    }

    // Crear sesión de Stripe Checkout
    $stripeData = [
        'payment_method_types' => ['card'],
        'line_items' => $lineItems,
        'mode' => 'payment',
        'success_url' => SITE_URL . '/success.php?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => SITE_URL . '/index.php',
        'metadata' => [
            'source' => 'charolais_store',
            'total_items' => count($cart),
            'total_amount' => $total
        ],
        'shipping_address_collection' => [
            'allowed_countries' => ['MX'],
        ],
        'billing_address_collection' => 'required',
        'phone_number_collection' => [
            'enabled' => true,
        ],
        'customer_email' => null, // Se pedirá en el checkout
    ];

    // Llamar a Stripe API
    $response = createStripeSession($stripeData);

    if ($response['success']) {
        jsonResponse([
            'id' => $response['session_id'],
            'url' => $response['url']
        ]);
    } else {
        jsonResponse(['error' => $response['error']], 400);
    }

} catch (Exception $e) {
    logError("Error en checkout: " . $e->getMessage());
    jsonResponse(['error' => 'Error interno del servidor'], 500);
}

function createStripeSession($data) {
    // Simular llamada a Stripe API
    // En producción, aquí usarías la librería oficial de Stripe
    
    $stripeUrl = 'https://api.stripe.com/v1/checkout/sessions';
    
    $headers = [
        'Authorization: Bearer ' . STRIPE_SECRET_KEY,
        'Content-Type: application/x-www-form-urlencoded'
    ];

    // Convertir datos a formato form-encoded para Stripe
    $postData = buildStripeParams($data);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $stripeUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        logError("cURL Error: " . $error);
        return ['success' => false, 'error' => 'Error de conexión con Stripe'];
    }

    $responseData = json_decode($response, true);

    if ($httpCode === 200 && isset($responseData['id'])) {
        return [
            'success' => true,
            'session_id' => $responseData['id'],
            'url' => $responseData['url']
        ];
    } else {
        $errorMsg = $responseData['error']['message'] ?? 'Error desconocido de Stripe';
        logError("Stripe Error: " . $errorMsg);
        return ['success' => false, 'error' => $errorMsg];
    }
}

function buildStripeParams($data, $prefix = '') {
    $params = [];
    
    foreach ($data as $key => $value) {
        $fullKey = $prefix ? $prefix . '[' . $key . ']' : $key;
        
        if (is_array($value)) {
            if (array_keys($value) === range(0, count($value) - 1)) {
                // Array indexado
                foreach ($value as $index => $item) {
                    if (is_array($item)) {
                        foreach (buildStripeParams($item, $fullKey . '[' . $index . ']') as $k => $v) {
                            $params[] = $k . '=' . urlencode($v);
                        }
                    } else {
                        $params[] = $fullKey . '[' . $index . ']=' . urlencode($item);
                    }
                }
            } else {
                // Array asociativo
                foreach (buildStripeParams($value, $fullKey) as $k => $v) {
                    $params[] = $k . '=' . urlencode($v);
                }
            }
        } else {
            $params[] = $fullKey . '=' . urlencode($value);
        }
    }
    
    return $prefix ? $params : implode('&', $params);
}

?> 