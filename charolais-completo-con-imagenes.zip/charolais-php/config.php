<?php
// 🚀 CHAROLAIS - CONFIGURACIÓN PRINCIPAL
// =====================================

// 🔒 CONFIGURACIÓN DE BASE DE DATOS
// Cambiar por tus credenciales de cPanel
define('DB_HOST', 'localhost');
define('DB_NAME', 'tu_usuario_charolais'); // Cambiar por tu base de datos
define('DB_USER', 'tu_usuario_mysql');     // Cambiar por tu usuario MySQL
define('DB_PASS', 'tu_contraseña_mysql');  // Cambiar por tu contraseña

// 💳 CONFIGURACIÓN DE STRIPE
// Cambiar por tus claves reales de Stripe
define('STRIPE_SECRET_KEY', 'sk_test_tu_clave_secreta_stripe');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_tu_clave_publica_stripe');
define('STRIPE_WEBHOOK_SECRET', 'whsec_tu_webhook_secret');

// 🌐 CONFIGURACIÓN DEL SITIO
define('SITE_URL', 'https://tudominio.com'); // Cambiar por tu dominio real
define('ADMIN_PASSWORD', 'admin123');         // Cambiar por contraseña segura

// 📧 CONFIGURACIÓN DE NOTIFICACIONES
define('ADMIN_EMAIL', 'tu@email.com');       // Email para recibir notificaciones
define('SITE_NAME', 'Charolais Store');

// 🔄 CONFIGURACIÓN DE INVENTARIO
define('LOW_STOCK_ALERT', 5); // Alerta cuando stock esté por debajo de 5

// 🗂️ CONFIGURACIÓN DE ARCHIVOS
define('UPLOAD_DIR', 'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB máximo por imagen

// 🔧 CONFIGURACIÓN DE DEBUG
define('DEBUG_MODE', false); // Cambiar a false en producción

// ==========================================
// 🔗 CONEXIÓN A BASE DE DATOS
// ==========================================
class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
        } catch (PDOException $e) {
            if (DEBUG_MODE) {
                die("Error de conexión: " . $e->getMessage());
            } else {
                die("Error de conexión a la base de datos.");
            }
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }
}

// ==========================================
// 🛠️ FUNCIONES ÚTILES
// ==========================================

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function logError($message) {
    if (DEBUG_MODE) {
        error_log(date('Y-m-d H:i:s') . " - " . $message . PHP_EOL, 3, 'debug.log');
    }
}

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function generateId($length = 10) {
    return substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, $length);
}

function formatPrice($price) {
    return '$' . number_format($price, 0, '.', ',');
}

function sendNotificationEmail($subject, $message) {
    $headers = "From: " . SITE_NAME . " <noreply@" . parse_url(SITE_URL, PHP_URL_HOST) . ">" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    
    $fullMessage = "
    <html>
    <head><title>$subject</title></head>
    <body>
        <h2>🤠 " . SITE_NAME . "</h2>
        <div>$message</div>
        <hr>
        <small>Enviado automáticamente desde " . SITE_URL . "</small>
    </body>
    </html>";
    
    return mail(ADMIN_EMAIL, $subject, $fullMessage, $headers);
}

// ==========================================
// 🔐 VERIFICACIÓN DE ADMIN
// ==========================================
function checkAdminAuth() {
    session_start();
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        header('Location: login.php');
        exit;
    }
}

function isAdminLoggedIn() {
    session_start();
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// ==========================================
// 🎯 INICIALIZACIÓN
// ==========================================
// Verificar conexión al cargar
try {
    $db = Database::getInstance();
    if (DEBUG_MODE) {
        logError("Conexión a base de datos establecida correctamente");
    }
} catch (Exception $e) {
    if (DEBUG_MODE) {
        logError("Error al conectar con la base de datos: " . $e->getMessage());
    }
}

// Establecer zona horaria
date_default_timezone_set('America/Mexico_City');

?> 