# 🚀 INSTALACIÓN SÚPER FÁCIL - CHAROLAIS cPANEL

## 📦 **ARCHIVOS QUE DEBES SUBIR**

**Sube TODA la carpeta `charolais-php` a tu hosting**

---

## 🗄️ **PASO 1: CONFIGURAR BASE DE DATOS (SÚPER FÁCIL)**

### **1.1 Entrar a cPanel:**
1. Ve a tu hosting y busca **"cPanel"**
2. Haz clic en **"Bases de datos MySQL"** o **"MySQL Databases"**

### **1.2 Crear Base de Datos:**
1. En la sección **"Crear nueva base de datos"**
2. Escribe: `charolais` 
3. Haz clic en **"Crear base de datos"**
4. **¡APUNTA EL NOMBRE COMPLETO!** (será algo como: `tu_usuario_charolais`)

### **1.3 Crear Usuario:**
1. En la sección **"Agregar nuevo usuario"**
2. **Usuario:** `charolais_user`
3. **Contraseña:** Crea una contraseña fuerte
4. **¡APUNTA USUARIO Y CONTRASEÑA!**
5. Haz clic en **"Crear usuario"**

### **1.4 Asignar Usuario a Base de Datos:**
1. En **"Agregar usuario a base de datos"**
2. Selecciona el usuario y la base de datos que creaste
3. Marca **"TODOS LOS PRIVILEGIOS"**
4. Haz clic en **"Realizar cambios"**

### **1.5 Importar Datos:**
1. Ve a **"phpMyAdmin"** en cPanel
2. Selecciona tu base de datos `tu_usuario_charolais`
3. Haz clic en **"Importar"**
4. Selecciona el archivo `database.sql` 
5. Haz clic en **"Continuar"**
6. ¡Listo! Verás las tablas creadas

---

## ⚙️ **PASO 2: CONFIGURAR ARCHIVOS**

### **2.1 Editar config.php:**
1. Ve a **"Administrador de archivos"** en cPanel
2. Navega a `public_html/config.php`
3. Haz clic derecho → **"Editar"**
4. Cambia estas líneas:

```php
// 🔒 CONFIGURACIÓN DE BASE DE DATOS
define('DB_HOST', 'localhost');
define('DB_NAME', 'TU_USUARIO_charolais');     // ← CAMBIAR AQUÍ
define('DB_USER', 'TU_USUARIO_charolais_user'); // ← CAMBIAR AQUÍ  
define('DB_PASS', 'TU_CONTRASEÑA_AQUÍ');        // ← CAMBIAR AQUÍ

// 🌐 CONFIGURACIÓN DEL SITIO
define('SITE_URL', 'https://tudominio.com');    // ← CAMBIAR AQUÍ

// 🔒 CONTRASEÑA ADMIN
define('ADMIN_PASSWORD', 'mi_contraseña_segura'); // ← CAMBIAR AQUÍ

// 📧 EMAIL PARA NOTIFICACIONES
define('ADMIN_EMAIL', 'tu@email.com');           // ← CAMBIAR AQUÍ
```

5. **Guarda los cambios**

---

## 💳 **PASO 3: CONFIGURAR STRIPE (OPCIONAL AL INICIO)**

### **3.1 Obtener Claves de Stripe:**
1. Ve a [dashboard.stripe.com](https://dashboard.stripe.com)
2. Crea cuenta o inicia sesión
3. Ve a **"Desarrolladores" → "Claves API"**
4. Copia:
   - **Clave pública:** `pk_test_...`
   - **Clave secreta:** `sk_test_...`

### **3.2 Configurar en config.php:**
```php
// 💳 CONFIGURACIÓN DE STRIPE
define('STRIPE_SECRET_KEY', 'sk_test_TU_CLAVE_AQUI');
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_TU_CLAVE_AQUI');
```

### **3.3 Configurar Webhook (MÁS TARDE):**
- URL del webhook: `https://tudominio.com/api/orders.php?action=webhook`

---

## 📁 **PASO 4: SUBIR ARCHIVOS A cPANEL**

### **4.1 ¿Qué archivos subir?**
**Sube TODO el contenido de la carpeta `charolais-php/` a `public_html/`**

**Estructura final en tu hosting:**
```
public_html/
├── index.php              ← Página principal  
├── success.php            ← Página de éxito
├── config.php             ← Configuración (editar)
├── database.sql           ← Archivo de base de datos
├── admin/                 ← Panel de administración
│   ├── index.php
│   ├── login.php
│   ├── logout.php
│   └── productos.php
├── api/                   ← APIs del sistema
│   ├── products.php
│   ├── orders.php
│   └── stripe_checkout.php
├── uploads/               ← Carpeta para imágenes
└── TODAS_LAS_IMAGENES.jpg ← Copiar imágenes aquí
```

### **4.2 Método 1 - File Manager:**
1. Ve a **"Administrador de archivos"** en cPanel
2. Entra a la carpeta `public_html/`
3. **Sube TODOS los archivos** de `charolais-php/`
4. Si subes un ZIP, extráelo ahí mismo

### **4.3 Método 2 - FTP:**
1. Usa FileZilla o similar
2. Conecta a tu hosting
3. Sube todo a la carpeta `public_html/`

---

## 🖼️ **PASO 5: SUBIR IMÁGENES**

### **5.1 Copiar imágenes originales:**
Copia TODAS estas imágenes a la carpeta raíz:
- `Logo sin fondo.png`
- `Boutique mujer unitalla.JPG`
- `Boutique unitalla 1.JPG`
- `Accesorios.JPG`
- `Accesorios 2.JPG`
- `all arround.JPG`
- `all arround blanca.JPG`
- `Bronc Riding.JPG`
- `Bronc Riding 1.JPG`
- `CowGirls.JPG`
- `Cowboy Skull.JPG`
- `Cowboy Skull blanca.JPG`
- `Rodeo Clown.JPG`
- `Gorra.JPG`, `gorra 2.JPG`, etc.
- `Nueca Colección.JPG`

### **5.2 Ubicación:**
```
public_html/
├── Logo sin fondo.png     ← Aquí
├── Boutique mujer.JPG     ← Aquí  
├── Accesorios.JPG         ← Aquí
└── ... (todas las imágenes)
```

---

## 🎯 **PASO 6: PROBAR INSTALACIÓN**

### **6.1 Verificar sitio web:**
1. Ve a: `https://tudominio.com`
2. ¿Se ve la página? ✅
3. ¿Aparecen las imágenes? ✅

### **6.2 Verificar admin:**
1. Ve a: `https://tudominio.com/admin`
2. Inicia sesión con la contraseña que pusiste
3. ¿Funciona el panel? ✅

---

## ❌ **SOLUCIÓN A PROBLEMAS COMUNES**

### **Error: "No se puede conectar a la base de datos"**
- ✅ Verifica que el nombre de BD sea correcto
- ✅ Verifica usuario y contraseña
- ✅ Asegúrate que el usuario tenga permisos

### **Error: "Página no encontrada"**
- ✅ Verifica que los archivos estén en `public_html/`
- ✅ Verifica que `index.php` exista

### **No aparecen imágenes:**
- ✅ Sube las imágenes a la carpeta raíz
- ✅ Verifica nombres exactos de archivos

---

## 📞 **NECESITAS AYUDA?**

Si algo no funciona:
1. 📧 **Email:** Mándame screenshot del error
2. 🔍 **Revisar:** Ve a cPanel → "Registros de errores"
3. 📱 **WhatsApp:** [Tu número aquí]

---

**¡En 10 minutos tendrás tu tienda funcionando!** 🤠✨ 