<?php
// 🚀 CHAROLAIS - CONFIGURACIÓN DE EJEMPLO
// ======================================
// COPIA ESTE ARCHIVO COMO config.php Y EDITA TUS DATOS

// 🔒 CONFIGURACIÓN DE BASE DE DATOS
// ⚠️ CAMBIAR por tus datos reales de cPanel
define('DB_HOST', 'localhost');                      // Casi siempre es 'localhost'
define('DB_NAME', 'TU_USUARIO_charolais');           // ← CAMBIAR: Nombre completo de tu base de datos
define('DB_USER', 'TU_USUARIO_charolais_user');      // ← CAMBIAR: Usuario que creaste
define('DB_PASS', 'TU_CONTRASEÑA_MYSQL');            // ← CAMBIAR: Contraseña del usuario

// 💳 CONFIGURACIÓN DE STRIPE
// ⚠️ CAMBIAR por tus claves reales de Stripe (dashboard.stripe.com)
define('STRIPE_SECRET_KEY', 'sk_test_51ABC123...');       // ← CAMBIAR: Clave secreta
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_51ABC123...');  // ← CAMBIAR: Clave pública
define('STRIPE_WEBHOOK_SECRET', 'whsec_ABC123...');       // ← CAMBIAR: Secret del webhook

// 🌐 CONFIGURACIÓN DEL SITIO
// ⚠️ CAMBIAR por tu dominio real
define('SITE_URL', 'https://tudominio.com');         // ← CAMBIAR: Tu dominio real
define('ADMIN_PASSWORD', 'mi_contraseña_segura');    // ← CAMBIAR: Contraseña del admin
define('SITE_NAME', 'Charolais Store');

// 📧 CONFIGURACIÓN DE NOTIFICACIONES
// ⚠️ CAMBIAR por tu email real
define('ADMIN_EMAIL', 'tu@email.com');               // ← CAMBIAR: Tu email

// 🔄 CONFIGURACIÓN DE INVENTARIO
define('LOW_STOCK_ALERT', 5); // Alerta cuando stock esté por debajo de 5

// 🗂️ CONFIGURACIÓN DE ARCHIVOS
define('UPLOAD_DIR', 'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB máximo por imagen

// 🔧 CONFIGURACIÓN DE DEBUG
define('DEBUG_MODE', false); // Cambiar a false en producción

// ==========================================
// 🔗 CONEXIÓN A BASE DE DATOS
// ==========================================
class Database {
    private static $instance = null;
    private $connection;

    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $this->connection = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]);
        } catch (PDOException $e) {
            if (DEBUG_MODE) {
                die("Error de conexión: " . $e->getMessage());
            } else {
                die("Error de conexión a la base de datos.");
            }
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->connection;
    }
}

// ==========================================
// 🛠️ FUNCIONES ÚTILES
// ==========================================

function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function logError($message) {
    if (DEBUG_MODE) {
        error_log(date('Y-m-d H:i:s') . " - " . $message . PHP_EOL, 3, 'debug.log');
    }
}

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function generateId($length = 10) {
    return substr(str_shuffle('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'), 0, $length);
}

function formatPrice($price) {
    return '$' . number_format($price, 0, '.', ',');
}

function sendNotificationEmail($subject, $message) {
    $headers = "From: " . SITE_NAME . " <noreply@" . parse_url(SITE_URL, PHP_URL_HOST) . ">" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    
    $fullMessage = "
    <html>
    <head><title>$subject</title></head>
    <body>
        <h2>🤠 " . SITE_NAME . "</h2>
        <div>$message</div>
        <hr>
        <small>Enviado automáticamente desde " . SITE_URL . "</small>
    </body>
    </html>";
    
    return mail(ADMIN_EMAIL, $subject, $fullMessage, $headers);
}

// ==========================================
// 🔐 VERIFICACIÓN DE ADMIN
// ==========================================
function checkAdminAuth() {
    session_start();
    if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
        header('Location: login.php');
        exit;
    }
}

function isAdminLoggedIn() {
    session_start();
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// ==========================================
// 🎯 INICIALIZACIÓN
// ==========================================
// Verificar conexión al cargar
try {
    $db = Database::getInstance();
    if (DEBUG_MODE) {
        logError("Conexión a base de datos establecida correctamente");
    }
} catch (Exception $e) {
    if (DEBUG_MODE) {
        logError("Error al conectar con la base de datos: " . $e->getMessage());
    }
}

// Establecer zona horaria
date_default_timezone_set('America/Mexico_City');

?> 

<!-- 
🚀 INSTRUCCIONES RÁPIDAS:

1. 📝 RENOMBRAR este archivo a: config.php

2. ✏️ EDITAR las líneas marcadas con ← CAMBIAR

3. 🗄️ DATOS DE BASE DE DATOS:
   - Ve a cPanel → "Bases de datos MySQL"
   - El nombre será algo como: tu_usuario_charolais
   - Usuario será algo como: tu_usuario_charolais_user

4. 💳 CLAVES DE STRIPE:
   - Ve a dashboard.stripe.com
   - Sección "Desarrolladores" → "Claves API"
   - Copia la clave pública (pk_test_...) y secreta (sk_test_...)

5. 🌐 DOMINIO:
   - Cambia https://tudominio.com por tu dominio real

6. 📧 EMAIL:
   - Cambia tu@email.com por tu email real

¡Listo! Tu configuración estará completa.
--> 