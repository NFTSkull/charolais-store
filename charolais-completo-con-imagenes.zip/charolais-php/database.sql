-- 🚀 CHAROLAIS E-COMMERCE - SCHEMA DE BASE DE DATOS MySQL
-- =======================================================
-- Archivo: database.sql
-- Uso: Importar en cPanel > phpMyAdmin
-- =====================================================

-- 🗑️ LIMPIAR TABLAS EXISTENTES (SI EXISTEN)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS admin_notifications;
DROP TABLE IF EXISTS variant_images;
DROP TABLE IF EXISTS variant_attributes;
DROP TABLE IF EXISTS product_variants;
DROP TABLE IF EXISTS color_options;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS system_settings;
SET FOREIGN_KEY_CHECKS = 1;

-- ==========================================
-- 📦 TABLA: products
-- ==========================================
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image_url VARCHAR(500),
    category VARCHAR(100),
    has_variants BOOLEAN DEFAULT 0,
    stock_quantity INT DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    featured BOOLEAN DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_active (is_active),
    INDEX idx_featured (featured),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 🎨 TABLA: color_options
-- ==========================================
CREATE TABLE color_options (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    hex_code VARCHAR(7) NOT NULL,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 🔄 TABLA: product_variants
-- ==========================================
CREATE TABLE product_variants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    variant_name VARCHAR(100),
    price DECIMAL(10,2),
    stock_quantity INT DEFAULT 0,
    sku VARCHAR(100) UNIQUE,
    is_active BOOLEAN DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    INDEX idx_product_variant (product_id),
    INDEX idx_sku (sku),
    INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 🏷️ TABLA: variant_attributes
-- ==========================================
CREATE TABLE variant_attributes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    variant_id INT NOT NULL,
    attribute_name VARCHAR(50) NOT NULL,
    attribute_value VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE,
    INDEX idx_variant_attr (variant_id, attribute_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 🖼️ TABLA: variant_images
-- ==========================================
CREATE TABLE variant_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    variant_id INT NOT NULL,
    image_url VARCHAR(500) NOT NULL,
    alt_text VARCHAR(255),
    is_primary BOOLEAN DEFAULT 0,
    display_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE,
    INDEX idx_variant_image (variant_id),
    INDEX idx_primary (is_primary)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 🛒 TABLA: orders
-- ==========================================
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) NOT NULL UNIQUE,
    stripe_session_id VARCHAR(255),
    stripe_payment_intent_id VARCHAR(255),
    customer_email VARCHAR(255) NOT NULL,
    customer_name VARCHAR(255),
    customer_phone VARCHAR(50),
    shipping_address TEXT,
    shipping_city VARCHAR(100),
    shipping_state VARCHAR(100),
    shipping_country VARCHAR(50) DEFAULT 'México',
    shipping_postal_code VARCHAR(20),
    subtotal DECIMAL(10,2) NOT NULL,
    shipping_cost DECIMAL(10,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'MXN',
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    order_status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_order_number (order_number),
    INDEX idx_stripe_session (stripe_session_id),
    INDEX idx_customer_email (customer_email),
    INDEX idx_payment_status (payment_status),
    INDEX idx_order_status (order_status),
    INDEX idx_created_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 📦 TABLA: order_items
-- ==========================================
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    variant_id INT NULL,
    product_name VARCHAR(255) NOT NULL,
    variant_name VARCHAR(100),
    price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    subtotal DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (variant_id) REFERENCES product_variants(id),
    INDEX idx_order_item (order_id),
    INDEX idx_product_item (product_id),
    INDEX idx_variant_item (variant_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 🔔 TABLA: admin_notifications
-- ==========================================
CREATE TABLE admin_notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('new_order', 'low_stock', 'payment_failed', 'system') DEFAULT 'system',
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT 0,
    order_id INT NULL,
    product_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
    INDEX idx_type_read (type, is_read),
    INDEX idx_created_date (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- ⚙️ TABLA: system_settings
-- ==========================================
CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    description VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_setting_key (setting_key)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ==========================================
-- 🎨 DATOS INICIALES: color_options
-- ==========================================
INSERT INTO color_options (name, hex_code) VALUES
('Negro', '#000000'),
('Blanco', '#FFFFFF'),
('Rojo', '#FF0000'),
('Azul', '#0000FF'),
('Verde', '#008000'),
('Amarillo', '#FFFF00'),
('Rosa', '#FFC0CB'),
('Morado', '#800080'),
('Naranja', '#FFA500'),
('Café', '#A52A2A');

-- ==========================================
-- ⚙️ CONFIGURACIONES INICIALES DEL SISTEMA
-- ==========================================
INSERT INTO system_settings (setting_key, setting_value, description) VALUES
('site_name', 'Charolais Store', 'Nombre del sitio web'),
('currency', 'MXN', 'Moneda principal'),
('timezone', 'America/Mexico_City', 'Zona horaria del sitio'),
('low_stock_threshold', '5', 'Umbral de stock bajo para alertas'),
('auto_email_notifications', '1', 'Enviar notificaciones por email automáticamente'),
('shipping_cost', '0', 'Costo de envío (0 = gratis)'),
('tax_rate', '0', 'Tasa de impuestos (0 = sin impuestos)');

-- ==========================================
-- 📦 PRODUCTOS DE EJEMPLO (DATOS INICIALES)
-- ==========================================
INSERT INTO products (name, description, price, image_url, category, has_variants, stock_quantity, featured) VALUES
('Cowboy Skull', 'Diseño icónico de calavera vaquera con estilo único', 450.00, 'uploads/cowboy-skull.jpg', 'Camisetas', 1, 0, 1),
('All Around', 'Camiseta versátil para cualquier ocasión', 420.00, 'uploads/all-around.jpg', 'Camisetas', 1, 0, 1),
('Rodeo Clown', 'Diseño divertido inspirado en el rodeo', 400.00, 'uploads/rodeo-clown.jpg', 'Camisetas', 1, 0, 1),
('CowGirls', 'Diseño especial para las vaqueras modernas', 460.00, 'uploads/cowgirls.jpg', 'Camisetas', 1, 0, 1),
('Western Classic', 'Estilo clásico del oeste americano', 380.00, 'uploads/western-classic.jpg', 'Camisetas', 0, 15, 0),
('Bull Rider', 'Para los amantes del rodeo extremo', 440.00, 'uploads/bull-rider.jpg', 'Camisetas', 0, 20, 1);

-- ==========================================
-- 🔄 VARIANTES PARA PRODUCTOS ESPECÍFICOS
-- ==========================================

-- Variantes para Cowboy Skull (ID: 1)
INSERT INTO product_variants (product_id, variant_name, price, stock_quantity, sku) VALUES
(1, 'Negro', 450.00, 12, 'COWBOY-SKULL-BLK'),
(1, 'Blanco', 450.00, 8, 'COWBOY-SKULL-WHT');

-- Variantes para All Around (ID: 2)
INSERT INTO product_variants (product_id, variant_name, price, stock_quantity, sku) VALUES
(2, 'Negro', 420.00, 15, 'ALL-AROUND-BLK'),
(2, 'Blanco', 420.00, 10, 'ALL-AROUND-WHT');

-- Variantes para Rodeo Clown (ID: 3)
INSERT INTO product_variants (product_id, variant_name, price, stock_quantity, sku) VALUES
(3, 'Rojo', 400.00, 6, 'RODEO-CLOWN-RED');

-- Variantes para CowGirls (ID: 4)
INSERT INTO product_variants (product_id, variant_name, price, stock_quantity, sku) VALUES
(4, 'Blanco', 460.00, 9, 'COWGIRLS-WHT'),
(4, 'Negro', 460.00, 7, 'COWGIRLS-BLK');

-- ==========================================
-- 🏷️ ATRIBUTOS DE VARIANTES (COLORES)
-- ==========================================
INSERT INTO variant_attributes (variant_id, attribute_name, attribute_value) VALUES
-- Cowboy Skull
(1, 'color', 'Negro'),
(2, 'color', 'Blanco'),
-- All Around
(3, 'color', 'Negro'),
(4, 'color', 'Blanco'),
-- Rodeo Clown
(5, 'color', 'Rojo'),
-- CowGirls
(6, 'color', 'Blanco'),
(7, 'color', 'Negro');

-- ==========================================
-- 🔔 NOTIFICACIÓN INICIAL
-- ==========================================
INSERT INTO admin_notifications (type, title, message) VALUES
('system', '🎉 ¡Sistema Iniciado!', 'La tienda Charolais está lista para recibir pedidos. Todos los productos y variantes han sido configurados correctamente.');

-- ==========================================
-- 📊 VISTAS PARA REPORTES
-- ==========================================

-- Vista para productos con stock total
CREATE VIEW products_with_total_stock AS
SELECT 
    p.id,
    p.name,
    p.price,
    p.has_variants,
    p.stock_quantity as base_stock,
    COALESCE(SUM(pv.stock_quantity), p.stock_quantity) as total_stock,
    p.is_active,
    p.featured
FROM products p
LEFT JOIN product_variants pv ON p.id = pv.product_id AND pv.is_active = 1
WHERE p.is_active = 1
GROUP BY p.id;

-- Vista para órdenes con detalles
CREATE VIEW orders_summary AS
SELECT 
    o.id,
    o.order_number,
    o.customer_name,
    o.customer_email,
    o.total_amount,
    o.payment_status,
    o.order_status,
    o.created_at,
    COUNT(oi.id) as items_count
FROM orders o
LEFT JOIN order_items oi ON o.id = oi.order_id
GROUP BY o.id
ORDER BY o.created_at DESC;

-- ==========================================
-- 🎯 FINALIZACIÓN
-- ==========================================

-- Mensaje de confirmación
SELECT '🎉 BASE DE DATOS CHAROLAIS CREADA EXITOSAMENTE' as STATUS,
       COUNT(*) as PRODUCTOS_CREADOS FROM products;

SELECT '🔄 VARIANTES CONFIGURADAS' as STATUS,
       COUNT(*) as VARIANTES_CREADAS FROM product_variants;

SELECT '✅ SISTEMA LISTO PARA PRODUCCIÓN' as STATUS; 