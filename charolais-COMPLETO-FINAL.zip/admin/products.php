<?php
/**
 * Gestión de Productos - Panel de Administración
 */

require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/auth.php';

// Verificar autenticación
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$action = $_GET['action'] ?? 'list';
$productId = $_GET['id'] ?? null;
$message = '';
$error = '';

// Obtener categorías para el formulario
$categories = $db->select("SELECT * FROM categories WHERE is_active = 1 ORDER BY name");

// Procesar acciones
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'add' || $action === 'edit') {
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $price = $_POST['price'] ?? 0;
        $categoryId = $_POST['category_id'] ?? null;
        $stockQuantity = $_POST['stock_quantity'] ?? 0;
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        
        if (empty($name) || $price <= 0) {
            $error = 'Nombre y precio son requeridos';
        } else {
            try {
                if ($action === 'add') {
                    $db->insert("INSERT INTO products (name, description, price, category_id, stock_quantity, is_active) VALUES (?, ?, ?, ?, ?, ?)", 
                               [$name, $description, $price, $categoryId, $stockQuantity, $isActive]);
                    $message = 'Producto agregado exitosamente';
                    $action = 'list';
                } else {
                    $db->update("UPDATE products SET name = ?, description = ?, price = ?, category_id = ?, stock_quantity = ?, is_active = ? WHERE id = ?", 
                               [$name, $description, $price, $categoryId, $stockQuantity, $isActive, $productId]);
                    $message = 'Producto actualizado exitosamente';
                    $action = 'list';
                }
            } catch (Exception $e) {
                $error = 'Error al guardar el producto: ' . $e->getMessage();
            }
        }
    }
}

// Eliminar producto
if ($action === 'delete' && $productId) {
    try {
        $db->delete("DELETE FROM products WHERE id = ?", [$productId]);
        $message = 'Producto eliminado exitosamente';
        $action = 'list';
    } catch (Exception $e) {
        $error = 'Error al eliminar el producto: ' . $e->getMessage();
    }
}

// Obtener producto para editar
$product = null;
if ($action === 'edit' && $productId) {
    $products = $db->select("SELECT * FROM products WHERE id = ?", [$productId]);
    $product = $products[0] ?? null;
    if (!$product) {
        $error = 'Producto no encontrado';
        $action = 'list';
    }
}

// Obtener lista de productos
if ($action === 'list') {
    $products = $db->select("
        SELECT p.*, c.name as category_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        ORDER BY p.created_at DESC
    ");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Productos - <?php echo APP_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            width: 250px;
        }
        .sidebar .nav-link {
            color: #adb5bd;
            padding: 0.75rem 1rem;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: #fff;
            background: #495057;
        }
        .main-content {
            margin-left: 0;
        }
        @media (min-width: 768px) {
            .main-content {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar position-fixed d-none d-md-block">
        <div class="p-3">
            <h5 class="text-white">
                <i class="fas fa-hat-cowboy"></i>
                <?php echo APP_NAME; ?>
            </h5>
            <small class="text-muted">Panel de Admin</small>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="products.php">
                    <i class="fas fa-box"></i> Productos
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="categories.php">
                    <i class="fas fa-tags"></i> Categorías
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="orders.php">
                    <i class="fas fa-shopping-cart"></i> Órdenes
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="images.php">
                    <i class="fas fa-images"></i> Imágenes
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="settings.php">
                    <i class="fas fa-cog"></i> Configuración
                </a>
            </li>
            <li class="nav-item mt-3">
                <a class="nav-link" href="../" target="_blank">
                    <i class="fas fa-external-link-alt"></i> Ver Tienda
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <div class="container-fluid">
                <h4 class="mb-0">Gestión de Productos</h4>
                
                <div class="ms-auto">
                    <?php if ($action === 'list'): ?>
                        <a href="?action=add" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Agregar Producto
                        </a>
                    <?php else: ?>
                        <a href="products.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>

        <!-- Content -->
        <div class="container-fluid p-4">
            <!-- Messages -->
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($action === 'list'): ?>
                <!-- Lista de Productos -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Lista de Productos</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($products)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-box fa-3x text-muted mb-3"></i>
                                <h5>No hay productos registrados</h5>
                                <p class="text-muted">Comienza agregando tu primer producto</p>
                                <a href="?action=add" class="btn btn-primary">
                                    <i class="fas fa-plus"></i> Agregar Primer Producto
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nombre</th>
                                            <th>Categoría</th>
                                            <th>Precio</th>
                                            <th>Stock</th>
                                            <th>Estado</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($products as $prod): ?>
                                        <tr>
                                            <td><?php echo $prod['id']; ?></td>
                                            <td><?php echo htmlspecialchars($prod['name']); ?></td>
                                            <td><?php echo htmlspecialchars($prod['category_name'] ?? 'Sin categoría'); ?></td>
                                            <td><?php echo formatPrice($prod['price']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $prod['stock_quantity'] > 0 ? 'success' : 'danger'; ?>">
                                                    <?php echo $prod['stock_quantity']; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php echo $prod['is_active'] ? 'success' : 'secondary'; ?>">
                                                    <?php echo $prod['is_active'] ? 'Activo' : 'Inactivo'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="?action=edit&id=<?php echo $prod['id']; ?>" class="btn btn-outline-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="?action=delete&id=<?php echo $prod['id']; ?>" 
                                                       class="btn btn-outline-danger"
                                                       onclick="return confirm('¿Estás seguro de eliminar este producto?')">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            <?php elseif ($action === 'add' || $action === 'edit'): ?>
                <!-- Formulario de Producto -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <?php echo $action === 'add' ? 'Agregar Producto' : 'Editar Producto'; ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="mb-3">
                                        <label class="form-label">Nombre del Producto *</label>
                                        <input type="text" class="form-control" name="name" 
                                               value="<?php echo htmlspecialchars($product['name'] ?? ''); ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Descripción</label>
                                        <textarea class="form-control" name="description" rows="4"><?php echo htmlspecialchars($product['description'] ?? ''); ?></textarea>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Precio *</label>
                                                <div class="input-group">
                                                    <span class="input-group-text">$</span>
                                                    <input type="number" class="form-control" name="price" step="0.01" min="0"
                                                           value="<?php echo $product['price'] ?? ''; ?>" required>
                                                    <span class="input-group-text">MXN</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Stock</label>
                                                <input type="number" class="form-control" name="stock_quantity" min="0"
                                                       value="<?php echo $product['stock_quantity'] ?? 0; ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Categoría</label>
                                        <select class="form-select" name="category_id">
                                            <option value="">Sin categoría</option>
                                            <?php foreach ($categories as $category): ?>
                                            <option value="<?php echo $category['id']; ?>"
                                                    <?php echo ($product['category_id'] ?? '') == $category['id'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($category['name']); ?>
                                            </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="is_active" 
                                                   <?php echo ($product['is_active'] ?? 1) ? 'checked' : ''; ?>>
                                            <label class="form-check-label">
                                                Producto activo
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="products.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancelar
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> 
                                    <?php echo $action === 'add' ? 'Agregar Producto' : 'Actualizar Producto'; ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 