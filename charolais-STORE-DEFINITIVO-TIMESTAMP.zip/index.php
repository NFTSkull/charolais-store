<?php
/**
 * Página principal de Charolais Store
 * Tienda online con productos, categorías y carrito de compras
 */

require_once 'includes/database.php';

// Obtener categorías
try {
    $categories = $db->select("SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name");
} catch (Exception $e) {
    $categories = [];
}

// Obtener productos con sus imágenes
try {
    $sql = "
        SELECT p.*, c.name as category_name,
               GROUP_CONCAT(pi.image_url ORDER BY pi.sort_order SEPARATOR '|') as images
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN product_images pi ON p.id = pi.product_id
        WHERE p.is_active = 1
        GROUP BY p.id
        ORDER BY p.sort_order, p.name
    ";
    $products = $db->select($sql);
    
    // Procesar imágenes
    foreach ($products as &$product) {
        $product['images'] = $product['images'] ? explode('|', $product['images']) : [];
    }
} catch (Exception $e) {
    $products = [];
}

// Obtener variantes de productos
try {
    $productIds = array_column($products, 'id');
    $variants = [];
    
    if (!empty($productIds)) {
        $placeholders = str_repeat('?,', count($productIds) - 1) . '?';
        $sql = "
            SELECT pv.*, vi.image_url as variant_image
            FROM product_variants pv
            LEFT JOIN variant_images vi ON pv.id = vi.variant_id
            WHERE pv.product_id IN ($placeholders) AND pv.is_active = 1
            ORDER BY pv.sort_order, pv.variant_name
        ";
        $variantsData = $db->select($sql, $productIds);
        
        // Organizar variantes por producto
        foreach ($variantsData as $variant) {
            $variants[$variant['product_id']][] = $variant;
        }
    }
} catch (Exception $e) {
    $variants = [];
}

// Obtener configuración de Stripe
$stripePublishableKey = getSystemSetting('stripe_publishable_key', STRIPE_PUBLISHABLE_KEY);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Tienda Cowboy</title>
    <meta name="description" content="Tienda online de productos cowboy. Sombreros, botas, cinturones y más.">
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="/favicon.ico">
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/styles.css">
    
    <!-- Stripe -->
    <script src="https://js.stripe.com/v3/"></script>
</head>
<body>
    <!-- Header -->
    <header class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="fas fa-hat-cowboy"></i>
                <?php echo APP_NAME; ?>
            </a>
            
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#products">Productos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#categories">Categorías</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">Nosotros</a>
                    </li>
                </ul>
                
                <div class="d-flex align-items-center">
                    <!-- Carrito -->
                    <div class="dropdown me-3">
                        <button class="btn btn-outline-light position-relative" type="button" data-bs-toggle="dropdown">
                            <i class="fas fa-shopping-cart"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" id="cart-count">
                                0
                            </span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end" style="width: 350px;">
                            <div class="p-3">
                                <h6 class="dropdown-header">Carrito de Compras</h6>
                                <div id="cart-items">
                                    <p class="text-muted mb-0">Tu carrito está vacío</p>
                                </div>
                                <hr>
                                <div class="d-flex justify-content-between mb-2">
                                    <strong>Total:</strong>
                                    <strong id="cart-total">$0.00 MXN</strong>
                                </div>
                                <button class="btn btn-primary w-100" id="checkout-btn" disabled>
                                    Proceder al Pago
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Admin Link -->
                    <a href="/admin" class="btn btn-outline-light btn-sm">
                        <i class="fas fa-cog"></i> Admin
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero-section text-white text-center py-5">
        <div class="container">
            <h1 class="display-4 mb-4">Bienvenido a <?php echo APP_NAME; ?></h1>
            <p class="lead mb-4">Descubre nuestra colección de productos cowboy de la más alta calidad</p>
            <a href="#products" class="btn btn-primary btn-lg">Ver Productos</a>
        </div>
    </section>

    <!-- Categories Section -->
    <section id="categories" class="py-5 bg-light">
        <div class="container">
            <h2 class="text-center mb-5">Categorías</h2>
            <div class="row">
                <?php foreach ($categories as $category): ?>
                <div class="col-md-4 mb-4">
                    <div class="card category-card h-100">
                        <div class="card-body text-center">
                            <i class="fas fa-tag fa-3x text-primary mb-3"></i>
                            <h5 class="card-title"><?php echo htmlspecialchars($category['name']); ?></h5>
                            <p class="card-text"><?php echo htmlspecialchars($category['description'] ?? ''); ?></p>
                            <button class="btn btn-outline-primary filter-category" data-category="<?php echo $category['id']; ?>">
                                Ver Productos
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Products Section -->
    <section id="products" class="py-5">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Productos</h2>
                <div class="btn-group" role="group">
                    <button type="button" class="btn btn-outline-primary filter-btn active" data-filter="all">
                        Todos
                    </button>
                    <?php foreach ($categories as $category): ?>
                    <button type="button" class="btn btn-outline-primary filter-btn" data-filter="<?php echo $category['id']; ?>">
                        <?php echo htmlspecialchars($category['name']); ?>
                    </button>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="row" id="products-grid">
                <?php foreach ($products as $product): ?>
                <div class="col-lg-4 col-md-6 mb-4 product-item" data-category="<?php echo $product['category_id']; ?>">
                    <div class="card h-100 product-card">
                        <!-- Product Images -->
                        <div id="carousel-<?php echo $product['id']; ?>" class="carousel slide" data-bs-ride="carousel">
                            <div class="carousel-inner">
                                <?php if (!empty($product['images'])): ?>
                                    <?php foreach ($product['images'] as $index => $image): ?>
                                    <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                        <img src="uploads/<?php echo htmlspecialchars($image); ?>" 
                                             class="d-block w-100 product-image" 
                                             alt="<?php echo htmlspecialchars($product['name']); ?>">
                                    </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <div class="carousel-item active">
                                        <img src="https://via.placeholder.com/400x300?text=Sin+Imagen" 
                                             class="d-block w-100 product-image" 
                                             alt="Sin imagen">
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php if (count($product['images']) > 1): ?>
                            <button class="carousel-control-prev" type="button" data-bs-target="#carousel-<?php echo $product['id']; ?>" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon"></span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#carousel-<?php echo $product['id']; ?>" data-bs-slide="next">
                                <span class="carousel-control-next-icon"></span>
                            </button>
                            <?php endif; ?>
                        </div>
                        
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                            <p class="card-text flex-grow-1"><?php echo htmlspecialchars($product['description'] ?? ''); ?></p>
                            
                            <!-- Variants -->
                            <?php if (isset($variants[$product['id']])): ?>
                            <div class="mb-3">
                                <label class="form-label">Color:</label>
                                <select class="form-select variant-select" data-product-id="<?php echo $product['id']; ?>">
                                    <option value="">Seleccionar color</option>
                                    <?php foreach ($variants[$product['id']] as $variant): ?>
                                    <option value="<?php echo $variant['id']; ?>" 
                                            data-price="<?php echo $variant['price_override'] ?: $product['price']; ?>"
                                            data-stock="<?php echo $variant['stock_quantity']; ?>">
                                        <?php echo htmlspecialchars($variant['variant_name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <?php endif; ?>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="h5 mb-0 product-price" data-base-price="<?php echo $product['price']; ?>">
                                    <?php echo formatPrice($product['price']); ?>
                                </span>
                                <button class="btn btn-primary add-to-cart" 
                                        data-product-id="<?php echo $product['id']; ?>"
                                        data-product-name="<?php echo htmlspecialchars($product['name']); ?>"
                                        data-product-price="<?php echo $product['price']; ?>"
                                        <?php echo $product['stock_quantity'] <= 0 ? 'disabled' : ''; ?>>
                                    <i class="fas fa-cart-plus"></i>
                                    <?php echo $product['stock_quantity'] > 0 ? 'Agregar' : 'Sin Stock'; ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h2>Sobre <?php echo APP_NAME; ?></h2>
                    <p class="lead">
                        Somos una tienda especializada en productos cowboy de la más alta calidad. 
                        Ofrecemos una amplia selección de sombreros, botas, cinturones y accesorios 
                        para todos los amantes del estilo western.
                    </p>
                    <p>
                        Nuestros productos están fabricados con materiales premium y diseño auténtico, 
                        garantizando durabilidad y estilo en cada pieza.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><?php echo APP_NAME; ?></h5>
                    <p>Tu tienda de confianza para productos cowboy</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. Todos los derechos reservados.</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Checkout Modal -->
    <div class="modal fade" id="checkoutModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Finalizar Compra</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="checkout-form">
                        <div class="row">
                            <div class="col-md-8">
                                <h6>Información de Contacto</h6>
                                <div class="mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" id="customer-email" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Nombre Completo</label>
                                    <input type="text" class="form-control" id="customer-name" required>
                                </div>
                                
                                <h6 class="mt-4">Resumen de Compra</h6>
                                <div id="checkout-items"></div>
                                
                                <div class="d-flex justify-content-between mt-3">
                                    <strong>Subtotal:</strong>
                                    <span id="checkout-subtotal">$0.00 MXN</span>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <strong>Envío:</strong>
                                    <span id="checkout-shipping">$0.00 MXN</span>
                                </div>
                                <div class="d-flex justify-content-between">
                                    <strong>Total:</strong>
                                    <span id="checkout-total">$0.00 MXN</span>
                                </div>
                                
                                <div id="free-shipping-badge" class="alert alert-success mt-3" style="display: none;">
                                    <i class="fas fa-gift"></i> ¡Envío gratis en tu primera compra!
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="proceed-to-payment">
                        Proceder al Pago
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Configuración global
        const STRIPE_PUBLISHABLE_KEY = '<?php echo $stripePublishableKey; ?>';
        const APP_URL = '<?php echo APP_URL; ?>';
        
        // Datos de productos
        const products = <?php echo json_encode($products); ?>;
        const variants = <?php echo json_encode($variants); ?>;
        
        // Carrito
        let cart = JSON.parse(localStorage.getItem('charolais_cart')) || [];
        let isFirstPurchase = localStorage.getItem('charolais_first_purchase') !== 'false';
        
        // Inicializar Stripe
        const stripe = Stripe(STRIPE_PUBLISHABLE_KEY);
        
        // Actualizar carrito
        function updateCart() {
            const cartCount = document.getElementById('cart-count');
            const cartItems = document.getElementById('cart-items');
            const cartTotal = document.getElementById('cart-total');
            
            cartCount.textContent = cart.length;
            
            if (cart.length === 0) {
                cartItems.innerHTML = '<p class="text-muted mb-0">Tu carrito está vacío</p>';
                cartTotal.textContent = '$0.00 MXN';
                document.getElementById('checkout-btn').disabled = true;
            } else {
                let itemsHtml = '';
                let total = 0;
                
                cart.forEach(item => {
                    const itemTotal = item.price * item.quantity;
                    total += itemTotal;
                    
                    itemsHtml += `
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <strong>${item.name}</strong>
                                ${item.variant ? `<br><small class="text-muted">${item.variant}</small>` : ''}
                                <br><small class="text-muted">Cantidad: ${item.quantity}</small>
                            </div>
                            <div class="text-end">
                                <div>$${itemTotal.toFixed(2)} MXN</div>
                                <button class="btn btn-sm btn-outline-danger remove-item" data-index="${cart.indexOf(item)}">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    `;
                });
                
                cartItems.innerHTML = itemsHtml;
                cartTotal.textContent = `$${total.toFixed(2)} MXN`;
                document.getElementById('checkout-btn').disabled = false;
            }
            
            localStorage.setItem('charolais_cart', JSON.stringify(cart));
        }
        
        // Agregar al carrito
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function() {
                const productId = parseInt(this.dataset.productId);
                const productName = this.dataset.productName;
                const productPrice = parseFloat(this.dataset.productPrice);
                
                // Verificar variante seleccionada
                const variantSelect = this.closest('.card-body').querySelector('.variant-select');
                let variantId = null;
                let variantName = null;
                let finalPrice = productPrice;
                
                if (variantSelect && variantSelect.value) {
                    const selectedOption = variantSelect.options[variantSelect.selectedIndex];
                    variantId = parseInt(variantSelect.value);
                    variantName = selectedOption.text;
                    finalPrice = parseFloat(selectedOption.dataset.price);
                }
                
                // Verificar si ya existe en el carrito
                const existingItem = cart.find(item => 
                    item.productId === productId && item.variantId === variantId
                );
                
                if (existingItem) {
                    existingItem.quantity++;
                } else {
                    cart.push({
                        productId,
                        name: productName,
                        price: finalPrice,
                        quantity: 1,
                        variantId,
                        variant: variantName
                    });
                }
                
                updateCart();
                
                // Mostrar notificación
                const toast = document.createElement('div');
                toast.className = 'toast position-fixed top-0 end-0 m-3';
                toast.innerHTML = `
                    <div class="toast-header">
                        <i class="fas fa-check-circle text-success me-2"></i>
                        <strong class="me-auto">Producto agregado</strong>
                        <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
                    </div>
                    <div class="toast-body">
                        ${productName} ha sido agregado al carrito
                    </div>
                `;
                document.body.appendChild(toast);
                new bootstrap.Toast(toast).show();
                
                setTimeout(() => {
                    document.body.removeChild(toast);
                }, 3000);
            });
        });
        
        // Remover del carrito
        document.addEventListener('click', function(e) {
            if (e.target.closest('.remove-item')) {
                const index = parseInt(e.target.closest('.remove-item').dataset.index);
                cart.splice(index, 1);
                updateCart();
            }
        });
        
        // Filtros de categoría
        document.querySelectorAll('.filter-btn, .filter-category').forEach(button => {
            button.addEventListener('click', function() {
                const filter = this.dataset.filter || this.dataset.category;
                
                // Actualizar botones activos
                document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
                if (this.classList.contains('filter-btn')) {
                    this.classList.add('active');
                }
                
                // Filtrar productos
                document.querySelectorAll('.product-item').forEach(item => {
                    if (filter === 'all' || item.dataset.category === filter) {
                        item.style.display = 'block';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });
        
        // Variantes
        document.querySelectorAll('.variant-select').forEach(select => {
            select.addEventListener('change', function() {
                const productId = parseInt(this.dataset.productId);
                const card = this.closest('.product-card');
                const priceElement = card.querySelector('.product-price');
                const addButton = card.querySelector('.add-to-cart');
                
                if (this.value) {
                    const selectedOption = this.options[this.selectedIndex];
                    const price = parseFloat(selectedOption.dataset.price);
                    const stock = parseInt(selectedOption.dataset.stock);
                    
                    priceElement.textContent = `$${price.toFixed(2)} MXN`;
                    addButton.dataset.productPrice = price;
                    addButton.disabled = stock <= 0;
                    addButton.innerHTML = stock > 0 ? '<i class="fas fa-cart-plus"></i> Agregar' : 'Sin Stock';
                } else {
                    const basePrice = parseFloat(priceElement.dataset.basePrice);
                    priceElement.textContent = `$${basePrice.toFixed(2)} MXN`;
                    addButton.dataset.productPrice = basePrice;
                    addButton.disabled = false;
                    addButton.innerHTML = '<i class="fas fa-cart-plus"></i> Agregar';
                }
            });
        });
        
        // Checkout
        document.getElementById('checkout-btn').addEventListener('click', function() {
            if (cart.length === 0) return;
            
            // Mostrar modal de checkout
            const modal = new bootstrap.Modal(document.getElementById('checkoutModal'));
            modal.show();
            
            // Llenar resumen
            const checkoutItems = document.getElementById('checkout-items');
            let itemsHtml = '';
            let subtotal = 0;
            
            cart.forEach(item => {
                const itemTotal = item.price * item.quantity;
                subtotal += itemTotal;
                
                itemsHtml += `
                    <div class="d-flex justify-content-between mb-2">
                        <div>
                            <strong>${item.name}</strong>
                            ${item.variant ? `<br><small class="text-muted">${item.variant}</small>` : ''}
                            <br><small class="text-muted">Cantidad: ${item.quantity}</small>
                        </div>
                        <div>$${itemTotal.toFixed(2)} MXN</div>
                    </div>
                `;
            });
            
            checkoutItems.innerHTML = itemsHtml;
            
            // Calcular envío
            const shipping = isFirstPurchase ? 0 : Math.max(150, subtotal * 0.1);
            const total = subtotal + shipping;
            
            document.getElementById('checkout-subtotal').textContent = `$${subtotal.toFixed(2)} MXN`;
            document.getElementById('checkout-shipping').textContent = `$${shipping.toFixed(2)} MXN`;
            document.getElementById('checkout-total').textContent = `$${total.toFixed(2)} MXN`;
            
            // Mostrar badge de envío gratis
            const freeShippingBadge = document.getElementById('free-shipping-badge');
            if (isFirstPurchase) {
                freeShippingBadge.style.display = 'block';
            } else {
                freeShippingBadge.style.display = 'none';
            }
        });
        
        // Proceder al pago
        document.getElementById('proceed-to-payment').addEventListener('click', async function() {
            const email = document.getElementById('customer-email').value;
            const name = document.getElementById('customer-name').value;
            
            if (!email || !name) {
                alert('Por favor completa todos los campos');
                return;
            }
            
            if (cart.length === 0) {
                alert('El carrito está vacío');
                return;
            }
            
            this.disabled = true;
            this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Procesando...';
            
            try {
                const response = await fetch('/api/checkout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        items: cart,
                        customer: { email, name },
                        isFirstPurchase
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    // Redirigir a Stripe
                    const { error } = await stripe.redirectToCheckout({
                        sessionId: result.sessionId
                    });
                    
                    if (error) {
                        alert('Error al procesar el pago: ' + error.message);
                    }
                } else {
                    alert('Error: ' + result.message);
                }
            } catch (error) {
                alert('Error al procesar la compra');
                console.error(error);
            } finally {
                this.disabled = false;
                this.innerHTML = 'Proceder al Pago';
            }
        });
        
        // Inicializar
        updateCart();
    </script>
</body>
</html> 