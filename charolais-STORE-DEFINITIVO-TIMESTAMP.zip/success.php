<?php
/**
 * Página de éxito de pago
 * Se muestra cuando el pago se completa exitosamente
 */

require_once 'includes/database.php';

$sessionId = $_GET['session_id'] ?? '';
$order = null;
$orderItems = [];

if ($sessionId) {
    try {
        // Buscar orden por session ID
        $order = $db->selectOne("SELECT * FROM orders WHERE stripe_session_id = ?", [$sessionId]);
        
        if ($order) {
            // Obtener items de la orden
            $orderItems = $db->select("SELECT * FROM order_items WHERE order_id = ?", [$order['id']]);
            
            // Actualizar estado si está pendiente
            if ($order['status'] === 'pending') {
                $db->update('orders', ['status' => 'paid'], 'id = ?', [$order['id']]);
                $order['status'] = 'paid';
                
                // Log de actividad
                logActivity('payment_success', "Pago exitoso: Orden #{$order['id']} - $" . number_format($order['total_amount'], 2) . " MXN", null);
            }
        }
    } catch (Exception $e) {
        error_log("Error obteniendo orden: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Exitoso - <?php echo APP_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <!-- Header -->
    <header class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="fas fa-hat-cowboy"></i>
                <?php echo APP_NAME; ?>
            </a>
        </div>
    </header>

    <!-- Success Content -->
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-cowboy">
                    <div class="card-body text-center p-5">
                        <!-- Success Icon -->
                        <div class="mb-4">
                            <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                        </div>
                        
                        <h1 class="text-success mb-4">¡Pago Exitoso!</h1>
                        
                        <p class="lead mb-4">
                            Gracias por tu compra. Tu orden ha sido procesada exitosamente.
                        </p>
                        
                        <?php if ($order): ?>
                            <!-- Order Details -->
                            <div class="alert alert-success">
                                <h5>Detalles de la Orden</h5>
                                <p class="mb-2"><strong>Orden #:</strong> <?php echo $order['id']; ?></p>
                                <p class="mb-2"><strong>Total:</strong> <?php echo formatPrice($order['total_amount']); ?></p>
                                <p class="mb-0"><strong>Estado:</strong> 
                                    <span class="badge bg-success">Pagado</span>
                                </p>
                            </div>
                            
                            <!-- Free Shipping Badge -->
                            <?php if ($order['is_first_purchase']): ?>
                            <div class="alert alert-info">
                                <i class="fas fa-gift"></i>
                                <strong>¡Envío gratis!</strong> Como es tu primera compra, el envío es completamente gratis.
                            </div>
                            <?php endif; ?>
                            
                            <!-- Order Items -->
                            <?php if (!empty($orderItems)): ?>
                            <div class="mt-4">
                                <h5>Productos Comprados</h5>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Producto</th>
                                                <th>Variante</th>
                                                <th>Cantidad</th>
                                                <th>Precio</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($orderItems as $item): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($item['product_name']); ?></td>
                                                <td>
                                                    <?php if ($item['variant_name']): ?>
                                                        <span class="badge bg-secondary"><?php echo htmlspecialchars($item['variant_name']); ?></span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo $item['quantity']; ?></td>
                                                <td><?php echo formatPrice($item['unit_price']); ?></td>
                                                <td><?php echo formatPrice($item['total_price']); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="4" class="text-end"><strong>Subtotal:</strong></td>
                                                <td><?php echo formatPrice($order['total_amount'] - $order['shipping_amount']); ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="4" class="text-end"><strong>Envío:</strong></td>
                                                <td><?php echo formatPrice($order['shipping_amount']); ?></td>
                                            </tr>
                                            <tr class="table-active">
                                                <td colspan="4" class="text-end"><strong>Total:</strong></td>
                                                <td><strong><?php echo formatPrice($order['total_amount']); ?></strong></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <!-- Customer Info -->
                            <div class="mt-4">
                                <h5>Información del Cliente</h5>
                                <div class="row">
                                    <div class="col-md-6">
                                        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($order['customer_name']); ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <p><strong>Email:</strong> <?php echo htmlspecialchars($order['customer_email']); ?></p>
                                    </div>
                                </div>
                                <p><strong>Fecha:</strong> <?php echo formatDate($order['created_at']); ?></p>
                            </div>
                            
                        <?php else: ?>
                            <div class="alert alert-warning">
                                <i class="fas fa-exclamation-triangle"></i>
                                No se pudo encontrar la información de la orden. 
                                Por favor, contacta con soporte si tienes alguna pregunta.
                            </div>
                        <?php endif; ?>
                        
                        <!-- Next Steps -->
                        <div class="mt-5">
                            <h5>Próximos Pasos</h5>
                            <div class="row text-start">
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-envelope text-primary me-3"></i>
                                        <div>
                                            <strong>Email de Confirmación</strong><br>
                                            <small class="text-muted">Recibirás un email con los detalles de tu compra</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-shipping-fast text-primary me-3"></i>
                                        <div>
                                            <strong>Envío</strong><br>
                                            <small class="text-muted">Tu pedido será enviado en 1-3 días hábiles</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-phone text-primary me-3"></i>
                                        <div>
                                            <strong>Soporte</strong><br>
                                            <small class="text-muted">Contáctanos si tienes alguna pregunta</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-star text-primary me-3"></i>
                                        <div>
                                            <strong>Reseña</strong><br>
                                            <small class="text-muted">Comparte tu experiencia con otros clientes</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="mt-5">
                            <a href="/" class="btn btn-primary btn-lg me-3">
                                <i class="fas fa-home"></i> Volver a la Tienda
                            </a>
                            <button class="btn btn-outline-primary btn-lg" onclick="window.print()">
                                <i class="fas fa-print"></i> Imprimir Recibo
                            </button>
                        </div>
                        
                        <!-- Social Sharing -->
                        <div class="mt-4">
                            <p class="text-muted">Comparte tu experiencia:</p>
                            <div class="d-flex justify-content-center gap-2">
                                <a href="#" class="btn btn-outline-primary" onclick="shareOnFacebook()">
                                    <i class="fab fa-facebook"></i> Facebook
                                </a>
                                <a href="#" class="btn btn-outline-info" onclick="shareOnTwitter()">
                                    <i class="fab fa-twitter"></i> Twitter
                                </a>
                                <a href="#" class="btn btn-outline-success" onclick="shareOnWhatsApp()">
                                    <i class="fab fa-whatsapp"></i> WhatsApp
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><?php echo APP_NAME; ?></h5>
                    <p>Gracias por tu compra</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. Todos los derechos reservados.</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Limpiar carrito después del pago exitoso
        localStorage.removeItem('charolais_cart');
        
        // Marcar que ya no es primera compra
        localStorage.setItem('charolais_first_purchase', 'false');
        
        // Funciones de compartir
        function shareOnFacebook() {
            const url = encodeURIComponent(window.location.href);
            const text = encodeURIComponent('¡Acabo de hacer una compra exitosa en ' + '<?php echo APP_NAME; ?>' + '!');
            window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}&quote=${text}`, '_blank');
        }
        
        function shareOnTwitter() {
            const text = encodeURIComponent('¡Acabo de hacer una compra exitosa en ' + '<?php echo APP_NAME; ?>' + '!');
            const url = encodeURIComponent(window.location.href);
            window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
        }
        
        function shareOnWhatsApp() {
            const text = encodeURIComponent('¡Acabo de hacer una compra exitosa en ' + '<?php echo APP_NAME; ?>' + '!');
            window.open(`https://wa.me/?text=${text}`, '_blank');
        }
        
        // Mostrar mensaje de bienvenida si es primera compra
        <?php if ($order && $order['is_first_purchase']): ?>
        setTimeout(() => {
            const welcomeModal = new bootstrap.Modal(document.createElement('div'));
            welcomeModal.element.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-success text-white">
                            <h5 class="modal-title">
                                <i class="fas fa-gift"></i> ¡Bienvenido a <?php echo APP_NAME; ?>!
                            </h5>
                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>¡Felicidades! Has completado tu primera compra con nosotros.</p>
                            <p>Como agradecimiento, tu envío ha sido completamente gratis.</p>
                            <p>Esperamos que disfrutes de tus productos y vuelvas pronto.</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-success" data-bs-dismiss="modal">
                                ¡Gracias!
                            </button>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(welcomeModal.element);
            welcomeModal.show();
        }, 1000);
        <?php endif; ?>
    </script>
</body>
</html> 