<?php
/**
 * Página de cancelación de pago
 * Se muestra cuando el usuario cancela el pago
 */

require_once 'includes/database.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pago Cancelado - <?php echo APP_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <!-- Header -->
    <header class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="/">
                <i class="fas fa-hat-cowboy"></i>
                <?php echo APP_NAME; ?>
            </a>
        </div>
    </header>

    <!-- Cancel Content -->
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-cowboy">
                    <div class="card-body text-center p-5">
                        <!-- Cancel Icon -->
                        <div class="mb-4">
                            <i class="fas fa-times-circle text-warning" style="font-size: 4rem;"></i>
                        </div>
                        
                        <h1 class="text-warning mb-4">Pago Cancelado</h1>
                        
                        <p class="lead mb-4">
                            Tu pago ha sido cancelado. No se ha procesado ninguna transacción.
                        </p>
                        
                        <div class="alert alert-info">
                            <h5>¿Qué pasó?</h5>
                            <p class="mb-0">
                                Has cancelado el proceso de pago. Tu carrito de compras sigue intacto 
                                y puedes intentar el pago nuevamente cuando lo desees.
                            </p>
                        </div>
                        
                        <!-- Common Reasons -->
                        <div class="mt-4">
                            <h5>Razones Comunes de Cancelación</h5>
                            <div class="row text-start">
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-credit-card text-warning me-3"></i>
                                        <div>
                                            <strong>Problemas con la Tarjeta</strong><br>
                                            <small class="text-muted">Verifica que tu tarjeta esté habilitada para compras online</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-shield-alt text-warning me-3"></i>
                                        <div>
                                            <strong>Seguridad Bancaria</strong><br>
                                            <small class="text-muted">Algunos bancos requieren autorización adicional</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-clock text-warning me-3"></i>
                                        <div>
                                            <strong>Tiempo de Espera</strong><br>
                                            <small class="text-muted">El proceso puede tardar unos minutos</small>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="d-flex align-items-center mb-3">
                                        <i class="fas fa-mobile-alt text-warning me-3"></i>
                                        <div>
                                            <strong>Dispositivo</strong><br>
                                            <small class="text-muted">Intenta desde otro dispositivo o navegador</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Help Section -->
                        <div class="mt-4">
                            <h5>¿Necesitas Ayuda?</h5>
                            <p class="text-muted">
                                Si tienes problemas con el pago, no dudes en contactarnos:
                            </p>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center justify-content-center mb-3">
                                        <i class="fas fa-envelope text-primary me-2"></i>
                                        <span>Email: contacto@charolais.com</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center justify-content-center mb-3">
                                        <i class="fas fa-phone text-primary me-2"></i>
                                        <span>Tel: (555) 123-4567</span>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="d-flex align-items-center justify-content-center mb-3">
                                        <i class="fas fa-clock text-primary me-2"></i>
                                        <span>Lun-Vie 9:00-18:00</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="mt-5">
                            <a href="/" class="btn btn-primary btn-lg me-3">
                                <i class="fas fa-home"></i> Volver a la Tienda
                            </a>
                            <button class="btn btn-outline-primary btn-lg" onclick="retryPayment()">
                                <i class="fas fa-redo"></i> Intentar Nuevamente
                            </button>
                        </div>
                        
                        <!-- Tips -->
                        <div class="mt-4">
                            <div class="alert alert-light">
                                <h6><i class="fas fa-lightbulb text-warning"></i> Consejos para el Pago</h6>
                                <ul class="list-unstyled mb-0">
                                    <li>✓ Asegúrate de que tu tarjeta esté habilitada para compras online</li>
                                    <li>✓ Verifica que tengas fondos suficientes</li>
                                    <li>✓ Usa un navegador actualizado</li>
                                    <li>✓ Desactiva temporalmente el bloqueador de anuncios</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5><?php echo APP_NAME; ?></h5>
                    <p>Estamos aquí para ayudarte</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. Todos los derechos reservados.</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script>
        // Función para reintentar el pago
        function retryPayment() {
            // Verificar si hay items en el carrito
            const cart = JSON.parse(localStorage.getItem('charolais_cart')) || [];
            
            if (cart.length === 0) {
                alert('Tu carrito está vacío. Agrega productos antes de intentar el pago.');
                window.location.href = '/';
                return;
            }
            
            // Redirigir al checkout
            window.location.href = '/';
        }
        
        // Mostrar mensaje de ayuda después de un tiempo
        setTimeout(() => {
            const helpModal = new bootstrap.Modal(document.createElement('div'));
            helpModal.element.innerHTML = `
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-warning text-dark">
                            <h5 class="modal-title">
                                <i class="fas fa-question-circle"></i> ¿Necesitas Ayuda?
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <p>Si tuviste problemas con el pago, podemos ayudarte:</p>
                            <ul>
                                <li>Verificar métodos de pago alternativos</li>
                                <li>Procesar tu orden por teléfono</li>
                                <li>Resolver problemas técnicos</li>
                                <li>Ofrecer descuentos especiales</li>
                            </ul>
                            <p class="mb-0"><strong>Contacto:</strong> contacto@charolais.com</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                Cerrar
                            </button>
                            <a href="mailto:contacto@charolais.com" class="btn btn-warning">
                                <i class="fas fa-envelope"></i> Contactar
                            </a>
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(helpModal.element);
            helpModal.show();
        }, 3000);
        
        // Log de cancelación
        console.log('Pago cancelado por el usuario');
        
        // Analytics (si tienes Google Analytics)
        if (typeof gtag !== 'undefined') {
            gtag('event', 'purchase_cancelled', {
                'event_category': 'ecommerce',
                'event_label': 'payment_cancelled'
            });
        }
    </script>
</body>
</html> 