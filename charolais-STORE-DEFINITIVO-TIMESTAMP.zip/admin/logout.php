<?php
/**
 * Logout - Panel de Administración
 */

require_once '../includes/config.php';
require_once '../includes/auth.php';

// Cerrar sesión
logout();

// Redirigir al login
header('Location: login.php');
exit();
?> 