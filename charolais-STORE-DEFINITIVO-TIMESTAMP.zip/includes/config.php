<?php
/**
 * Configuración principal de Charolais Store
 * Archivo de configuración para la aplicación PHP
 */

// Configuración de la aplicación
define('APP_NAME', 'Charolais Store');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'https://tudominio.com'); // Cambiar por tu dominio

// Configuración de base de datos MySQL
define('DB_HOST', 'localhost');
define('DB_NAME', 'charolais_store');
define('DB_USER', 'tu_usuario_mysql'); // Cambiar por tu usuario MySQL
define('DB_PASS', 'tu_password_mysql'); // Cambiar por tu contraseña MySQL
define('DB_CHARSET', 'utf8mb4');

// Configuración de Stripe
define('STRIPE_PUBLISHABLE_KEY', 'pk_test_...'); // Cambiar por tu clave pública
define('STRIPE_SECRET_KEY', 'sk_test_...'); // Cambiar por tu clave secreta
define('STRIPE_WEBHOOK_SECRET', 'whsec_...'); // Cambiar por tu webhook secret

// Configuración de sesiones
define('SESSION_NAME', 'charolais_session');
define('SESSION_LIFETIME', 86400); // 24 horas
define('SESSION_SECURE', true); // true para HTTPS
define('SESSION_HTTP_ONLY', true);

// Configuración de archivos
define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// Configuración de envío
define('FREE_SHIPPING_FIRST_PURCHASE', true);
define('STANDARD_SHIPPING_COST', 150); // MXN
define('STANDARD_SHIPPING_PERCENTAGE', 0.10); // 10%

// Configuración de seguridad
define('CSRF_TOKEN_NAME', 'charolais_csrf');
define('PASSWORD_MIN_LENGTH', 8);
define('LOGIN_MAX_ATTEMPTS', 5);
define('LOGIN_LOCKOUT_TIME', 900); // 15 minutos

// Configuración de errores
define('DISPLAY_ERRORS', false); // false en producción
define('LOG_ERRORS', true);
define('ERROR_LOG_FILE', __DIR__ . '/../logs/error.log');

// Configuración de timezone
date_default_timezone_set('America/Mexico_City');

// Configuración de idioma
setlocale(LC_ALL, 'es_MX.UTF-8');

// Configuración de memoria
ini_set('memory_limit', '256M');
ini_set('max_execution_time', 300); // 5 minutos

// Configuración de sesiones
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', SESSION_SECURE ? 1 : 0);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', SESSION_LIFETIME);

// Configuración de errores
if (DISPLAY_ERRORS) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

if (LOG_ERRORS) {
    ini_set('log_errors', 1);
    ini_set('error_log', ERROR_LOG_FILE);
}

// Crear directorio de logs si no existe
$log_dir = dirname(ERROR_LOG_FILE);
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0755, true);
}

// Crear directorio de uploads si no existe
if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

// Configuración de headers de seguridad
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// Configuración de CORS (si es necesario)
header('Access-Control-Allow-Origin: ' . APP_URL);
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Función para obtener configuración del sistema
function getSystemSetting($key, $default = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $result ? $result['setting_value'] : $default;
    } catch (Exception $e) {
        error_log("Error getting system setting: " . $e->getMessage());
        return $default;
    }
}

// Función para actualizar configuración del sistema
function updateSystemSetting($key, $value) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO system_settings (setting_key, setting_value) 
            VALUES (?, ?) 
            ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
        ");
        return $stmt->execute([$key, $value]);
    } catch (Exception $e) {
        error_log("Error updating system setting: " . $e->getMessage());
        return false;
    }
}

// Función para validar email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// Función para sanitizar input
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Función para generar token CSRF
function generateCSRFToken() {
    if (!isset($_SESSION[CSRF_TOKEN_NAME])) {
        $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
    }
    return $_SESSION[CSRF_TOKEN_NAME];
}

// Función para validar token CSRF
function validateCSRFToken($token) {
    return isset($_SESSION[CSRF_TOKEN_NAME]) && hash_equals($_SESSION[CSRF_TOKEN_NAME], $token);
}

// Función para redireccionar
function redirect($url) {
    header("Location: $url");
    exit();
}

// Función para respuesta JSON
function jsonResponse($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

// Función para error JSON
function jsonError($message, $status = 400) {
    jsonResponse(['error' => $message], $status);
}

// Función para éxito JSON
function jsonSuccess($data = null, $message = 'Success') {
    $response = ['success' => true, 'message' => $message];
    if ($data !== null) {
        $response['data'] = $data;
    }
    jsonResponse($response);
}

// Función para log de actividad
function logActivity($action, $details = '', $user_id = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO activity_logs (action, details, user_id, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            $action,
            $details,
            $user_id,
            $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);
    } catch (Exception $e) {
        error_log("Error logging activity: " . $e->getMessage());
    }
}

// Función para formatear precio
function formatPrice($price) {
    return '$' . number_format($price, 2, '.', ',') . ' MXN';
}

// Función para formatear fecha
function formatDate($date, $format = 'd/m/Y H:i') {
    return date($format, strtotime($date));
}

// Función para generar SKU único
function generateSKU($prefix = 'CH') {
    return $prefix . strtoupper(substr(md5(uniqid()), 0, 8));
}

// Función para validar imagen
function isValidImage($file) {
    $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    $max_size = MAX_FILE_SIZE;
    
    return in_array($file['type'], $allowed_types) && $file['size'] <= $max_size;
}

// Función para subir imagen
function uploadImage($file, $directory = UPLOAD_DIR) {
    if (!isValidImage($file)) {
        return false;
    }
    
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = uniqid() . '.' . $extension;
    $filepath = $directory . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        return $filename;
    }
    
    return false;
}

// Función para eliminar imagen
function deleteImage($filename, $directory = UPLOAD_DIR) {
    $filepath = $directory . $filename;
    if (file_exists($filepath)) {
        return unlink($filepath);
    }
    return false;
}

// Función para verificar si es primera compra
function isFirstPurchase($email) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE customer_email = ? AND status = 'paid'");
        $stmt->execute([$email]);
        return $stmt->fetchColumn() == 0;
    } catch (Exception $e) {
        error_log("Error checking first purchase: " . $e->getMessage());
        return true; // Por defecto, asumir primera compra
    }
}

// Función para calcular envío
function calculateShipping($subtotal, $isFirstPurchase = false) {
    if ($isFirstPurchase && FREE_SHIPPING_FIRST_PURCHASE) {
        return 0;
    }
    
    $standard_cost = STANDARD_SHIPPING_COST;
    $percentage_cost = $subtotal * STANDARD_SHIPPING_PERCENTAGE;
    
    return max($standard_cost, $percentage_cost);
}

// Configuración de sesión
session_name(SESSION_NAME);
session_start();

// Verificar si la sesión ha expirado
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > SESSION_LIFETIME)) {
    session_unset();
    session_destroy();
    session_start();
}

$_SESSION['last_activity'] = time();
?> 