<?php
/**
 * Conexión a base de datos MySQL para Charolais Store
 * Manejo de conexión PDO y funciones de base de datos
 */

require_once 'config.php';

class Database {
    private static $instance = null;
    private $pdo;
    
    private function __construct() {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
            ];
            
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            
        } catch (PDOException $e) {
            error_log("Error de conexión a base de datos: " . $e->getMessage());
            throw new Exception("Error de conexión a la base de datos");
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->pdo;
    }
    
    /**
     * Ejecutar consulta SELECT
     */
    public function select($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Error en consulta SELECT: " . $e->getMessage());
            throw new Exception("Error en consulta de base de datos");
        }
    }
    
    /**
     * Ejecutar consulta SELECT y obtener un solo registro
     */
    public function selectOne($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Error en consulta SELECT ONE: " . $e->getMessage());
            throw new Exception("Error en consulta de base de datos");
        }
    }
    
    /**
     * Ejecutar consulta INSERT
     */
    public function insert($table, $data) {
        try {
            $columns = array_keys($data);
            $placeholders = ':' . implode(', :', $columns);
            $sql = "INSERT INTO $table (" . implode(', ', $columns) . ") VALUES ($placeholders)";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($data);
            
            return $this->pdo->lastInsertId();
        } catch (PDOException $e) {
            error_log("Error en consulta INSERT: " . $e->getMessage());
            throw new Exception("Error al insertar datos");
        }
    }
    
    /**
     * Ejecutar consulta UPDATE
     */
    public function update($table, $data, $where, $whereParams = []) {
        try {
            $setClause = [];
            foreach (array_keys($data) as $column) {
                $setClause[] = "$column = :$column";
            }
            
            $sql = "UPDATE $table SET " . implode(', ', $setClause) . " WHERE $where";
            
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute(array_merge($data, $whereParams));
            
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("Error en consulta UPDATE: " . $e->getMessage());
            throw new Exception("Error al actualizar datos");
        }
    }
    
    /**
     * Ejecutar consulta DELETE
     */
    public function delete($table, $where, $params = []) {
        try {
            $sql = "DELETE FROM $table WHERE $where";
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("Error en consulta DELETE: " . $e->getMessage());
            throw new Exception("Error al eliminar datos");
        }
    }
    
    /**
     * Ejecutar consulta personalizada
     */
    public function execute($sql, $params = []) {
        try {
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            error_log("Error en consulta personalizada: " . $e->getMessage());
            throw new Exception("Error en consulta de base de datos");
        }
    }
    
    /**
     * Iniciar transacción
     */
    public function beginTransaction() {
        return $this->pdo->beginTransaction();
    }
    
    /**
     * Confirmar transacción
     */
    public function commit() {
        return $this->pdo->commit();
    }
    
    /**
     * Revertir transacción
     */
    public function rollback() {
        return $this->pdo->rollback();
    }
    
    /**
     * Verificar si estamos en una transacción
     */
    public function inTransaction() {
        return $this->pdo->inTransaction();
    }
    
    /**
     * Obtener estadísticas de la base de datos
     */
    public function getStats() {
        try {
            $stats = [];
            
            // Contar productos
            $result = $this->selectOne("SELECT COUNT(*) as count FROM products WHERE is_active = 1");
            $stats['products'] = $result['count'];
            
            // Contar categorías
            $result = $this->selectOne("SELECT COUNT(*) as count FROM categories WHERE is_active = 1");
            $stats['categories'] = $result['count'];
            
            // Contar órdenes
            $result = $this->selectOne("SELECT COUNT(*) as count FROM orders");
            $stats['orders'] = $result['count'];
            
            // Ventas totales
            $result = $this->selectOne("SELECT SUM(total_amount) as total FROM orders WHERE status = 'paid'");
            $stats['total_sales'] = $result['total'] ?? 0;
            
            // Órdenes del mes
            $result = $this->selectOne("
                SELECT COUNT(*) as count 
                FROM orders 
                WHERE status = 'paid' 
                AND MONTH(created_at) = MONTH(CURRENT_DATE())
                AND YEAR(created_at) = YEAR(CURRENT_DATE())
            ");
            $stats['orders_this_month'] = $result['count'];
            
            return $stats;
        } catch (Exception $e) {
            error_log("Error obteniendo estadísticas: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Verificar si una tabla existe
     */
    public function tableExists($tableName) {
        try {
            $sql = "SHOW TABLES LIKE ?";
            $result = $this->select($sql, [$tableName]);
            return !empty($result);
        } catch (Exception $e) {
            return false;
        }
    }
    
    /**
     * Obtener estructura de una tabla
     */
    public function getTableStructure($tableName) {
        try {
            return $this->select("DESCRIBE $tableName");
        } catch (Exception $e) {
            error_log("Error obteniendo estructura de tabla: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Crear tabla de logs de actividad si no existe
     */
    public function createActivityLogsTable() {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS activity_logs (
                id INT AUTO_INCREMENT PRIMARY KEY,
                action VARCHAR(100) NOT NULL,
                details TEXT,
                user_id INT,
                ip_address VARCHAR(45),
                user_agent TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            
            $this->execute($sql);
            return true;
        } catch (Exception $e) {
            error_log("Error creando tabla de logs: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Limpiar logs antiguos
     */
    public function cleanOldLogs($days = 30) {
        try {
            $sql = "DELETE FROM activity_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)";
            $this->execute($sql, [$days]);
            return true;
        } catch (Exception $e) {
            error_log("Error limpiando logs: " . $e->getMessage());
            return false;
        }
    }
}

// Inicializar conexión global
try {
    $db = Database::getInstance();
    $pdo = $db->getConnection();
    
    // Crear tabla de logs si no existe
    $db->createActivityLogsTable();
    
} catch (Exception $e) {
    error_log("Error inicializando base de datos: " . $e->getMessage());
    die("Error de conexión a la base de datos. Por favor, verifica la configuración.");
}

// Función helper para obtener instancia de base de datos
function getDB() {
    return Database::getInstance();
}

// Función helper para obtener conexión PDO
function getPDO() {
    return Database::getInstance()->getConnection();
}
?> 