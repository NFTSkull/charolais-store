<?php
/**
 * API de Checkout con Stripe
 * Procesa pagos y crea sesiones de Stripe
 */

require_once '../includes/database.php';

// Verificar método HTTP
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('Método no permitido', 405);
}

// Obtener datos JSON
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    jsonError('Datos JSON inválidos', 400);
}

// Validar datos requeridos
if (empty($input['items']) || empty($input['customer'])) {
    jsonError('Datos de compra incompletos', 400);
}

$items = $input['items'];
$customer = $input['customer'];
$isFirstPurchase = $input['isFirstPurchase'] ?? false;

// Validar email
if (!isValidEmail($customer['email'])) {
    jsonError('Email inválido', 400);
}

// Validar nombre
if (empty($customer['name'])) {
    jsonError('Nombre requerido', 400);
}

try {
    // Calcular totales
    $subtotal = 0;
    $lineItems = [];
    
    foreach ($items as $item) {
        // Validar producto
        $product = $db->selectOne("SELECT * FROM products WHERE id = ? AND is_active = 1", [$item['productId']]);
        
        if (!$product) {
            jsonError('Producto no encontrado: ' . $item['name'], 400);
        }
        
        // Validar variante si existe
        if (!empty($item['variantId'])) {
            $variant = $db->selectOne("SELECT * FROM product_variants WHERE id = ? AND product_id = ? AND is_active = 1", 
                [$item['variantId'], $item['productId']]);
            
            if (!$variant) {
                jsonError('Variante no encontrada', 400);
            }
            
            $price = $variant['price_override'] ?: $product['price'];
            $stock = $variant['stock_quantity'];
        } else {
            $price = $product['price'];
            $stock = $product['stock_quantity'];
        }
        
        // Verificar stock
        if ($stock < $item['quantity']) {
            jsonError('Stock insuficiente para: ' . $item['name'], 400);
        }
        
        $itemTotal = $price * $item['quantity'];
        $subtotal += $itemTotal;
        
        // Preparar item para Stripe
        $lineItems[] = [
            'price_data' => [
                'currency' => 'mxn',
                'product_data' => [
                    'name' => $item['name'],
                    'description' => $item['variant'] ? "Variante: {$item['variant']}" : $product['description'],
                    'images' => getProductImages($item['productId'], $item['variantId'] ?? null)
                ],
                'unit_amount' => (int)($price * 100) // Stripe usa centavos
            ],
            'quantity' => $item['quantity']
        ];
    }
    
    // Calcular envío
    $shipping = calculateShipping($subtotal, $isFirstPurchase);
    
    if ($shipping > 0) {
        $lineItems[] = [
            'price_data' => [
                'currency' => 'mxn',
                'product_data' => [
                    'name' => 'Envío',
                    'description' => 'Costo de envío'
                ],
                'unit_amount' => (int)($shipping * 100)
            ],
            'quantity' => 1
        ];
    }
    
    $total = $subtotal + $shipping;
    
    // Verificar total mínimo
    if ($total < 1) {
        jsonError('Total mínimo no alcanzado', 400);
    }
    
    // Configurar Stripe
    $stripeSecretKey = getSystemSetting('stripe_secret_key', STRIPE_SECRET_KEY);
    
    if (empty($stripeSecretKey) || $stripeSecretKey === 'sk_test_...') {
        jsonError('Configuración de Stripe incompleta', 500);
    }
    
    // Inicializar Stripe
    require_once '../vendor/autoload.php';
    \Stripe\Stripe::setApiKey($stripeSecretKey);
    
    // Crear sesión de checkout
    $sessionData = [
        'payment_method_types' => ['card'],
        'line_items' => $lineItems,
        'mode' => 'payment',
        'success_url' => APP_URL . '/success.php?session_id={CHECKOUT_SESSION_ID}',
        'cancel_url' => APP_URL . '/cancel.php',
        'locale' => 'es',
        'currency' => 'mxn',
        'customer_email' => $customer['email'],
        'metadata' => [
            'customer_name' => $customer['name'],
            'is_first_purchase' => $isFirstPurchase ? 'true' : 'false',
            'items_count' => count($items)
        ]
    ];
    
    // Agregar información de envío si es necesario
    if ($shipping > 0) {
        $sessionData['shipping_address_collection'] = [
            'allowed_countries' => ['MX']
        ];
    }
    
    // Crear sesión
    $session = \Stripe\Checkout\Session::create($sessionData);
    
    // Guardar orden en base de datos
    $orderId = $db->insert('orders', [
        'stripe_session_id' => $session->id,
        'customer_email' => $customer['email'],
        'customer_name' => $customer['name'],
        'total_amount' => $total,
        'shipping_amount' => $shipping,
        'status' => 'pending',
        'is_first_purchase' => $isFirstPurchase
    ]);
    
    // Guardar items de la orden
    foreach ($items as $item) {
        $product = $db->selectOne("SELECT * FROM products WHERE id = ?", [$item['productId']]);
        
        $db->insert('order_items', [
            'order_id' => $orderId,
            'product_id' => $item['productId'],
            'variant_id' => $item['variantId'] ?? null,
            'product_name' => $item['name'],
            'variant_name' => $item['variant'] ?? null,
            'quantity' => $item['quantity'],
            'unit_price' => $item['price'],
            'total_price' => $item['price'] * $item['quantity']
        ]);
        
        // Actualizar stock
        if (!empty($item['variantId'])) {
            $db->update('product_variants', 
                ['stock_quantity' => $variant['stock_quantity'] - $item['quantity']], 
                'id = ?', 
                [$item['variantId']]
            );
        } else {
            $db->update('products', 
                ['stock_quantity' => $product['stock_quantity'] - $item['quantity']], 
                'id = ?', 
                [$item['productId']]
            );
        }
    }
    
    // Log de actividad
    logActivity('checkout_created', "Orden creada: #$orderId - Total: $" . number_format($total, 2) . " MXN", null);
    
    // Respuesta exitosa
    jsonSuccess([
        'sessionId' => $session->id,
        'orderId' => $orderId,
        'total' => $total,
        'shipping' => $shipping
    ], 'Sesión de pago creada exitosamente');
    
} catch (\Stripe\Exception\ApiErrorException $e) {
    error_log("Error de Stripe: " . $e->getMessage());
    jsonError('Error al procesar el pago: ' . $e->getMessage(), 500);
    
} catch (Exception $e) {
    error_log("Error en checkout: " . $e->getMessage());
    jsonError('Error interno del servidor', 500);
}

/**
 * Obtener imágenes del producto para Stripe
 */
function getProductImages($productId, $variantId = null) {
    global $db;
    
    $images = [];
    
    try {
        if ($variantId) {
            // Imágenes de la variante
            $variantImages = $db->select("SELECT image_url FROM variant_images WHERE variant_id = ? ORDER BY sort_order", [$variantId]);
            foreach ($variantImages as $img) {
                $images[] = APP_URL . '/uploads/' . $img['image_url'];
            }
        }
        
        // Si no hay imágenes de variante, usar imágenes del producto
        if (empty($images)) {
            $productImages = $db->select("SELECT image_url FROM product_images WHERE product_id = ? ORDER BY sort_order", [$productId]);
            foreach ($productImages as $img) {
                $images[] = APP_URL . '/uploads/' . $img['image_url'];
            }
        }
        
        // Filtrar URLs locales en desarrollo
        if (strpos(APP_URL, 'localhost') !== false || strpos(APP_URL, '127.0.0.1') !== false) {
            $images = []; // No enviar imágenes locales a Stripe
        }
        
        return $images;
        
    } catch (Exception $e) {
        error_log("Error obteniendo imágenes: " . $e->getMessage());
        return [];
    }
}
?> 