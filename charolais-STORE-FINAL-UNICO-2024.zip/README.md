# 🎩 Charolais Store - PHP Version

Tienda online de productos cowboy convertida de Node.js a PHP para HostGator.

## 🚀 Características

- ✅ **Gestión completa de productos** con imágenes y variantes
- ✅ **Sistema de categorías** para organizar productos
- ✅ **Carrito de compras** con localStorage
- ✅ **Checkout con Stripe** para pagos seguros
- ✅ **Panel de administración** completo
- ✅ **Envío gratis en primera compra**
- ✅ **Diseño responsive** con tema cowboy
- ✅ **Base de datos MySQL** optimizada
- ✅ **Sistema de autenticación** seguro

## 📋 Requisitos

### Servidor
- PHP 7.4 o superior
- MySQL 5.7 o superior
- Extensiones PHP: PDO, JSON, cURL, GD
- Composer (para dependencias)

### Hosting
- HostGator (compatible)
- cPanel disponible
- SSL habilitado (recomendado)

## 🛠️ Instalación

### 1. Preparar Base de Datos

```sql
-- Crear base de datos
CREATE DATABASE charolais_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Crear usuario (opcional)
CREATE USER 'charolais_user'@'localhost' IDENTIFIED BY 'tu_password_seguro';
GRANT ALL PRIVILEGES ON charolais_store.* TO 'charolais_user'@'localhost';
FLUSH PRIVILEGES;
```

### 2. Configurar Aplicación

1. **Editar configuración:**
   ```bash
   nano includes/config.php
   ```

2. **Actualizar credenciales de base de datos:**
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'charolais_store');
   define('DB_USER', 'tu_usuario_mysql');
   define('DB_PASS', 'tu_password_mysql');
   ```

3. **Configurar Stripe:**
   ```php
   define('STRIPE_PUBLISHABLE_KEY', 'pk_test_tu_clave_publica');
   define('STRIPE_SECRET_KEY', 'sk_test_tu_clave_secreta');
   ```

4. **Configurar URL de la aplicación:**
   ```php
   define('APP_URL', 'https://tudominio.com');
   ```

### 3. Instalar Dependencias

```bash
# Instalar Composer (si no está instalado)
curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/local/bin/composer

# Instalar dependencias
composer install --no-dev --optimize-autoloader
```

### 4. Migrar Datos (si tienes datos existentes)

```bash
# Ejecutar script de migración
php migrate-sqlite-to-mysql.php
```

### 5. Configurar Permisos

```bash
# Crear directorios necesarios
mkdir -p uploads logs
chmod 755 uploads logs
chmod 644 includes/config.php
```

### 6. Configurar HostGator

1. **Subir archivos a cPanel:**
   - Usar File Manager o FTP
   - Subir todos los archivos a `public_html/`

2. **Configurar base de datos MySQL:**
   - Ir a MySQL Databases en cPanel
   - Crear base de datos y usuario
   - Importar estructura SQL

3. **Configurar dominio:**
   - Asegurar que el dominio apunte al directorio correcto
   - Habilitar SSL si es posible

## 🔧 Configuración Avanzada

### Variables de Entorno (Opcional)

Crear archivo `.env` en la raíz:

```env
DB_HOST=localhost
DB_NAME=charolais_store
DB_USER=tu_usuario
DB_PASS=tu_password

STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...

APP_URL=https://tudominio.com
APP_ENV=production
```

### Configuración de Stripe

1. **Obtener claves de Stripe:**
   - Ir a [Stripe Dashboard](https://dashboard.stripe.com)
   - Copiar claves de API (test/live)

2. **Configurar webhooks (opcional):**
   - URL: `https://tudominio.com/api/webhook.php`
   - Eventos: `checkout.session.completed`, `payment_intent.succeeded`

### Configuración de Email

Para notificaciones de pedidos, configurar en `includes/config.php`:

```php
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'tu_email@gmail.com');
define('SMTP_PASS', 'tu_password_app');
```

## 📁 Estructura de Archivos

```
charolais-php/
├── index.php                 # Página principal
├── success.php              # Página de pago exitoso
├── cancel.php               # Página de pago cancelado
├── admin/                   # Panel de administración
│   ├── index.php
│   ├── login.php
│   └── products.php
├── api/                     # Endpoints de API
│   ├── products.php
│   ├── categories.php
│   ├── variants.php
│   └── checkout.php
├── includes/                # Archivos de configuración
│   ├── config.php
│   ├── database.php
│   ├── auth.php
│   └── functions.php
├── uploads/                 # Imágenes subidas
├── css/                     # Estilos
│   └── styles.css
├── js/                      # JavaScript
│   ├── main.js
│   └── admin.js
├── database/                # Base de datos
│   └── charolais.sql
├── logs/                    # Logs de errores
├── vendor/                  # Dependencias (generado por Composer)
├── composer.json
└── README.md
```

## 🔐 Seguridad

### Configuraciones Recomendadas

1. **Archivo .htaccess:**
   ```apache
   # Proteger archivos sensibles
   <Files "config.php">
       Order allow,deny
       Deny from all
   </Files>
   
   # Forzar HTTPS
   RewriteEngine On
   RewriteCond %{HTTPS} off
   RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
   ```

2. **Permisos de archivos:**
   ```bash
   chmod 644 *.php
   chmod 755 uploads/ logs/
   chmod 600 includes/config.php
   ```

3. **Configuración PHP:**
   ```ini
   display_errors = Off
   log_errors = On
   error_log = /path/to/logs/error.log
   session.cookie_httponly = 1
   session.cookie_secure = 1
   ```

## 🚀 Despliegue en HostGator

### Pasos de Despliegue

1. **Preparar archivos:**
   ```bash
   # Crear archivo ZIP
   zip -r charolais-php.zip charolais-php/ -x "*.git*" "node_modules/*" "*.log"
   ```

2. **Subir a HostGator:**
   - Usar File Manager en cPanel
   - Extraer archivos en `public_html/`
   - Configurar base de datos MySQL

3. **Configurar dominio:**
   - Asegurar que apunte al directorio correcto
   - Configurar SSL si está disponible

4. **Instalar dependencias:**
   ```bash
   composer install --no-dev --optimize-autoloader
   ```

5. **Configurar aplicación:**
   - Editar `includes/config.php`
   - Configurar credenciales de base de datos
   - Configurar claves de Stripe

### Verificación Post-Despliegue

1. **Verificar archivos:**
   - ✅ `index.php` carga correctamente
   - ✅ Conexión a base de datos funciona
   - ✅ Imágenes se cargan desde `uploads/`

2. **Probar funcionalidades:**
   - ✅ Panel de admin accesible
   - ✅ Productos se muestran
   - ✅ Carrito funciona
   - ✅ Checkout con Stripe

3. **Verificar logs:**
   - Revisar `logs/error.log` para errores
   - Verificar permisos de archivos

## 🔧 Mantenimiento

### Actualizaciones

1. **Backup antes de actualizar:**
   ```bash
   # Backup de base de datos
   mysqldump -u usuario -p charolais_store > backup_$(date +%Y%m%d).sql
   
   # Backup de archivos
   tar -czf backup_$(date +%Y%m%d).tar.gz charolais-php/
   ```

2. **Actualizar código:**
   ```bash
   # Subir nuevos archivos
   # Ejecutar migraciones si es necesario
   # Verificar funcionalidades
   ```

### Monitoreo

1. **Logs de errores:**
   - Revisar `logs/error.log` regularmente
   - Configurar alertas por email

2. **Base de datos:**
   - Monitorear tamaño de base de datos
   - Optimizar tablas regularmente

3. **Rendimiento:**
   - Monitorear tiempo de carga
   - Optimizar imágenes si es necesario

## 🆘 Solución de Problemas

### Problemas Comunes

1. **Error de conexión a base de datos:**
   - Verificar credenciales en `config.php`
   - Verificar que MySQL esté funcionando
   - Verificar permisos de usuario

2. **Imágenes no se cargan:**
   - Verificar permisos de directorio `uploads/`
   - Verificar rutas en `config.php`
   - Verificar que las imágenes existan

3. **Error de Stripe:**
   - Verificar claves de API
   - Verificar que las claves sean correctas (test/live)
   - Verificar configuración de webhooks

4. **Error 500:**
   - Revisar `logs/error.log`
   - Verificar permisos de archivos
   - Verificar sintaxis PHP

### Logs de Debug

Habilitar debug temporalmente:

```php
// En config.php
define('DISPLAY_ERRORS', true);
define('LOG_ERRORS', true);
```

## 📞 Soporte

- **Email:** contacto@charolais.com
- **Documentación:** Este README
- **Issues:** Crear issue en el repositorio

## 📄 Licencia

MIT License - Ver archivo LICENSE para detalles.

---

**¡Gracias por usar Charolais Store!** 🎩🤠 