<?php
/**
 * INSTALADOR FINAL CHAROLAIS 2024
 * COMPLETAMENTE LIMPIO - SIN JQUERY - SIN DEPENDENCIAS EXTERNAS
 */

// Verificar si ya está instalado
if (file_exists('includes/config.php') && !isset($_GET['force'])) {
    die('La aplicación ya está instalada. Agrega ?force=1 para forzar la reinstalación.');
}

$step = $_GET['step'] ?? 1;
$errors = [];
$success = [];

// Procesar formulario de configuración
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'] ?? '';
    $db_name = $_POST['db_name'] ?? '';
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';
    $app_url = $_POST['app_url'] ?? '';
    $stripe_pk = $_POST['stripe_pk'] ?? '';
    $stripe_sk = $_POST['stripe_sk'] ?? '';
    $admin_user = $_POST['admin_user'] ?? '';
    $admin_pass = $_POST['admin_pass'] ?? '';
    $admin_email = $_POST['admin_email'] ?? '';
    
    // Validar datos
    if (empty($db_host) || empty($db_name) || empty($db_user)) {
        $errors[] = 'Todos los campos de base de datos son requeridos';
    }
    
    if (empty($app_url)) {
        $errors[] = 'La URL de la aplicación es requerida';
    }
    
    if (empty($admin_user) || empty($admin_pass) || empty($admin_email)) {
        $errors[] = 'Los datos del administrador son requeridos';
    }
    
    if (strlen($admin_pass) < 6) {
        $errors[] = 'La contraseña del administrador debe tener al menos 6 caracteres';
    }
    
    // Si no hay errores, proceder con la instalación
    if (empty($errors)) {
        try {
            // Probar conexión a base de datos
            $pdo = new PDO("mysql:host=$db_host;charset=utf8mb4", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Crear base de datos si no existe
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db_name`");
            
            // Crear estructura de tablas
            createTables($pdo);
            
            // Crear archivo de configuración
            createConfigFile($db_host, $db_name, $db_user, $db_pass, $app_url, $stripe_pk, $stripe_sk);
            
            // Crear administrador
            createAdmin($pdo, $admin_user, $admin_pass, $admin_email);
            
            // Crear directorios necesarios
            createDirectories();
            
            $success[] = 'Instalación completada exitosamente';
            $step = 3;
            
        } catch (Exception $e) {
            $errors[] = 'Error durante la instalación: ' . $e->getMessage();
        }
    }
}

function createTables($pdo) {
    $tables = [
        // Tabla de administradores
        "CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            email VARCHAR(100),
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de categorías
        "CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de productos
        "CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            category_id INT,
            stock_quantity INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            rating DECIMAL(3,2) DEFAULT 0,
            reviews_count INT DEFAULT 0,
            sort_order INT DEFAULT 0,
            stripe_price_id VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
        )",
        
        // Tabla de imágenes de productos
        "CREATE TABLE IF NOT EXISTS product_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        )",
        
        // Tabla de variantes de productos
        "CREATE TABLE IF NOT EXISTS product_variants (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            variant_name VARCHAR(100) NOT NULL,
            sku VARCHAR(100),
            price_override DECIMAL(10,2),
            stock_quantity INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        )",
        
        // Tabla de imágenes de variantes
        "CREATE TABLE IF NOT EXISTS variant_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            variant_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE
        )",
        
        // Tabla de órdenes
        "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            stripe_session_id VARCHAR(255),
            customer_email VARCHAR(100),
            customer_name VARCHAR(100),
            total_amount DECIMAL(10,2) NOT NULL,
            shipping_amount DECIMAL(10,2) DEFAULT 0,
            status ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
            shipping_address TEXT,
            billing_address TEXT,
            is_first_purchase BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de items de órdenes
        "CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            product_id INT,
            variant_id INT,
            product_name VARCHAR(200) NOT NULL,
            variant_name VARCHAR(100),
            quantity INT NOT NULL,
            unit_price DECIMAL(10,2) NOT NULL,
            total_price DECIMAL(10,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE SET NULL
        )",
        
        // Tabla de configuraciones del sistema
        "CREATE TABLE IF NOT EXISTS system_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) UNIQUE NOT NULL,
            setting_value TEXT,
            description VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )"
    ];
    
    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }
}

function createConfigFile($db_host, $db_name, $db_user, $db_pass, $app_url, $stripe_pk, $stripe_sk) {
    // Crear directorio includes si no existe
    if (!is_dir('includes')) {
        mkdir('includes', 0755, true);
    }
    
    $config = "<?php
/**
 * Configuración de Charolais Store
 * Generado automáticamente por el instalador
 */

// Configuración de base de datos
define('DB_HOST', '$db_host');
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASS', '$db_pass');

// Configuración de la aplicación
define('APP_URL', '$app_url');
define('APP_NAME', 'Charolais Store');
define('APP_VERSION', '1.0.0');

// Configuración de Stripe
define('STRIPE_PUBLISHABLE_KEY', '$stripe_pk');
define('STRIPE_SECRET_KEY', '$stripe_sk');

// Configuración de sesión
define('SESSION_LIFETIME', 86400); // 24 horas

// Configuración de archivos
define('UPLOAD_DIR', 'uploads/');
define('MAX_FILE_SIZE', 10485760); // 10MB

// Configuración de email (opcional)
define('SMTP_HOST', '');
define('SMTP_PORT', 587);
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('FROM_EMAIL', 'noreply@charolais.com');
define('FROM_NAME', 'Charolais Store');

// Configuración de seguridad
define('HASH_ALGO', 'sha256');
define('ENCRYPTION_KEY', '" . bin2hex(random_bytes(32)) . "');

// Configuración de debug (cambiar a false en producción)
define('DEBUG_MODE', false);
define('LOG_ERRORS', true);

// Zona horaria
date_default_timezone_set('America/Mexico_City');
";

    file_put_contents('includes/config.php', $config);
}

function createAdmin($pdo, $username, $password, $email) {
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash, email) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE password_hash = ?, email = ?");
    $stmt->execute([$username, $password_hash, $email, $password_hash, $email]);
}

function createDirectories() {
    $dirs = ['uploads', 'uploads/products', 'uploads/categories', 'logs', 'cache'];
    
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤠 Instalador Charolais Final 2024</title>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .installer-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            padding: 40px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h1 {
            color: #8B4513;
            margin-bottom: 10px;
            font-size: 2.5em;
        }
        
        .header p {
            color: #666;
            font-size: 1.1em;
        }
        
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
        }
        
        .step {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 15px;
            font-weight: bold;
            color: white;
            font-size: 1.2em;
        }
        
        .step.active {
            background: #28a745;
            box-shadow: 0 0 20px rgba(40, 167, 69, 0.5);
        }
        
        .step.pending {
            background: #ccc;
            color: #666;
        }
        
        .alert {
            padding: 20px;
            margin-bottom: 25px;
            border-radius: 8px;
            border-left: 5px solid;
        }
        
        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border-left-color: #dc3545;
        }
        
        .alert-success {
            background: #d4edda;
            color: #155724;
            border-left-color: #28a745;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
            font-size: 1.1em;
        }
        
        .form-control {
            width: 100%;
            padding: 15px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #8B4513;
            box-shadow: 0 0 10px rgba(139, 69, 19, 0.3);
        }
        
        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 8px;
            font-size: 18px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            text-align: center;
            transition: all 0.3s ease;
            font-weight: bold;
        }
        
        .btn-primary {
            background: #8B4513;
            color: white;
        }
        
        .btn-primary:hover {
            background: #6d3410;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(139, 69, 19, 0.4);
        }
        
        .btn-success {
            background: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background: #218838;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.4);
        }
        
        .btn-lg {
            padding: 20px 40px;
            font-size: 20px;
        }
        
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: -15px;
        }
        
        .col-md-6 {
            flex: 0 0 50%;
            padding: 15px;
        }
        
        .text-center {
            text-align: center;
        }
        
        .text-success {
            color: #28a745;
        }
        
        .text-danger {
            color: #dc3545;
        }
        
        .mb-3 {
            margin-bottom: 1rem;
        }
        
        .mt-4 {
            margin-top: 2rem;
        }
        
        .card {
            background: #f8f9fa;
            border: 2px solid #dee2e6;
            border-radius: 10px;
            padding: 25px;
            margin-bottom: 25px;
            transition: all 0.3s ease;
        }
        
        .card:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        
        .card h5 {
            margin-bottom: 20px;
            color: #8B4513;
            font-size: 1.3em;
        }
        
        ul {
            padding-left: 25px;
        }
        
        li {
            margin-bottom: 8px;
            font-size: 1.05em;
        }
        
        code {
            background: #f1f3f4;
            padding: 4px 8px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            color: #d63384;
        }
        
        .success-icon {
            font-size: 5em;
            color: #28a745;
            margin-bottom: 20px;
        }
        
        @media (max-width: 768px) {
            .col-md-6 {
                flex: 0 0 100%;
            }
            
            .installer-card {
                padding: 25px;
            }
            
            .header h1 {
                font-size: 2em;
            }
            
            .step {
                width: 40px;
                height: 40px;
                margin: 0 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="installer-card">
            <div class="header">
                <h1>🤠 Charolais Store</h1>
                <p><strong>Instalador Final 2024 - Completamente Limpio</strong></p>
            </div>
            
            <!-- Indicador de pasos -->
            <div class="step-indicator">
                <div class="step <?php echo $step >= 1 ? 'active' : 'pending'; ?>">1</div>
                <div class="step <?php echo $step >= 2 ? 'active' : 'pending'; ?>">2</div>
                <div class="step <?php echo $step >= 3 ? 'active' : 'pending'; ?>">3</div>
            </div>
            
            <!-- Mensajes de error -->
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <h5>❌ Errores encontrados:</h5>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <!-- Mensajes de éxito -->
            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <h5>✅ ¡Instalación exitosa!</h5>
                    <ul>
                        <?php foreach ($success as $msg): ?>
                            <li><?php echo htmlspecialchars($msg); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
                <!-- Paso 1: Verificación del sistema -->
                <div class="text-center">
                    <h3>🔍 Verificación del Sistema</h3>
                    <p>Verificando que tu servidor cumple con los requisitos...</p>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card">
                                <h5>🖥️ Requisitos del Servidor</h5>
                                <ul style="list-style: none; padding-left: 0;">
                                    <li>
                                        <?php echo version_compare(PHP_VERSION, '7.4.0', '>=') ? '✅' : '❌'; ?>
                                        PHP 7.4+ (Actual: <?php echo PHP_VERSION; ?>)
                                    </li>
                                    <li>
                                        <?php echo extension_loaded('pdo') ? '✅' : '❌'; ?>
                                        Extensión PDO
                                    </li>
                                    <li>
                                        <?php echo extension_loaded('pdo_mysql') ? '✅' : '❌'; ?>
                                        Extensión PDO MySQL
                                    </li>
                                    <li>
                                        <?php echo extension_loaded('json') ? '✅' : '❌'; ?>
                                        Extensión JSON
                                    </li>
                                    <li>
                                        <?php echo extension_loaded('curl') ? '✅' : '❌'; ?>
                                        Extensión cURL
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <h5>📁 Permisos de Archivos</h5>
                                <ul style="list-style: none; padding-left: 0;">
                                    <li>
                                        <?php echo is_writable('.') ? '✅' : '❌'; ?>
                                        Directorio actual escribible
                                    </li>
                                    <li>
                                        <?php echo function_exists('mkdir') ? '✅' : '❌'; ?>
                                        Función mkdir disponible
                                    </li>
                                    <li>
                                        <?php echo function_exists('file_put_contents') ? '✅' : '❌'; ?>
                                        Función file_put_contents disponible
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <a href="?step=2" class="btn btn-primary btn-lg">
                            Continuar ➡️
                        </a>
                    </div>
                </div>
                
            <?php elseif ($step == 2): ?>
                <!-- Paso 2: Configuración -->
                <form method="POST" action="?step=2">
                    <h3>⚙️ Configuración de la Aplicación</h3>
                    <p>Completa la información necesaria para configurar tu tienda Charolais.</p>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h5>📊 Configuración de Base de Datos</h5>
                            <div class="form-group">
                                <label class="form-label">Host de MySQL</label>
                                <input type="text" class="form-control" name="db_host" value="localhost" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Nombre de la Base de Datos</label>
                                <input type="text" class="form-control" name="db_name" value="grecovi3_charolais" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Usuario MySQL</label>
                                <input type="text" class="form-control" name="db_user" value="grecovi3_charolais" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Contraseña MySQL</label>
                                <input type="password" class="form-control" name="db_pass" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <h5>🌐 Configuración de la Aplicación</h5>
                            <div class="form-group">
                                <label class="form-label">URL de la Aplicación</label>
                                <input type="url" class="form-control" name="app_url" 
                                       value="https://charolaishat.com" required>
                            </div>
                            
                            <h5>💳 Stripe (Opcional)</h5>
                            <div class="form-group">
                                <label class="form-label">Clave Pública de Stripe</label>
                                <input type="text" class="form-control" name="stripe_pk" placeholder="pk_test_...">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Clave Secreta de Stripe</label>
                                <input type="password" class="form-control" name="stripe_sk" placeholder="sk_test_...">
                            </div>
                            
                            <h5>👤 Administrador</h5>
                            <div class="form-group">
                                <label class="form-label">Usuario Administrador</label>
                                <input type="text" class="form-control" name="admin_user" value="admin" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Contraseña Administrador</label>
                                <input type="password" class="form-control" name="admin_pass" value="Admin123!" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email Administrador</label>
                                <input type="email" class="form-control" name="admin_email" required>
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-success btn-lg">
                            🚀 Instalar Charolais Store
                        </button>
                    </div>
                </form>
                
            <?php elseif ($step == 3): ?>
                <!-- Paso 3: Finalización -->
                <div class="text-center">
                    <div class="success-icon">🎉</div>
                    <h1 style="color: #28a745; margin-bottom: 20px;">¡Instalación Completada!</h1>
                    <p style="font-size: 1.2em; margin-bottom: 30px;">Tu tienda Charolais ha sido instalada exitosamente y está lista para usar.</p>
                    
                    <div class="row mt-4">
                        <div class="col-md-6">
                            <div class="card">
                                <h5>📋 Próximos Pasos</h5>
                                <ol style="text-align: left;">
                                    <li>Ejecutar <code>admin/setup-sample-data.php</code> para agregar 21 productos de ejemplo</li>
                                    <li>Configurar las claves de Stripe en el panel admin</li>
                                    <li>Personalizar el logo y colores de la tienda</li>
                                    <li>Agregar más productos desde el panel administrativo</li>
                                    <li>Configurar métodos de pago y envío</li>
                                </ol>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card">
                                <h5>🔑 Información de Acceso</h5>
                                <ul style="list-style: none; padding-left: 0; text-align: left;">
                                    <li><strong>🛍️ Tienda:</strong> <a href="index.php" target="_blank">Ver Tienda</a></li>
                                    <li><strong>⚙️ Panel Admin:</strong> <a href="admin/" target="_blank">Administrar</a></li>
                                    <li><strong>👤 Usuario:</strong> admin</li>
                                    <li><strong>🔐 Contraseña:</strong> Admin123!</li>
                                    <li><strong>📧 Email:</strong> (el que configuraste)</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div class="mt-4">
                        <a href="admin/setup-sample-data.php" class="btn btn-primary btn-lg" style="margin-right: 15px;">
                            📦 Agregar Productos
                        </a>
                        <a href="index.php" class="btn btn-success btn-lg">
                            🛍️ Ver Tienda
                        </a>
                    </div>
                    
                    <div style="margin-top: 30px; padding: 20px; background: #e9ecef; border-radius: 8px;">
                        <h5 style="color: #8B4513;">🤠 ¡Bienvenido a Charolais Store!</h5>
                        <p>Tu tienda western está lista. No olvides cambiar la contraseña del administrador después del primer acceso.</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
