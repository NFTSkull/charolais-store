<?php
/**
 * Script de instalación NUEVO para Charolais Store
 * Versión sin cache - HTTPS garantizado
 */

// Verificar si ya está instalado
if (file_exists('includes/config.php') && !isset($_GET['force'])) {
    die('La aplicación ya está instalada. Agrega ?force=1 para forzar la reinstalación.');
}

$step = $_GET['step'] ?? 1;
$errors = [];
$success = [];

// Procesar formulario de configuración
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'] ?? '';
    $db_name = $_POST['db_name'] ?? '';
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';
    $app_url = $_POST['app_url'] ?? '';
    $stripe_pk = $_POST['stripe_pk'] ?? '';
    $stripe_sk = $_POST['stripe_sk'] ?? '';
    $admin_user = $_POST['admin_user'] ?? '';
    $admin_pass = $_POST['admin_pass'] ?? '';
    $admin_email = $_POST['admin_email'] ?? '';
    
    // Validar datos
    if (empty($db_host) || empty($db_name) || empty($db_user)) {
        $errors[] = 'Todos los campos de base de datos son requeridos';
    }
    
    if (empty($app_url)) {
        $errors[] = 'La URL de la aplicación es requerida';
    }
    
    if (empty($admin_user) || empty($admin_pass) || empty($admin_email)) {
        $errors[] = 'Los datos del administrador son requeridos';
    }
    
    if (strlen($admin_pass) < 8) {
        $errors[] = 'La contraseña del administrador debe tener al menos 8 caracteres';
    }
    
    // Si no hay errores, proceder con la instalación
    if (empty($errors)) {
        try {
            // Probar conexión a base de datos
            $pdo = new PDO("mysql:host=$db_host;charset=utf8mb4", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Crear base de datos si no existe
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db_name`");
            
            // Crear estructura de tablas
            createTables($pdo);
            
            // Crear archivo de configuración
            createConfigFile($db_host, $db_name, $db_user, $db_pass, $app_url, $stripe_pk, $stripe_sk);
            
            // Crear administrador
            createAdmin($pdo, $admin_user, $admin_pass, $admin_email);
            
            // Crear directorios necesarios
            createDirectories();
            
            $success[] = 'Instalación completada exitosamente';
            $step = 3;
            
        } catch (Exception $e) {
            $errors[] = 'Error durante la instalación: ' . $e->getMessage();
        }
    }
}

function createTables($pdo) {
    $tables = [
        // Tabla de administradores
        "CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            email VARCHAR(100),
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de categorías
        "CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de productos
        "CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            category_id INT,
            stock_quantity INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            rating DECIMAL(3,2) DEFAULT 0,
            reviews_count INT DEFAULT 0,
            sort_order INT DEFAULT 0,
            stripe_price_id VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
        )",
        
        // Tabla de imágenes de productos
        "CREATE TABLE IF NOT EXISTS product_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        )",
        
        // Tabla de variantes de productos
        "CREATE TABLE IF NOT EXISTS product_variants (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            variant_name VARCHAR(100) NOT NULL,
            sku VARCHAR(100),
            price_override DECIMAL(10,2),
            stock_quantity INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        )",
        
        // Tabla de imágenes de variantes
        "CREATE TABLE IF NOT EXISTS variant_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            variant_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE
        )",
        
        // Tabla de órdenes
        "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            stripe_session_id VARCHAR(255),
            customer_email VARCHAR(100),
            customer_name VARCHAR(100),
            total_amount DECIMAL(10,2) NOT NULL,
            shipping_amount DECIMAL(10,2) DEFAULT 0,
            status ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
            shipping_address TEXT,
            billing_address TEXT,
            is_first_purchase BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        // Tabla de items de órdenes
        "CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            product_id INT,
            variant_id INT,
            product_name VARCHAR(200) NOT NULL,
            variant_name VARCHAR(100),
            quantity INT NOT NULL,
            unit_price DECIMAL(10,2) NOT NULL,
            total_price DECIMAL(10,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE SET NULL
        )",
        
        // Tabla de configuraciones del sistema
        "CREATE TABLE IF NOT EXISTS system_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) UNIQUE NOT NULL,
            setting_value TEXT,
            description VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )"
    ];
    
    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }
}

function createConfigFile($db_host, $db_name, $db_user, $db_pass, $app_url, $stripe_pk, $stripe_sk) {
    $config = "<?php
/**
 * Configuración de la aplicación Charolais Store
 * Generado automáticamente por el instalador
 */

// Configuración de la aplicación
define('APP_NAME', 'Charolais');
define('APP_URL', '$app_url');
define('APP_VERSION', '1.0.0');

// Configuración de base de datos
define('DB_HOST', '$db_host');
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASS', '$db_pass');

// Configuración de Stripe
define('STRIPE_PUBLISHABLE_KEY', '$stripe_pk');
define('STRIPE_SECRET_KEY', '$stripe_sk');

// Configuración de envío
define('FREE_SHIPPING_THRESHOLD', 0); // Envío gratis en primera compra
define('REGULAR_SHIPPING_COST', 99.00); // Costo de envío regular en MXN

// Configuración de sesión
define('SESSION_LIFETIME', 3600); // 1 hora

// Configuración de archivos
define('UPLOAD_DIR', 'uploads/');
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB

// Configuración de seguridad
define('ADMIN_SESSION_TIMEOUT', 1800); // 30 minutos

// Logo del sitio
define('SITE_LOGO', 'uploads/Logo.JPG');

// Funciones auxiliares
function formatPrice(\$price) {
    return '$' . number_format(\$price, 2) . ' MXN';
}

function getSystemSetting(\$key, \$default = null) {
    global \$db;
    try {
        \$result = \$db->select('SELECT setting_value FROM system_settings WHERE setting_key = ?', [\$key]);
        return \$result ? \$result[0]['setting_value'] : \$default;
    } catch (Exception \$e) {
        return \$default;
    }
}

function setSystemSetting(\$key, \$value, \$description = null) {
    global \$db;
    try {
        \$existing = \$db->select('SELECT id FROM system_settings WHERE setting_key = ?', [\$key]);
        if (\$existing) {
            \$db->update('UPDATE system_settings SET setting_value = ? WHERE setting_key = ?', [\$value, \$key]);
        } else {
            \$db->insert('INSERT INTO system_settings (setting_key, setting_value, description) VALUES (?, ?, ?)', [\$key, \$value, \$description]);
        }
        return true;
    } catch (Exception \$e) {
        return false;
    }
}
?>";

    if (!file_put_contents('includes/config.php', $config)) {
        throw new Exception('No se pudo crear el archivo de configuración');
    }
}

function createAdmin($pdo, $username, $password, $email) {
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash, email) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE password_hash = ?, email = ?");
    $stmt->execute([$username, $passwordHash, $email, $passwordHash, $email]);
}

function createDirectories() {
    $dirs = ['uploads', 'includes', 'admin', 'api', 'css', 'js'];
    
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalador Charolais Store - NUEVO</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- jQuery HTTPS GARANTIZADO -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    
    <style>
        body {
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            min-height: 100vh;
        }
        .installer-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
        }
        .step-indicator {
            display: flex;
            justify-content: center;
            margin-bottom: 2rem;
        }
        .step {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 10px;
            font-weight: bold;
        }
        .step.active {
            background: #28a745;
            color: white;
        }
        .step.completed {
            background: #6c757d;
            color: white;
        }
        .step.pending {
            background: #e9ecef;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="installer-card p-5">
                    <div class="text-center mb-4">
                        <i class="fas fa-hat-cowboy fa-3x text-primary mb-3"></i>
                        <h1>Instalador Charolais Store</h1>
                        <p class="text-muted">Versión NUEVA - Sin problemas de cache</p>
                    </div>
                    
                    <!-- Indicador de pasos -->
                    <div class="step-indicator">
                        <div class="step <?php echo $step >= 1 ? 'active' : 'pending'; ?>">1</div>
                        <div class="step <?php echo $step >= 2 ? 'active' : 'pending'; ?>">2</div>
                        <div class="step <?php echo $step >= 3 ? 'active' : 'pending'; ?>">3</div>
                    </div>
                    
                    <!-- Mensajes de error -->
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <h5><i class="fas fa-exclamation-triangle"></i> Errores encontrados:</h5>
                            <ul class="mb-0">
                                <?php foreach ($errors as $error): ?>
                                    <li><?php echo htmlspecialchars($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Mensajes de éxito -->
                    <?php if (!empty($success)): ?>
                        <div class="alert alert-success">
                            <h5><i class="fas fa-check-circle"></i> ¡Instalación exitosa!</h5>
                            <ul class="mb-0">
                                <?php foreach ($success as $msg): ?>
                                    <li><?php echo htmlspecialchars($msg); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    
                    <?php if ($step == 1): ?>
                        <!-- Paso 1: Información del sistema -->
                        <div class="text-center">
                            <h3>Verificación del Sistema</h3>
                            <p>Verificando requisitos del servidor...</p>
                            
                            <div class="row text-start">
                                <div class="col-md-6">
                                    <h5>Requisitos del Servidor</h5>
                                    <ul class="list-unstyled">
                                        <li>
                                            <i class="fas fa-<?php echo version_compare(PHP_VERSION, '7.4.0', '>=') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            PHP 7.4+ (<?php echo PHP_VERSION; ?>)
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('pdo') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión PDO
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('pdo_mysql') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión PDO MySQL
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('json') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión JSON
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo extension_loaded('curl') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Extensión cURL
                                        </li>
                                    </ul>
                                </div>
                                <div class="col-md-6">
                                    <h5>Permisos de Archivos</h5>
                                    <ul class="list-unstyled">
                                        <li>
                                            <i class="fas fa-<?php echo is_writable('.') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Directorio actual escribible
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo function_exists('mkdir') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Función mkdir disponible
                                        </li>
                                        <li>
                                            <i class="fas fa-<?php echo function_exists('file_put_contents') ? 'check text-success' : 'times text-danger'; ?>"></i>
                                            Función file_put_contents disponible
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <a href="?step=2" class="btn btn-primary btn-lg">
                                    Continuar <i class="fas fa-arrow-right"></i>
                                </a>
                            </div>
                        </div>
                        
                    <?php elseif ($step == 2): ?>
                        <!-- Paso 2: Configuración -->
                        <form method="POST" action="?step=2">
                            <h3>Configuración de la Aplicación</h3>
                            <p class="text-muted">Completa la información necesaria para configurar tu tienda.</p>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <h5>Base de Datos</h5>
                                    <div class="mb-3">
                                        <label class="form-label">Host de MySQL</label>
                                        <input type="text" class="form-control" name="db_host" value="localhost" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Nombre de la Base de Datos</label>
                                        <input type="text" class="form-control" name="db_name" value="charolais_store" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Usuario MySQL</label>
                                        <input type="text" class="form-control" name="db_user" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Contraseña MySQL</label>
                                        <input type="password" class="form-control" name="db_pass">
                                    </div>
                                </div>
                                
                                <div class="col-md-6">
                                    <h5>Aplicación</h5>
                                    <div class="mb-3">
                                        <label class="form-label">URL de la Aplicación</label>
                                        <input type="url" class="form-control" name="app_url" 
                                               value="<?php echo 'https://' . ($_SERVER['HTTP_HOST'] ?? 'localhost'); ?>" required>
                                        <small class="text-muted">Ejemplo: https://tudominio.com</small>
                                    </div>
                                    
                                    <h5>Stripe (Opcional)</h5>
                                    <div class="mb-3">
                                        <label class="form-label">Clave Pública de Stripe</label>
                                        <input type="text" class="form-control" name="stripe_pk" placeholder="pk_test_...">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Clave Secreta de Stripe</label>
                                        <input type="password" class="form-control" name="stripe_sk" placeholder="sk_test_...">
                                    </div>
                                    
                                    <h5>Administrador</h5>
                                    <div class="mb-3">
                                        <label class="form-label">Usuario Administrador</label>
                                        <input type="text" class="form-control" name="admin_user" value="admin" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Contraseña Administrador</label>
                                        <input type="password" class="form-control" name="admin_pass" value="Admin123!" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Email Administrador</label>
                                        <input type="email" class="form-control" name="admin_email" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-success btn-lg">
                                    <i class="fas fa-cog"></i> Instalar Base de Datos
                                </button>
                            </div>
                        </form>
                        
                    <?php elseif ($step == 3): ?>
                        <!-- Paso 3: Finalización -->
                        <div class="text-center">
                            <i class="fas fa-check-circle fa-4x text-success mb-4"></i>
                            <h3>¡Instalación Completada!</h3>
                            <p class="lead">Tu tienda Charolais ha sido instalada exitosamente.</p>
                            
                            <div class="row mt-4">
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Próximos Pasos</h5>
                                            <ol class="text-start">
                                                <li>Ejecutar <code>admin/setup-sample-data.php</code> para agregar productos de ejemplo</li>
                                                <li>Configurar las claves de Stripe en <code>includes/config.php</code></li>
                                                <li>Personalizar el logo y colores</li>
                                                <li>Agregar más productos desde el panel admin</li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card">
                                        <div class="card-body">
                                            <h5 class="card-title">Accesos</h5>
                                            <ul class="list-unstyled text-start">
                                                <li><strong>Tienda:</strong> <a href="index.php">Ver Tienda</a></li>
                                                <li><strong>Admin:</strong> <a href="admin/">Panel Admin</a></li>
                                                <li><strong>Usuario:</strong> admin</li>
                                                <li><strong>Contraseña:</strong> Admin123!</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-4">
                                <a href="admin/setup-sample-data.php" class="btn btn-primary btn-lg me-3">
                                    <i class="fas fa-database"></i> Agregar Productos de Ejemplo
                                </a>
                                <a href="index.php" class="btn btn-success btn-lg">
                                    <i class="fas fa-store"></i> Ver Tienda
                                </a>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        $(document).ready(function() {
            console.log('jQuery cargado correctamente desde HTTPS');
        });
    </script>
</body>
</html> 