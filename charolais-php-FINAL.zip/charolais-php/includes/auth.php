<?php
/**
 * Sistema de autenticación para Charolais Store
 * Manejo de login, sesiones y protección de rutas
 */

require_once 'database.php';

class Auth {
    private $db;
    
    public function __construct() {
        $this->db = Database::getInstance();
    }
    
    /**
     * Autenticar administrador
     */
    public function login($username, $password) {
        try {
            // Verificar intentos de login
            if ($this->isLockedOut()) {
                return ['success' => false, 'message' => 'Cuenta bloqueada temporalmente. Intenta de nuevo en 15 minutos.'];
            }
            
            // Buscar administrador
            $sql = "SELECT * FROM admins WHERE username = ? AND is_active = 1";
            $admin = $this->db->selectOne($sql, [$username]);
            
            if (!$admin) {
                $this->recordFailedAttempt();
                return ['success' => false, 'message' => 'Credenciales inválidas'];
            }
            
            // Verificar contraseña
            if (!password_verify($password, $admin['password_hash'])) {
                $this->recordFailedAttempt();
                return ['success' => false, 'message' => 'Credenciales inválidas'];
            }
            
            // Login exitoso
            $this->clearFailedAttempts();
            $this->createSession($admin);
            $this->logActivity('login', 'Login exitoso', $admin['id']);
            
            return ['success' => true, 'message' => 'Login exitoso', 'admin' => $admin];
            
        } catch (Exception $e) {
            error_log("Error en login: " . $e->getMessage());
            return ['success' => false, 'message' => 'Error interno del servidor'];
        }
    }
    
    /**
     * Crear sesión de administrador
     */
    private function createSession($admin) {
        $_SESSION['admin_id'] = $admin['id'];
        $_SESSION['admin_username'] = $admin['username'];
        $_SESSION['admin_email'] = $admin['email'];
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['login_time'] = time();
        
        // Regenerar ID de sesión por seguridad
        session_regenerate_id(true);
    }
    
    /**
     * Verificar si el administrador está autenticado
     */
    public function isAuthenticated() {
        return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
    }
    
    /**
     * Obtener información del administrador actual
     */
    public function getCurrentAdmin() {
        if (!$this->isAuthenticated()) {
            return null;
        }
        
        try {
            $sql = "SELECT id, username, email, created_at FROM admins WHERE id = ?";
            return $this->db->selectOne($sql, [$_SESSION['admin_id']]);
        } catch (Exception $e) {
            error_log("Error obteniendo admin actual: " . $e->getMessage());
            return null;
        }
    }
    
    /**
     * Cerrar sesión
     */
    public function logout() {
        if ($this->isAuthenticated()) {
            $this->logActivity('logout', 'Logout exitoso', $_SESSION['admin_id']);
        }
        
        session_unset();
        session_destroy();
        session_start();
    }
    
    /**
     * Cambiar contraseña
     */
    public function changePassword($adminId, $currentPassword, $newPassword) {
        try {
            // Verificar contraseña actual
            $sql = "SELECT password_hash FROM admins WHERE id = ?";
            $admin = $this->db->selectOne($sql, [$adminId]);
            
            if (!$admin || !password_verify($currentPassword, $admin['password_hash'])) {
                return ['success' => false, 'message' => 'Contraseña actual incorrecta'];
            }
            
            // Validar nueva contraseña
            if (strlen($newPassword) < PASSWORD_MIN_LENGTH) {
                return ['success' => false, 'message' => 'La nueva contraseña debe tener al menos ' . PASSWORD_MIN_LENGTH . ' caracteres'];
            }
            
            // Hashear nueva contraseña
            $newPasswordHash = password_hash($newPassword, PASSWORD_DEFAULT);
            
            // Actualizar contraseña
            $this->db->update('admins', 
                ['password_hash' => $newPasswordHash], 
                'id = ?', 
                [$adminId]
            );
            
            $this->logActivity('change_password', 'Contraseña cambiada', $adminId);
            
            return ['success' => true, 'message' => 'Contraseña cambiada exitosamente'];
            
        } catch (Exception $e) {
            error_log("Error cambiando contraseña: " . $e->getMessage());
            return ['success' => false, 'message' => 'Error interno del servidor'];
        }
    }
    
    /**
     * Crear nuevo administrador
     */
    public function createAdmin($username, $email, $password) {
        try {
            // Verificar si el usuario ya existe
            $sql = "SELECT id FROM admins WHERE username = ? OR email = ?";
            $existing = $this->db->select($sql, [$username, $email]);
            
            if (!empty($existing)) {
                return ['success' => false, 'message' => 'El usuario o email ya existe'];
            }
            
            // Validar contraseña
            if (strlen($password) < PASSWORD_MIN_LENGTH) {
                return ['success' => false, 'message' => 'La contraseña debe tener al menos ' . PASSWORD_MIN_LENGTH . ' caracteres'];
            }
            
            // Hashear contraseña
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            
            // Insertar administrador
            $adminId = $this->db->insert('admins', [
                'username' => $username,
                'email' => $email,
                'password_hash' => $passwordHash
            ]);
            
            $this->logActivity('create_admin', "Administrador creado: $username", $adminId);
            
            return ['success' => true, 'message' => 'Administrador creado exitosamente', 'admin_id' => $adminId];
            
        } catch (Exception $e) {
            error_log("Error creando administrador: " . $e->getMessage());
            return ['success' => false, 'message' => 'Error interno del servidor'];
        }
    }
    
    /**
     * Verificar intentos fallidos de login
     */
    private function isLockedOut() {
        $lockoutKey = 'login_attempts_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        
        if (!isset($_SESSION[$lockoutKey])) {
            return false;
        }
        
        $attempts = $_SESSION[$lockoutKey];
        
        // Verificar si ha pasado el tiempo de bloqueo
        if (time() - $attempts['time'] > LOGIN_LOCKOUT_TIME) {
            unset($_SESSION[$lockoutKey]);
            return false;
        }
        
        return $attempts['count'] >= LOGIN_MAX_ATTEMPTS;
    }
    
    /**
     * Registrar intento fallido de login
     */
    private function recordFailedAttempt() {
        $lockoutKey = 'login_attempts_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        
        if (!isset($_SESSION[$lockoutKey])) {
            $_SESSION[$lockoutKey] = ['count' => 0, 'time' => time()];
        }
        
        $_SESSION[$lockoutKey]['count']++;
        $_SESSION[$lockoutKey]['time'] = time();
    }
    
    /**
     * Limpiar intentos fallidos
     */
    private function clearFailedAttempts() {
        $lockoutKey = 'login_attempts_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        unset($_SESSION[$lockoutKey]);
    }
    
    /**
     * Registrar actividad
     */
    private function logActivity($action, $details, $userId = null) {
        try {
            $this->db->insert('activity_logs', [
                'action' => $action,
                'details' => $details,
                'user_id' => $userId,
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
            ]);
        } catch (Exception $e) {
            error_log("Error registrando actividad: " . $e->getMessage());
        }
    }
    
    /**
     * Obtener logs de actividad
     */
    public function getActivityLogs($limit = 50, $offset = 0) {
        try {
            $sql = "
                SELECT al.*, a.username 
                FROM activity_logs al 
                LEFT JOIN admins a ON al.user_id = a.id 
                ORDER BY al.created_at DESC 
                LIMIT ? OFFSET ?
            ";
            
            return $this->db->select($sql, [$limit, $offset]);
        } catch (Exception $e) {
            error_log("Error obteniendo logs: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Verificar permisos de administrador
     */
    public function requireAuth() {
        if (!$this->isAuthenticated()) {
            if (isAjaxRequest()) {
                jsonError('No autorizado', 401);
            } else {
                redirect('/admin/login.php');
            }
        }
    }
    
    /**
     * Verificar si es una petición AJAX
     */
    private function isAjaxRequest() {
        return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
               strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
    }
    
    /**
     * Obtener estadísticas de seguridad
     */
    public function getSecurityStats() {
        try {
            $stats = [];
            
            // Intentos fallidos de login hoy
            $sql = "
                SELECT COUNT(*) as count 
                FROM activity_logs 
                WHERE action = 'failed_login' 
                AND DATE(created_at) = CURRENT_DATE()
            ";
            $result = $this->db->selectOne($sql);
            $stats['failed_logins_today'] = $result['count'];
            
            // Logins exitosos hoy
            $sql = "
                SELECT COUNT(*) as count 
                FROM activity_logs 
                WHERE action = 'login' 
                AND DATE(created_at) = CURRENT_DATE()
            ";
            $result = $this->db->selectOne($sql);
            $stats['successful_logins_today'] = $result['count'];
            
            // Último login
            $sql = "
                SELECT created_at 
                FROM activity_logs 
                WHERE action = 'login' 
                ORDER BY created_at DESC 
                LIMIT 1
            ";
            $result = $this->db->selectOne($sql);
            $stats['last_login'] = $result['created_at'] ?? null;
            
            return $stats;
        } catch (Exception $e) {
            error_log("Error obteniendo estadísticas de seguridad: " . $e->getMessage());
            return [];
        }
    }
}

// Inicializar sistema de autenticación
$auth = new Auth();

// Función helper para verificar autenticación
function requireAdminAuth() {
    global $auth;
    $auth->requireAuth();
}

// Función helper para obtener admin actual
function getCurrentAdmin() {
    global $auth;
    return $auth->getCurrentAdmin();
}

// Función helper para verificar si está autenticado
function isAdminAuthenticated() {
    global $auth;
    return $auth->isAuthenticated();
}
?> 