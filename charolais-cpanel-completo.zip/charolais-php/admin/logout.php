<?php
// 🚀 CHAROLAIS - LOGOUT ADMIN
// ===========================
require_once '../config.php';

// Iniciar sesión para poder destruirla
session_start();

// Log del logout
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    logError("Admin logout desde IP: " . $_SERVER['REMOTE_ADDR']);
}

// Destruir toda la sesión
session_unset();
session_destroy();

// Limpiar cookie de sesión si existe
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Redirigir al login con mensaje
header('Location: login.php?logout=1');
exit;
?> 