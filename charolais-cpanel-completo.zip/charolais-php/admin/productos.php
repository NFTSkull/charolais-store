<?php
// 🚀 CHAROLAIS - GESTIÓN DE PRODUCTOS
// ==================================
require_once '../config.php';
checkAdminAuth();

// Procesar acciones
$action = $_GET['action'] ?? 'list';
$message = '';
$error = '';

try {
    $db = Database::getInstance()->getConnection();
    
    // Manejar acciones POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        switch ($action) {
            case 'create':
                $result = createProduct($db);
                break;
            case 'update':
                $result = updateProduct($db);
                break;
            case 'delete':
                $result = deleteProduct($db);
                break;
        }
        
        if (isset($result['success'])) {
            $message = $result['message'];
            // Redirigir para evitar reenvío de formulario
            header('Location: productos.php?success=' . urlencode($message));
            exit;
        } else {
            $error = $result['message'] ?? 'Error desconocido';
        }
    }
    
    // Obtener productos
    $products = getProducts($db);
    
    // Obtener categorías
    $categories = getCategories($db);
    
} catch (Exception $e) {
    $error = 'Error de conexión: ' . $e->getMessage();
    logError($error);
}

// Obtener mensajes de URL
if (isset($_GET['success'])) {
    $message = $_GET['success'];
}
if (isset($_GET['error'])) {
    $error = $_GET['error'];
}

// Funciones auxiliares
function getProducts($db) {
    $stmt = $db->query("
        SELECT p.*, 
               COALESCE(SUM(pv.stock_quantity), p.stock_quantity) as total_stock,
               COUNT(pv.id) as variant_count
        FROM products p 
        LEFT JOIN product_variants pv ON p.id = pv.product_id AND pv.is_active = 1
        WHERE p.is_active = 1 
        GROUP BY p.id 
        ORDER BY p.created_at DESC
    ");
    return $stmt->fetchAll();
}

function getCategories($db) {
    $stmt = $db->query("SELECT DISTINCT category FROM products WHERE is_active = 1 ORDER BY category");
    return $stmt->fetchAll();
}

function createProduct($db) {
    $name = sanitizeInput($_POST['name']);
    $description = sanitizeInput($_POST['description']);
    $price = floatval($_POST['price']);
    $category = sanitizeInput($_POST['category']);
    $stock = intval($_POST['stock_quantity']);
    $featured = isset($_POST['featured']) ? 1 : 0;
    
    // Manejar imagen
    $imageUrl = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $imageUrl = uploadImage($_FILES['image']);
        if (!$imageUrl) {
            return ['message' => 'Error al subir la imagen'];
        }
    }
    
    $stmt = $db->prepare("
        INSERT INTO products (name, description, price, category, stock_quantity, image_url, featured) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    
    if ($stmt->execute([$name, $description, $price, $category, $stock, $imageUrl, $featured])) {
        return ['success' => true, 'message' => 'Producto creado exitosamente'];
    } else {
        return ['message' => 'Error al crear el producto'];
    }
}

function updateProduct($db) {
    $id = intval($_POST['id']);
    $name = sanitizeInput($_POST['name']);
    $description = sanitizeInput($_POST['description']);
    $price = floatval($_POST['price']);
    $category = sanitizeInput($_POST['category']);
    $stock = intval($_POST['stock_quantity']);
    $featured = isset($_POST['featured']) ? 1 : 0;
    
    // Manejar imagen
    $imageUpdate = '';
    $params = [$name, $description, $price, $category, $stock, $featured];
    
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $imageUrl = uploadImage($_FILES['image']);
        if ($imageUrl) {
            $imageUpdate = ', image_url = ?';
            $params[] = $imageUrl;
        }
    }
    
    $params[] = $id;
    
    $stmt = $db->prepare("
        UPDATE products 
        SET name = ?, description = ?, price = ?, category = ?, stock_quantity = ?, featured = ? $imageUpdate
        WHERE id = ?
    ");
    
    if ($stmt->execute($params)) {
        return ['success' => true, 'message' => 'Producto actualizado exitosamente'];
    } else {
        return ['message' => 'Error al actualizar el producto'];
    }
}

function deleteProduct($db) {
    $id = intval($_POST['id']);
    
    $stmt = $db->prepare("UPDATE products SET is_active = 0 WHERE id = ?");
    
    if ($stmt->execute([$id])) {
        return ['success' => true, 'message' => 'Producto eliminado exitosamente'];
    } else {
        return ['message' => 'Error al eliminar el producto'];
    }
}

function uploadImage($file) {
    $uploadDir = '../uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }
    
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($fileExtension, $allowedTypes)) {
        return false;
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        return false;
    }
    
    $fileName = generateId() . '.' . $fileExtension;
    $uploadPath = $uploadDir . $fileName;
    
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        return 'uploads/' . $fileName;
    }
    
    return false;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤠 Gestión de Productos - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            min-height: 100vh;
            color: #333;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            background: rgba(255, 255, 255, 0.95);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            color: #8B4513;
            font-size: 2.5em;
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header-actions {
            display: flex;
            gap: 15px;
        }

        .btn {
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: #28a745;
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }

        .alert {
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: bold;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .alert.success {
            background: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .alert.error {
            background: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }

        .product-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            transition: transform 0.3s ease;
        }

        .product-card:hover {
            transform: translateY(-5px);
        }

        .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: #f8f9fa;
        }

        .product-info {
            padding: 20px;
        }

        .product-name {
            font-size: 1.3em;
            font-weight: bold;
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .product-price {
            font-size: 1.5em;
            color: #8B4513;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .product-category {
            background: rgba(139, 69, 19, 0.1);
            color: #8B4513;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.9em;
            display: inline-block;
            margin-bottom: 10px;
        }

        .product-stock {
            font-size: 0.9em;
            color: #6c757d;
            margin-bottom: 15px;
        }

        .product-actions {
            display: flex;
            gap: 10px;
        }

        .btn-small {
            padding: 8px 16px;
            font-size: 0.9em;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background: #007bff;
            color: white;
        }

        .btn-delete {
            background: #dc3545;
            color: white;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 30px;
            border: none;
            border-radius: 15px;
            width: 90%;
            max-width: 600px;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-title {
            color: #8B4513;
            font-size: 1.8em;
            font-weight: bold;
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover {
            color: #000;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            color: #333;
            font-weight: bold;
            margin-bottom: 8px;
        }

        .form-group input,
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1em;
            transition: border-color 0.3s ease;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            border-color: #8B4513;
            outline: none;
        }

        .form-group textarea {
            height: 100px;
            resize: vertical;
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: auto;
        }

        .empty-state {
            background: rgba(255, 255, 255, 0.95);
            padding: 60px;
            border-radius: 15px;
            text-align: center;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
        }

        .empty-state .icon {
            font-size: 4em;
            color: #8B4513;
            margin-bottom: 20px;
        }

        .empty-state h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 1.5em;
        }

        .empty-state p {
            color: #6c757d;
            margin-bottom: 25px;
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }

            .header h1 {
                font-size: 2em;
            }

            .products-grid {
                grid-template-columns: 1fr;
            }

            .modal-content {
                margin: 10% auto;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>
                <i class="fas fa-tshirt"></i>
                Gestión de Productos
            </h1>
            <div class="header-actions">
                <button class="btn btn-primary" onclick="openModal('createModal')">
                    <i class="fas fa-plus"></i> Nuevo Producto
                </button>
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Volver al Panel
                </a>
            </div>
        </div>

        <!-- Alertas -->
        <?php if ($message): ?>
        <div class="alert success">
            <i class="fas fa-check-circle"></i>
            <?php echo htmlspecialchars($message); ?>
        </div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="alert error">
            <i class="fas fa-exclamation-circle"></i>
            <?php echo htmlspecialchars($error); ?>
        </div>
        <?php endif; ?>

        <!-- Productos -->
        <?php if (empty($products)): ?>
        <div class="empty-state">
            <div class="icon">
                <i class="fas fa-box-open"></i>
            </div>
            <h3>No hay productos</h3>
            <p>¡Comienza agregando tu primer producto western! Crea camisetas, sombreros, accesorios y más para tu tienda.</p>
            <button class="btn btn-primary" onclick="openModal('createModal')">
                <i class="fas fa-plus"></i> Crear Primer Producto
            </button>
        </div>
        <?php else: ?>
        <div class="products-grid">
            <?php foreach ($products as $product): ?>
            <div class="product-card">
                <?php if ($product['image_url']): ?>
                <img src="../<?php echo htmlspecialchars($product['image_url']); ?>" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>" 
                     class="product-image">
                <?php else: ?>
                <div class="product-image" style="display: flex; align-items: center; justify-content: center; color: #ccc;">
                    <i class="fas fa-image" style="font-size: 3em;"></i>
                </div>
                <?php endif; ?>
                
                <div class="product-info">
                    <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                    <div class="product-price"><?php echo formatPrice($product['price']); ?></div>
                    <div class="product-category"><?php echo htmlspecialchars($product['category']); ?></div>
                    <div class="product-stock">
                        Stock: <?php echo number_format($product['total_stock']); ?>
                        <?php if ($product['variant_count'] > 0): ?>
                        (<?php echo $product['variant_count']; ?> variantes)
                        <?php endif; ?>
                    </div>
                    
                    <div class="product-actions">
                        <button class="btn-small btn-edit" onclick="editProduct(<?php echo $product['id']; ?>)">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                        <button class="btn-small btn-delete" onclick="deleteProduct(<?php echo $product['id']; ?>)">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Modal Crear Producto -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-plus"></i> Nuevo Producto
                </h2>
                <span class="close" onclick="closeModal('createModal')">&times;</span>
            </div>
            
            <form method="POST" action="productos.php?action=create" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Nombre del Producto *</label>
                    <input type="text" id="name" name="name" required placeholder="Ej: Sombrero Vaquero Premium">
                </div>
                
                <div class="form-group">
                    <label for="description">Descripción</label>
                    <textarea id="description" name="description" placeholder="Describe tu producto western..."></textarea>
                </div>
                
                <div class="form-group">
                    <label for="price">Precio ($) *</label>
                    <input type="number" id="price" name="price" required min="0" step="0.01" placeholder="0.00">
                </div>
                
                <div class="form-group">
                    <label for="category">Categoría *</label>
                    <select id="category" name="category" required>
                        <option value="">Seleccionar categoría...</option>
                        <option value="Sombreros">Sombreros</option>
                        <option value="Camisetas">Camisetas</option>
                        <option value="Accesorios">Accesorios</option>
                        <option value="Conjuntos">Conjuntos</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo htmlspecialchars($cat['category']); ?>">
                            <?php echo htmlspecialchars($cat['category']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="stock_quantity">Stock Inicial *</label>
                    <input type="number" id="stock_quantity" name="stock_quantity" required min="0" value="1">
                </div>
                
                <div class="form-group">
                    <label for="image">Imagen del Producto</label>
                    <input type="file" id="image" name="image" accept="image/*">
                </div>
                
                <div class="form-group">
                    <div class="checkbox-group">
                        <input type="checkbox" id="featured" name="featured">
                        <label for="featured">Producto destacado</label>
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-save"></i> Crear Producto
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Modal Editar Producto -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title">
                    <i class="fas fa-edit"></i> Editar Producto
                </h2>
                <span class="close" onclick="closeModal('editModal')">&times;</span>
            </div>
            
            <form id="editForm" method="POST" action="productos.php?action=update" enctype="multipart/form-data">
                <input type="hidden" id="edit_id" name="id">
                
                <div class="form-group">
                    <label for="edit_name">Nombre del Producto *</label>
                    <input type="text" id="edit_name" name="name" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_description">Descripción</label>
                    <textarea id="edit_description" name="description"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="edit_price">Precio ($) *</label>
                    <input type="number" id="edit_price" name="price" required min="0" step="0.01">
                </div>
                
                <div class="form-group">
                    <label for="edit_category">Categoría *</label>
                    <select id="edit_category" name="category" required>
                        <option value="">Seleccionar categoría...</option>
                        <option value="Sombreros">Sombreros</option>
                        <option value="Camisetas">Camisetas</option>
                        <option value="Accesorios">Accesorios</option>
                        <option value="Conjuntos">Conjuntos</option>
                        <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo htmlspecialchars($cat['category']); ?>">
                            <?php echo htmlspecialchars($cat['category']); ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="edit_stock_quantity">Stock</label>
                    <input type="number" id="edit_stock_quantity" name="stock_quantity" min="0">
                </div>
                
                <div class="form-group">
                    <label for="edit_image">Cambiar Imagen</label>
                    <input type="file" id="edit_image" name="image" accept="image/*">
                </div>
                
                <div class="form-group">
                    <div class="checkbox-group">
                        <input type="checkbox" id="edit_featured" name="featured">
                        <label for="edit_featured">Producto destacado</label>
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" style="width: 100%;">
                        <i class="fas fa-save"></i> Actualizar Producto
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        // Funciones para modales
        function openModal(modalId) {
            document.getElementById(modalId).style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Cerrar modal al hacer clic fuera
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }

        // Función para editar producto
        function editProduct(id) {
            // Obtener datos del producto por AJAX
            fetch(`../api/products.php?action=detail&id=${id}`)
                .then(response => response.json())
                .then(data => {
                    if (data.product) {
                        const product = data.product;
                        document.getElementById('edit_id').value = product.id;
                        document.getElementById('edit_name').value = product.name;
                        document.getElementById('edit_description').value = product.description || '';
                        document.getElementById('edit_price').value = product.price;
                        document.getElementById('edit_category').value = product.category;
                        document.getElementById('edit_stock_quantity').value = product.stock_quantity;
                        document.getElementById('edit_featured').checked = product.featured == 1;
                        
                        openModal('editModal');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Error al cargar los datos del producto');
                });
        }

        // Función para eliminar producto
        function deleteProduct(id) {
            if (confirm('¿Estás seguro de que quieres eliminar este producto?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = 'productos.php?action=delete';
                
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'id';
                input.value = id;
                
                form.appendChild(input);
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Mensaje de bienvenida
        console.log('🤠 Gestión de Productos - Charolais');
    </script>
</body>
</html> 