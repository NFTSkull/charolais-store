<?php
// 🚀 CHAROLAIS - PÁGINA DE ÉXITO
// ==============================
require_once 'config.php';

$sessionId = $_GET['session_id'] ?? null;

if (!$sessionId) {
    header('Location: index.php');
    exit;
}

// Obtener información de la sesión de Stripe (simulado)
$orderInfo = [
    'session_id' => $sessionId,
    'status' => 'completed',
    'date' => date('d/m/Y H:i')
];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤠 ¡Compra Exitosa! - <?php echo SITE_NAME; ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .success-container {
            background: rgba(255, 255, 255, 0.95);
            padding: 60px;
            border-radius: 20px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            text-align: center;
            max-width: 600px;
            width: 100%;
            backdrop-filter: blur(10px);
        }

        .success-icon {
            font-size: 5em;
            color: #28a745;
            margin-bottom: 30px;
            animation: bounceIn 1s ease-out;
        }

        .success-title {
            color: #8B4513;
            font-size: 3em;
            font-weight: bold;
            margin-bottom: 20px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }

        .success-message {
            color: #333;
            font-size: 1.3em;
            margin-bottom: 40px;
            line-height: 1.6;
        }

        .order-details {
            background: rgba(139, 69, 19, 0.1);
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 40px;
            border-left: 4px solid #8B4513;
        }

        .order-details h3 {
            color: #8B4513;
            margin-bottom: 20px;
            font-size: 1.5em;
        }

        .detail-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 1.1em;
        }

        .detail-label {
            font-weight: bold;
            color: #666;
        }

        .detail-value {
            color: #333;
        }

        .actions {
            display: flex;
            gap: 20px;
            justify-content: center;
            flex-wrap: wrap;
        }

        .btn {
            padding: 15px 30px;
            border: none;
            border-radius: 10px;
            font-size: 1.1em;
            font-weight: bold;
            text-decoration: none;
            cursor: pointer;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        .btn-primary {
            background: linear-gradient(45deg, #8B4513, #D2691E);
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
        }

        .celebration {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            overflow: hidden;
        }

        .confetti {
            position: absolute;
            width: 10px;
            height: 10px;
            background: #D2691E;
            animation: confetti-fall 3s linear infinite;
        }

        .confetti:nth-child(odd) {
            background: #8B4513;
            animation-delay: -1s;
        }

        .confetti:nth-child(even) {
            background: #28a745;
            animation-delay: -2s;
        }

        @keyframes bounceIn {
            0% {
                transform: scale(0.3);
                opacity: 0;
            }
            50% {
                transform: scale(1.05);
            }
            70% {
                transform: scale(0.9);
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        @keyframes confetti-fall {
            0% {
                transform: translateY(-100vh) rotate(0deg);
                opacity: 1;
            }
            100% {
                transform: translateY(100vh) rotate(720deg);
                opacity: 0;
            }
        }

        @media (max-width: 768px) {
            .success-container {
                padding: 40px 30px;
            }

            .success-title {
                font-size: 2.5em;
            }

            .success-message {
                font-size: 1.1em;
            }

            .actions {
                flex-direction: column;
                align-items: center;
            }

            .btn {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <!-- Celebración con confetti -->
    <div class="celebration">
        <?php for ($i = 0; $i < 50; $i++): ?>
        <div class="confetti" style="left: <?php echo rand(0, 100); ?>%; animation-delay: <?php echo rand(-3000, 0); ?>ms;"></div>
        <?php endfor; ?>
    </div>

    <div class="success-container">
        <div class="success-icon">
            <i class="fas fa-check-circle"></i>
        </div>

        <h1 class="success-title">¡Compra Exitosa!</h1>
        
        <p class="success-message">
            🤠 ¡Yeehaw! Tu pedido ha sido procesado exitosamente. 
            Gracias por elegir Charolais para tu estilo vaquero auténtico.
        </p>

        <div class="order-details">
            <h3>
                <i class="fas fa-receipt"></i>
                Detalles de tu Pedido
            </h3>
            
            <div class="detail-item">
                <span class="detail-label">ID de Sesión:</span>
                <span class="detail-value"><?php echo htmlspecialchars(substr($sessionId, 0, 20)); ?>...</span>
            </div>
            
            <div class="detail-item">
                <span class="detail-label">Estado:</span>
                <span class="detail-value" style="color: #28a745; font-weight: bold;">
                    <i class="fas fa-check"></i> Pagado
                </span>
            </div>
            
            <div class="detail-item">
                <span class="detail-label">Fecha:</span>
                <span class="detail-value"><?php echo $orderInfo['date']; ?></span>
            </div>
        </div>

        <div style="background: #d4edda; color: #155724; padding: 20px; border-radius: 10px; margin-bottom: 30px; border-left: 4px solid #28a745;">
            <i class="fas fa-info-circle"></i>
            <strong>¿Qué sigue?</strong><br>
            • Recibirás un email de confirmación<br>
            • Te contactaremos para coordinar la entrega<br>
            • Tu pedido será procesado en 1-2 días hábiles
        </div>

        <div class="actions">
            <a href="index.php" class="btn btn-primary">
                <i class="fas fa-home"></i>
                Volver a la Tienda
            </a>
            
            <a href="mailto:<?php echo ADMIN_EMAIL; ?>" class="btn btn-secondary">
                <i class="fas fa-envelope"></i>
                Contactar Soporte
            </a>
        </div>

        <div style="margin-top: 40px; padding-top: 30px; border-top: 1px solid #eee; color: #666;">
            <p style="font-size: 0.9em;">
                <i class="fas fa-star"></i>
                Gracias por confiar en Charolais - Tradición vaquera desde Monterrey, N.L.
            </p>
        </div>
    </div>

    <script>
        // Limpiar carrito después de compra exitosa
        localStorage.removeItem('charolais_cart');
        
        // Mensaje de celebración
        console.log('🤠 ¡Compra exitosa! ¡Gracias por elegir Charolais!');
        
        // Auto-redirect después de 30 segundos
        setTimeout(() => {
            if (confirm('¿Quieres volver a la tienda principal?')) {
                window.location.href = 'index.php';
            }
        }, 30000);
    </script>
</body>
</html> 