<?php
// 🚀 CHAROLAIS - TIENDA PRINCIPAL (PHP)
// ===================================
require_once 'config.php';

// Obtener productos desde la API
try {
    $apiUrl = SITE_URL . '/api/products.php?action=list';
    $context = stream_context_create([
        'http' => [
            'timeout' => 10
        ]
    ]);
    
    $response = file_get_contents($apiUrl, false, $context);
    if ($response === false) {
        throw new Exception('Error al obtener productos');
    }
    
    $data = json_decode($response, true);
    $products = $data['products'] ?? [];
    
} catch (Exception $e) {
    logError("Error cargando productos: " . $e->getMessage());
    $products = [];
}

// Organizar productos por categoría
$categories = [];
foreach ($products as $product) {
    $category = $product['category'];
    if (!isset($categories[$category])) {
        $categories[$category] = [];
    }
    $categories[$category][] = $product;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤠 <?php echo SITE_NAME; ?> - Estilo Vaquero Auténtico | Monterrey, N.L.</title>
    <meta name="description" content="Descubre la colección auténtica de Charolais: gorras, playeras y accesorios con estilo vaquero de Monterrey, Nuevo León.">
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Oswald:wght@300;400;500;600;700&family=Crimson+Text:ital,wght@0,400;0,600;1,400&display=swap" rel="stylesheet">
    
    <!-- Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Oswald', sans-serif;
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            color: #333;
            line-height: 1.6;
        }

        /* Header */
        .header {
            background: rgba(0, 0, 0, 0.9);
            padding: 20px 0;
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
            backdrop-filter: blur(10px);
        }

        .header-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            color: #D2691E;
            font-family: 'Bebas Neue', cursive;
            font-size: 2.5em;
            font-weight: bold;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }

        .nav-menu {
            display: flex;
            gap: 30px;
            list-style: none;
        }

        .nav-menu a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            transition: color 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .nav-menu a:hover {
            color: #D2691E;
        }

        .cart-icon {
            color: white;
            font-size: 1.5em;
            position: relative;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .cart-icon:hover {
            color: #D2691E;
        }

        .cart-count {
            background: #dc3545;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 0.7em;
            position: absolute;
            top: -8px;
            right: -8px;
            min-width: 18px;
            text-align: center;
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), 
                        url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 1000"><defs><pattern id="western" patternUnits="userSpaceOnUse" width="100" height="100"><circle cx="50" cy="50" r="2" fill="%23D2691E" opacity="0.3"/></pattern></defs><rect width="100%" height="100%" fill="url(%23western)"/></svg>');
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: white;
            margin-top: 0;
        }

        .hero-content h1 {
            font-family: 'Bebas Neue', cursive;
            font-size: 5em;
            margin-bottom: 20px;
            text-shadow: 3px 3px 6px rgba(0, 0, 0, 0.7);
            animation: fadeInUp 1s ease-out;
        }

        .hero-content p {
            font-size: 1.3em;
            margin-bottom: 40px;
            max-width: 600px;
            opacity: 0.9;
            animation: fadeInUp 1s ease-out 0.3s both;
        }

        .hero-btn {
            background: linear-gradient(45deg, #8B4513, #D2691E);
            color: white;
            padding: 15px 40px;
            border: none;
            border-radius: 50px;
            font-size: 1.2em;
            font-weight: bold;
            text-decoration: none;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            display: inline-block;
            animation: fadeInUp 1s ease-out 0.6s both;
        }

        .hero-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(139, 69, 19, 0.4);
        }

        /* Products Section */
        .products-section {
            padding: 80px 0;
            background: rgba(255, 255, 255, 0.95);
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .section-title {
            text-align: center;
            margin-bottom: 60px;
        }

        .section-title h2 {
            font-family: 'Bebas Neue', cursive;
            font-size: 3.5em;
            color: #8B4513;
            margin-bottom: 15px;
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.1);
        }

        .section-title p {
            font-size: 1.2em;
            color: #666;
            max-width: 500px;
            margin: 0 auto;
        }

        .category-section {
            margin-bottom: 80px;
        }

        .category-title {
            font-family: 'Bebas Neue', cursive;
            font-size: 2.5em;
            color: #8B4513;
            margin-bottom: 30px;
            text-align: center;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }

        .product-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            cursor: pointer;
        }

        .product-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.2);
        }

        .product-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            background: #f8f9fa;
        }

        .product-info {
            padding: 25px;
        }

        .product-name {
            font-family: 'Bebas Neue', cursive;
            font-size: 1.5em;
            color: #2c3e50;
            margin-bottom: 10px;
            text-transform: uppercase;
        }

        .product-price {
            font-size: 1.8em;
            color: #8B4513;
            font-weight: bold;
            margin-bottom: 15px;
        }

        .product-description {
            color: #666;
            margin-bottom: 20px;
            line-height: 1.5;
        }

        .product-actions {
            display: flex;
            gap: 10px;
        }

        .btn-add-cart {
            flex: 1;
            background: linear-gradient(45deg, #28a745, #20c997);
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.3s ease;
            text-transform: uppercase;
        }

        .btn-add-cart:hover {
            transform: translateY(-2px);
        }

        .btn-details {
            background: #6c757d;
            color: white;
            border: none;
            padding: 12px 15px;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn-details:hover {
            background: #5a6268;
        }

        /* Cart Sidebar */
        .cart-sidebar {
            position: fixed;
            right: -400px;
            top: 0;
            width: 400px;
            height: 100vh;
            background: white;
            box-shadow: -5px 0 15px rgba(0, 0, 0, 0.3);
            z-index: 2000;
            transition: right 0.3s ease;
            display: flex;
            flex-direction: column;
        }

        .cart-sidebar.open {
            right: 0;
        }

        .cart-header {
            background: #8B4513;
            color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .cart-header h3 {
            font-family: 'Bebas Neue', cursive;
            font-size: 1.5em;
        }

        .cart-close {
            background: none;
            border: none;
            color: white;
            font-size: 1.5em;
            cursor: pointer;
        }

        .cart-items {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .cart-item {
            display: flex;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }

        .cart-item-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 8px;
        }

        .cart-item-info {
            flex: 1;
        }

        .cart-item-name {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .cart-item-price {
            color: #8B4513;
            font-weight: bold;
        }

        .cart-footer {
            padding: 20px;
            border-top: 1px solid #eee;
            background: #f8f9fa;
        }

        .cart-total {
            font-size: 1.3em;
            font-weight: bold;
            margin-bottom: 15px;
            text-align: center;
            color: #8B4513;
        }

        .btn-checkout {
            width: 100%;
            background: linear-gradient(45deg, #8B4513, #D2691E);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            text-transform: uppercase;
            transition: transform 0.3s ease;
        }

        .btn-checkout:hover {
            transform: translateY(-2px);
        }

        /* Empty states */
        .empty-category {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }

        .empty-category i {
            font-size: 4em;
            margin-bottom: 20px;
            color: #ccc;
        }

        .empty-cart {
            text-align: center;
            padding: 60px 20px;
            color: #666;
        }

        .empty-cart i {
            font-size: 3em;
            margin-bottom: 15px;
            color: #ccc;
        }

        /* Footer */
        .footer {
            background: #2c3e50;
            color: white;
            text-align: center;
            padding: 40px 0;
        }

        .footer p {
            margin-bottom: 10px;
        }

        .footer a {
            color: #D2691E;
            text-decoration: none;
        }

        /* Animations */
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive */
        @media (max-width: 768px) {
            .nav-menu {
                display: none;
            }

            .hero-content h1 {
                font-size: 3em;
            }

            .hero-content p {
                font-size: 1.1em;
            }

            .cart-sidebar {
                width: 100%;
                right: -100%;
            }

            .products-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-container">
            <div class="logo">
                🤠 CHAROLAIS
            </div>
            
            <nav class="nav-menu">
                <a href="#inicio">Inicio</a>
                <a href="#productos">Productos</a>
                <a href="#contacto">Contacto</a>
                <a href="admin/login.php">Admin</a>
            </nav>
            
            <div class="cart-icon" onclick="toggleCart()">
                <i class="fas fa-shopping-cart"></i>
                <span class="cart-count" id="cart-count">0</span>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero" id="inicio">
        <div class="hero-content">
            <h1>CHAROLAIS</h1>
            <p>Tradición vaquera auténtica desde el corazón de Monterrey, Nuevo León. 
               Descubre nuestra colección exclusiva que captura el espíritu del rodeo moderno.</p>
            <a href="#productos" class="hero-btn">
                <i class="fas fa-shopping-bag"></i> Ver Colección
            </a>
        </div>
    </section>

    <!-- Products Section -->
    <section class="products-section" id="productos">
        <div class="container">
            <div class="section-title">
                <h2>🤠 Nuestra Colección</h2>
                <p>Auténtico estilo vaquero mexicano con la calidad que te mereces</p>
            </div>

            <?php if (empty($products)): ?>
            <div class="empty-category">
                <i class="fas fa-box-open"></i>
                <h3>¡Pronto tendremos productos increíbles!</h3>
                <p>Estamos preparando una colección espectacular para ti.</p>
            </div>
            <?php else: ?>
                <?php foreach ($categories as $categoryName => $categoryProducts): ?>
                <div class="category-section">
                    <h3 class="category-title"><?php echo htmlspecialchars($categoryName); ?></h3>
                    
                    <div class="products-grid">
                        <?php foreach ($categoryProducts as $product): ?>
                        <div class="product-card" data-product-id="<?php echo $product['id']; ?>">
                            <?php if ($product['image_url']): ?>
                            <img src="<?php echo htmlspecialchars($product['image_url']); ?>" 
                                 alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                 class="product-image">
                            <?php else: ?>
                            <div class="product-image" style="display: flex; align-items: center; justify-content: center; background: #f8f9fa; color: #ccc;">
                                <i class="fas fa-image" style="font-size: 3em;"></i>
                            </div>
                            <?php endif; ?>
                            
                            <div class="product-info">
                                <h4 class="product-name"><?php echo htmlspecialchars($product['name']); ?></h4>
                                <div class="product-price"><?php echo formatPrice($product['price']); ?></div>
                                
                                <?php if ($product['description']): ?>
                                <p class="product-description"><?php echo htmlspecialchars($product['description']); ?></p>
                                <?php endif; ?>
                                
                                <div class="product-actions">
                                    <?php if ($product['total_stock'] > 0): ?>
                                    <button class="btn-add-cart" onclick="addToCart(<?php echo $product['id']; ?>)">
                                        <i class="fas fa-shopping-cart"></i> Agregar
                                    </button>
                                    <?php else: ?>
                                    <button class="btn-add-cart" disabled style="background: #ccc;">
                                        Sin Stock
                                    </button>
                                    <?php endif; ?>
                                    
                                    <button class="btn-details" onclick="showProductDetails(<?php echo $product['id']; ?>)">
                                        <i class="fas fa-info"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </section>

    <!-- Cart Sidebar -->
    <div class="cart-sidebar" id="cart-sidebar">
        <div class="cart-header">
            <h3><i class="fas fa-shopping-cart"></i> Mi Carrito</h3>
            <button class="cart-close" onclick="toggleCart()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="cart-items" id="cart-items">
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <h4>Tu carrito está vacío</h4>
                <p>¡Agrega algunos productos increíbles!</p>
            </div>
        </div>
        
        <div class="cart-footer" id="cart-footer" style="display: none;">
            <div class="cart-total" id="cart-total">Total: $0</div>
            <button class="btn-checkout" onclick="checkout()">
                <i class="fas fa-credit-card"></i> Pagar con Stripe
            </button>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> <?php echo SITE_NAME; ?> - Monterrey, N.L.</p>
            <p>Tradición vaquera auténtica | <a href="admin/login.php">Panel Admin</a></p>
        </div>
    </footer>

    <!-- Stripe -->
    <script src="https://js.stripe.com/v3/"></script>
    
    <script>
        // Variables globales
        let cart = JSON.parse(localStorage.getItem('charolais_cart')) || [];
        let products = <?php echo json_encode($products); ?>;
        
        // Configuración Stripe
        const stripe = Stripe('<?php echo STRIPE_PUBLISHABLE_KEY; ?>');

        // Inicializar
        document.addEventListener('DOMContentLoaded', function() {
            updateCartDisplay();
            updateCartCount();
        });

        // Funciones del carrito
        function toggleCart() {
            const sidebar = document.getElementById('cart-sidebar');
            sidebar.classList.toggle('open');
        }

        function addToCart(productId) {
            const product = products.find(p => p.id == productId);
            if (!product) return;

            const existingItem = cart.find(item => item.id == productId);
            if (existingItem) {
                existingItem.quantity += 1;
            } else {
                cart.push({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    image: product.image_url,
                    quantity: 1
                });
            }

            localStorage.setItem('charolais_cart', JSON.stringify(cart));
            updateCartDisplay();
            updateCartCount();
            
            // Mostrar feedback
            showNotification('Producto agregado al carrito', 'success');
        }

        function removeFromCart(productId) {
            cart = cart.filter(item => item.id != productId);
            localStorage.setItem('charolais_cart', JSON.stringify(cart));
            updateCartDisplay();
            updateCartCount();
        }

        function updateCartDisplay() {
            const cartItems = document.getElementById('cart-items');
            const cartFooter = document.getElementById('cart-footer');
            const cartTotal = document.getElementById('cart-total');

            if (cart.length === 0) {
                cartItems.innerHTML = `
                    <div class="empty-cart">
                        <i class="fas fa-shopping-cart"></i>
                        <h4>Tu carrito está vacío</h4>
                        <p>¡Agrega algunos productos increíbles!</p>
                    </div>
                `;
                cartFooter.style.display = 'none';
            } else {
                cartItems.innerHTML = cart.map(item => `
                    <div class="cart-item">
                        <img src="${item.image || 'placeholder.jpg'}" alt="${item.name}" class="cart-item-image">
                        <div class="cart-item-info">
                            <div class="cart-item-name">${item.name}</div>
                            <div class="cart-item-price">$${item.price.toLocaleString()} x ${item.quantity}</div>
                            <button onclick="removeFromCart(${item.id})" style="background: #dc3545; color: white; border: none; padding: 5px 10px; border-radius: 4px; cursor: pointer; margin-top: 5px;">
                                <i class="fas fa-trash"></i> Eliminar
                            </button>
                        </div>
                    </div>
                `).join('');

                const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
                cartTotal.textContent = `Total: $${total.toLocaleString()}`;
                cartFooter.style.display = 'block';
            }
        }

        function updateCartCount() {
            const count = cart.reduce((sum, item) => sum + item.quantity, 0);
            document.getElementById('cart-count').textContent = count;
        }

        function showProductDetails(productId) {
            const product = products.find(p => p.id == productId);
            if (!product) return;

            alert(`${product.name}\n\nPrecio: $${product.price.toLocaleString()}\n\n${product.description || 'Sin descripción disponible'}`);
        }

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 100px;
                right: 20px;
                background: ${type === 'success' ? '#28a745' : '#007bff'};
                color: white;
                padding: 15px 20px;
                border-radius: 8px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.3);
                z-index: 3000;
                animation: slideInRight 0.3s ease;
            `;
            notification.textContent = message;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }

        async function checkout() {
            if (cart.length === 0) {
                showNotification('Tu carrito está vacío', 'error');
                return;
            }

            try {
                // Crear sesión de Stripe
                const response = await fetch('api/stripe_checkout.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        cart: cart
                    })
                });

                const session = await response.json();
                
                if (session.error) {
                    showNotification('Error: ' + session.error, 'error');
                    return;
                }

                // Redirigir a Stripe Checkout
                const result = await stripe.redirectToCheckout({
                    sessionId: session.id
                });

                if (result.error) {
                    showNotification('Error: ' + result.error.message, 'error');
                }

            } catch (error) {
                console.error('Error:', error);
                showNotification('Error al procesar el pago', 'error');
            }
        }

        // Smooth scroll para navegación
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });

        console.log('🤠 ¡Bienvenido a Charolais! Tradición vaquera auténtica desde Monterrey, N.L.');
    </script>
</body>
</html> 