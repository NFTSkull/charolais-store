<?php
// 🚀 CHAROLAIS - INSTALADOR AUTOMÁTICO DE PRODUCTOS
// ===============================================
// EJECUTAR SOLO UNA VEZ DESPUÉS DE INSTALAR LA BASE DE DATOS
require_once 'config.php';

echo "<h1>🤠 Instalando Productos de Charolais...</h1>";

try {
    $db = Database::getInstance()->getConnection();
    
    // Verificar si ya hay productos
    $stmt = $db->query("SELECT COUNT(*) as count FROM products");
    $count = $stmt->fetch()['count'];
    
    if ($count > 0) {
        echo "<p style='color: orange;'>⚠️ Ya hay $count productos en la base de datos.</p>";
        echo "<p><a href='?force=1'>¿Quieres reinstalar todos los productos?</a></p>";
        
        if (!isset($_GET['force'])) {
            echo "<p><a href='admin/'>Ir al panel de administración</a></p>";
            exit;
        }
        
        // Limpiar productos existentes
        $db->exec("DELETE FROM products");
        echo "<p style='color: red;'>🗑️ Productos anteriores eliminados</p>";
    }
    
    // Productos a instalar con sus imágenes
    $productos = [
        // SOMBREROS
        [
            'name' => 'Gorra Vaquera Clásica',
            'description' => 'Gorra auténtica estilo vaquero, perfecta para el día a día',
            'price' => 450,
            'category' => 'Sombreros',
            'stock_quantity' => 25,
            'image_url' => 'Gorra.JPG',
            'featured' => 1
        ],
        [
            'name' => 'Gorra Western Premium',
            'description' => 'Gorra premium con detalles únicos de Monterrey',
            'price' => 520,
            'category' => 'Sombreros',
            'stock_quantity' => 20,
            'image_url' => 'gorra 2.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Gorra Rodeo Style',
            'description' => 'Diseño exclusivo inspirado en el rodeo mexicano',
            'price' => 480,
            'category' => 'Sombreros',
            'stock_quantity' => 30,
            'image_url' => 'Gorra 3.JPG',
            'featured' => 0
        ],
        
        // CAMISETAS HOMBRE
        [
            'name' => 'Playera All Around',
            'description' => 'Diseño versátil para el vaquero moderno',
            'price' => 380,
            'category' => 'Camisetas',
            'stock_quantity' => 35,
            'image_url' => 'all arround.JPG',
            'featured' => 1
        ],
        [
            'name' => 'Playera All Around Blanca',
            'description' => 'Edición especial en color blanco',
            'price' => 380,
            'category' => 'Camisetas',
            'stock_quantity' => 30,
            'image_url' => 'all arround blanca.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Playera Bronc Riding',
            'description' => 'Inspirada en la monta de broncos',
            'price' => 420,
            'category' => 'Camisetas',
            'stock_quantity' => 25,
            'image_url' => 'Bronc Riding.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Playera Bronc Riding Premium',
            'description' => 'Versión premium del diseño Bronc Riding',
            'price' => 450,
            'category' => 'Camisetas',
            'stock_quantity' => 20,
            'image_url' => 'Bronc Riding 1.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Playera Cowboy Skull',
            'description' => 'Diseño atrevido con calavera vaquera',
            'price' => 400,
            'category' => 'Camisetas',
            'stock_quantity' => 28,
            'image_url' => 'Cowboy Skull.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Playera Cowboy Skull Blanca',
            'description' => 'Edición especial en blanco',
            'price' => 400,
            'category' => 'Camisetas',
            'stock_quantity' => 25,
            'image_url' => 'Cowboy Skull blanca.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Playera Rodeo Clown',
            'description' => 'Homenaje a los payasos de rodeo',
            'price' => 390,
            'category' => 'Camisetas',
            'stock_quantity' => 30,
            'image_url' => 'Rodeo Clown.JPG',
            'featured' => 0
        ],
        
        // CAMISETAS MUJER
        [
            'name' => 'Sierra Spirits',
            'description' => 'Diseño femenino inspirado en las montañas del norte',
            'price' => 420,
            'category' => 'Mujer',
            'stock_quantity' => 22,
            'image_url' => 'Boutique mujer unitalla.JPG',
            'featured' => 1
        ],
        [
            'name' => 'Gunsmoke Rose',
            'description' => 'Elegancia western con toque femenino',
            'price' => 450,
            'category' => 'Mujer',
            'stock_quantity' => 18,
            'image_url' => 'Boutique unitalla 1.JPG',
            'featured' => 1
        ],
        [
            'name' => 'CowGirls Spirit',
            'description' => 'Para las vaqueras de corazón',
            'price' => 410,
            'category' => 'Mujer',
            'stock_quantity' => 25,
            'image_url' => 'CowGirls.JPG',
            'featured' => 0
        ],
        
        // ACCESORIOS
        [
            'name' => 'Desert Bloom',
            'description' => 'Accesorio único inspirado en el desierto',
            'price' => 320,
            'category' => 'Accesorios',
            'stock_quantity' => 15,
            'image_url' => 'Accesorios.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Wildflower Rodeo',
            'description' => 'Accesorios con diseño floral western',
            'price' => 350,
            'category' => 'Accesorios',
            'stock_quantity' => 12,
            'image_url' => 'Accesorios 2.JPG',
            'featured' => 0
        ],
        
        // CONJUNTOS
        [
            'name' => 'Conjunto Charolais Completo',
            'description' => 'Set completo con playera y accesorios',
            'price' => 850,
            'category' => 'Conjuntos',
            'stock_quantity' => 10,
            'image_url' => 'Charolais conjunto.JPG',
            'featured' => 1
        ],
        [
            'name' => 'Conjunto Cowboy Skull',
            'description' => 'Combo playera y gorra Cowboy Skull',
            'price' => 780,
            'category' => 'Conjuntos',
            'stock_quantity' => 8,
            'image_url' => 'Conjunto Cowboy Skull.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Conjunto Rodeo Clown',
            'description' => 'Set completo temático Rodeo Clown',
            'price' => 820,
            'category' => 'Conjuntos',
            'stock_quantity' => 6,
            'image_url' => 'Rodeo Clown Conjuntio.JPG',
            'featured' => 0
        ],
        [
            'name' => 'Conjunto CowGirl Premium',
            'description' => 'Set femenino completo premium',
            'price' => 890,
            'category' => 'Conjuntos',
            'stock_quantity' => 5,
            'image_url' => 'Conjunto CowGirl.JPG',
            'featured' => 1
        ]
    ];
    
    // Instalar productos
    $inserted = 0;
    foreach ($productos as $producto) {
        try {
            // Verificar si la imagen existe
            if ($producto['image_url'] && !file_exists($producto['image_url'])) {
                echo "<p style='color: orange;'>⚠️ Imagen no encontrada: {$producto['image_url']}</p>";
                $producto['image_url'] = ''; // Sin imagen si no existe
            }
            
            $stmt = $db->prepare("
                INSERT INTO products (
                    name, description, price, category, 
                    stock_quantity, image_url, featured, 
                    created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            
            $stmt->execute([
                $producto['name'],
                $producto['description'],
                $producto['price'],
                $producto['category'],
                $producto['stock_quantity'],
                $producto['image_url'],
                $producto['featured']
            ]);
            
            $inserted++;
            echo "<p style='color: green;'>✅ {$producto['name']} - ${$producto['price']}</p>";
            
        } catch (Exception $e) {
            echo "<p style='color: red;'>❌ Error con {$producto['name']}: {$e->getMessage()}</p>";
        }
    }
    
    echo "<hr>";
    echo "<h2 style='color: green;'>🎉 ¡Instalación Completada!</h2>";
    echo "<p><strong>Productos instalados:</strong> $inserted</p>";
    echo "<p><strong>Categorías creadas:</strong> Sombreros, Camisetas, Mujer, Accesorios, Conjuntos</p>";
    
    // Mostrar estadísticas
    $stats = $db->query("
        SELECT category, COUNT(*) as count, AVG(price) as avg_price 
        FROM products 
        GROUP BY category
    ")->fetchAll();
    
    echo "<h3>📊 Estadísticas por Categoría:</h3>";
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Categoría</th><th>Productos</th><th>Precio Promedio</th></tr>";
    foreach ($stats as $stat) {
        echo "<tr>";
        echo "<td>{$stat['category']}</td>";
        echo "<td>{$stat['count']}</td>";
        echo "<td>$" . number_format($stat['avg_price'], 0) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
    
    echo "<hr>";
    echo "<h3>🚀 Próximos Pasos:</h3>";
    echo "<ol>";
    echo "<li>✅ Ve a tu tienda: <a href='index.php' target='_blank'>Ver Tienda</a></li>";
    echo "<li>✅ Accede al admin: <a href='admin/' target='_blank'>Panel Admin</a></li>";
    echo "<li>✅ Configura Stripe para pagos</li>";
    echo "<li>✅ Personaliza productos desde el admin</li>";
    echo "</ol>";
    
    echo "<div style='background: #d4edda; padding: 20px; border-radius: 10px; margin: 20px 0;'>";
    echo "<h4 style='color: #155724;'>🔐 Datos de Acceso Admin:</h4>";
    echo "<p><strong>URL:</strong> <a href='admin/'>https://tudominio.com/admin/</a></p>";
    echo "<p><strong>Contraseña:</strong> La que configuraste en config.php</p>";
    echo "</div>";
    
    echo "<div style='background: #fff3cd; padding: 20px; border-radius: 10px; margin: 20px 0;'>";
    echo "<h4 style='color: #856404;'>⚠️ IMPORTANTE:</h4>";
    echo "<p><strong>Elimina este archivo</strong> después de la instalación por seguridad:</p>";
    echo "<p><code>rm instalar_productos.php</code></p>";
    echo "</div>";
    
} catch (Exception $e) {
    echo "<h2 style='color: red;'>❌ Error de Instalación</h2>";
    echo "<p>Error: " . $e->getMessage() . "</p>";
    echo "<p>Verifica que:</p>";
    echo "<ul>";
    echo "<li>La base de datos esté configurada correctamente</li>";
    echo "<li>El archivo database.sql haya sido importado</li>";
    echo "<li>Las credenciales en config.php sean correctas</li>";
    echo "</ul>";
}
?>

<style>
body {
    font-family: Arial, sans-serif;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    line-height: 1.6;
}
h1, h2, h3 { color: #8B4513; }
table { width: 100%; margin: 20px 0; }
th, td { padding: 10px; text-align: left; }
th { background: #f8f9fa; }
code { background: #f8f9fa; padding: 2px 5px; border-radius: 3px; }
</style> 