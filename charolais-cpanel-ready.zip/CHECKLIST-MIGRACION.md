# ✅ CHECKLIST DE MIGRACIÓN A CPANEL

## 📋 PREPARACIÓN
- [ ] Descargué el archivo `charolais-cpanel-ready.zip`
- [ ] Descomprimí el archivo
- [ ] Verifiqué que tengo acceso a cPanel
- [ ] Tengo mi dominio configurado
- [ ] Tengo las claves de Stripe de producción

## 🎯 PASO 1: CREAR APLICACIÓN NODE.JS
- [ ] Accedí a cPanel
- [ ] Encontré "Setup Node.js App"
- [ ] Creé nueva aplicación con:
  - [ ] Node.js version: 18.x o superior
  - [ ] Application mode: Production
  - [ ] Application root: /home/tuusuario/charolais-store
  - [ ] Application URL: https://tudominio.com
  - [ ] Application startup file: server.js
- [ ] La aplicación se creó exitosamente

## 🎯 PASO 2: SUBIR ARCHIVOS
- [ ] Accedí a File Manager
- [ ] Navegué a la carpeta de la aplicación
- [ ] Subí todos los archivos de `charolais-cpanel-ready`
- [ ] Subí la carpeta `database` completa
- [ ] Subí la carpeta `public` completa
- [ ] Subí la carpeta `views` completa
- [ ] Subí la carpeta `uploads` completa
- [ ] Configuré permisos:
  - [ ] Carpetas: 755
  - [ ] Archivos: 644
  - [ ] Base de datos: 664

## 🎯 PASO 3: CONFIGURAR VARIABLES DE ENTORNO
- [ ] Regresé a Setup Node.js App
- [ ] Encontré mi aplicación
- [ ] Hice clic en "Environment Variables"
- [ ] Agregué NODE_ENV=production
- [ ] Agregué PORT=3000
- [ ] Agregué SESSION_SECRET=charolais_production_secret_key_2024_secure_random_string
- [ ] Agregué BASE_URL=https://tudominio.com
- [ ] Agregué STRIPE_SECRET_KEY=sk_live_mi_clave_secreta
- [ ] Agregué STRIPE_PUBLISHABLE_KEY=pk_live_mi_clave_publica
- [ ] Guardé todas las variables

## 🎯 PASO 4: INSTALAR DEPENDENCIAS
- [ ] Hice clic en "Run NPM Install"
- [ ] Esperé a que termine la instalación
- [ ] No hubo errores en la instalación

## 🎯 PASO 5: INICIAR APLICACIÓN
- [ ] Hice clic en "Restart App"
- [ ] La aplicación se inició correctamente
- [ ] El estado muestra "Running"

## 🎯 PASO 6: CONFIGURAR DOMINIO
- [ ] Configuré mi dominio en cPanel
- [ ] Apunté el dominio a la carpeta de la aplicación
- [ ] Instalé certificado SSL
- [ ] HTTPS está funcionando

## 🎯 PASO 7: VERIFICAR FUNCIONAMIENTO
- [ ] Página principal carga: https://tudominio.com
- [ ] Productos se muestran correctamente
- [ ] Imágenes se cargan
- [ ] Admin panel funciona: https://tudominio.com/admin
- [ ] API funciona: https://tudominio.com/api/products
- [ ] Carrito de compras funciona
- [ ] Variantes de productos funcionan

## 🎯 PASO 8: CONFIGURAR STRIPE
- [ ] Actualicé las claves de Stripe con las de producción
- [ ] Probé el checkout con Stripe
- [ ] Los pagos funcionan correctamente
- [ ] Envío gratis en primera compra funciona

## 🎯 PASO 9: VERIFICACIONES FINALES
- [ ] Todas las funcionalidades principales funcionan
- [ ] No hay errores en los logs
- [ ] La aplicación es estable
- [ ] Hice backup de la configuración

## 🎉 MIGRACIÓN COMPLETADA
- [ ] La tienda está funcionando en producción
- [ ] Todas las funcionalidades están operativas
- [ ] El sistema es estable y seguro

---

## 📞 EN CASO DE PROBLEMAS

### Si algo no funciona:
1. Revisa los logs de error en cPanel
2. Verifica que todas las variables estén configuradas
3. Asegúrate de que los permisos sean correctos
4. Confirma que el dominio esté bien configurado

### Logs útiles:
- Error Logs: cPanel → Error Logs
- Node.js Logs: Setup Node.js App → Logs
- Application Logs: Terminal/SSH → `tail -f logs/nodejs.log`

---

## 🎯 PRÓXIMOS PASOS DESPUÉS DE LA MIGRACIÓN

1. **Monitoreo**: Configurar alertas de monitoreo
2. **Backup**: Configurar backups automáticos
3. **Seguridad**: Revisar configuración de seguridad
4. **Optimización**: Optimizar rendimiento según sea necesario
5. **Contenido**: Actualizar productos y contenido
6. **Marketing**: Configurar analytics y tracking

---

## 📋 INFORMACIÓN IMPORTANTE

**URLs de tu tienda:**
- Tienda principal: https://tudominio.com
- Panel de admin: https://tudominio.com/admin
- API de productos: https://tudominio.com/api/products

**Credenciales de admin:**
- Usuario: admin
- Contraseña: (la que configuraste)

**Soporte:**
- Revisa los logs si hay problemas
- Verifica la configuración de variables
- Confirma que los permisos sean correctos 