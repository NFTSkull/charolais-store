# 🚀 GUÍA PASO A PASO - Migración a cPanel

## 📋 ANTES DE EMPEZAR

### ✅ Verificaciones Previas:
- [ ] Tienes acceso a tu cPanel
- [ ] Tienes un dominio configurado
- [ ] Tienes las claves de Stripe de producción
- [ ] Tienes Node.js disponible en tu hosting

---

## 🎯 PASO 1: PREPARAR ARCHIVOS

### 1.1 Descargar el archivo de migración
- Descarga el archivo `charolais-cpanel-ready.zip`
- Descomprime el archivo en tu computadora

### 1.2 Verificar contenido
El archivo debe contener:
```
charolais-cpanel-ready/
├── server.js
├── package.json
├── package-lock.json
├── database/
│   └── charolais.db
├── public/
│   ├── css/
│   │   └── styles.css
│   └── js/
│       ├── main.js
│       └── admin.js
├── views/
│   ├── index.html
│   ├── admin.html
│   ├── success.html
│   └── cancel.html
├── uploads/
└── README-MIGRATION.md
```

---

## 🎯 PASO 2: ACCEDER A CPANEL

### 2.1 Iniciar sesión
1. Ve a tu proveedor de hosting
2. Inicia sesión en cPanel
3. Busca la sección "Software" o "Node.js"

### 2.2 Verificar Node.js
1. Busca "Setup Node.js App" o "Node.js Selector"
2. Verifica que tengas Node.js 18.x o superior disponible

---

## 🎯 PASO 3: CREAR APLICACIÓN NODE.JS

### 3.1 Configurar aplicación
1. Haz clic en "Create Application" o "Crear Aplicación"
2. Completa los campos:

```
Node.js version: 18.x (o la más reciente disponible)
Application mode: Production
Application root: /home/tuusuario/charolais-store
Application URL: https://tudominio.com
Application startup file: server.js
```

### 3.2 Crear la aplicación
1. Haz clic en "Create" o "Crear"
2. Espera a que se cree la aplicación
3. Anota la URL de la aplicación

---

## 🎯 PASO 4: SUBIR ARCHIVOS

### 4.1 Usar File Manager
1. En cPanel, busca "File Manager"
2. Navega a la carpeta de tu aplicación (ej: `/home/tuusuario/charolais-store`)
3. Haz clic en "Upload" o "Subir"

### 4.2 Subir archivos
1. Selecciona todos los archivos de la carpeta `charolais-cpanel-ready`
2. Sube los archivos uno por uno o en lotes
3. **IMPORTANTE**: Sube también las carpetas `database`, `public`, `views`, `uploads`

### 4.3 Verificar permisos
1. Selecciona todas las carpetas
2. Haz clic derecho → "Change Permissions"
3. Configura:
   - Carpetas: 755
   - Archivos: 644
   - Base de datos: 664

---

## 🎯 PASO 5: CONFIGURAR VARIABLES DE ENTORNO

### 5.1 Acceder a variables de entorno
1. Regresa a "Setup Node.js App"
2. Encuentra tu aplicación "charolais-store"
3. Haz clic en "Environment Variables" o "Variables de Entorno"

### 5.2 Agregar variables
Agrega estas variables una por una:

```
NODE_ENV = production
PORT = 3000
SESSION_SECRET = charolais_production_secret_key_2024_secure_random_string
BASE_URL = https://tudominio.com
STRIPE_SECRET_KEY = sk_live_tu_clave_secreta_de_produccion
STRIPE_PUBLISHABLE_KEY = pk_live_tu_clave_publica_de_produccion
```

### 5.3 Guardar configuración
1. Haz clic en "Save" o "Guardar" para cada variable
2. Verifica que todas las variables estén guardadas

---

## 🎯 PASO 6: INSTALAR DEPENDENCIAS

### 6.1 Ejecutar instalación
1. En "Setup Node.js App"
2. Encuentra tu aplicación
3. Haz clic en "Run NPM Install"
4. Espera a que termine la instalación

### 6.2 Verificar instalación
1. Busca mensajes de éxito
2. Si hay errores, revisa los logs

---

## 🎯 PASO 7: INICIAR APLICACIÓN

### 7.1 Reiniciar aplicación
1. En "Setup Node.js App"
2. Encuentra tu aplicación
3. Haz clic en "Restart App"
4. Espera a que se inicie

### 7.2 Verificar estado
1. El estado debe mostrar "Running" o "Ejecutándose"
2. Anota la URL de la aplicación

---

## 🎯 PASO 8: CONFIGURAR DOMINIO

### 8.1 Configurar dominio
1. En cPanel, busca "Domains" o "Dominios"
2. Agrega tu dominio si no está configurado
3. Apunta el dominio a la carpeta de la aplicación

### 8.2 Configurar SSL
1. En cPanel, busca "SSL/TLS Status"
2. Instala un certificado SSL para tu dominio
3. Asegúrate de que HTTPS esté habilitado

---

## 🎯 PASO 9: VERIFICAR FUNCIONAMIENTO

### 9.1 Probar URLs principales
Abre estas URLs en tu navegador:

```
Frontend: https://tudominio.com
Admin Panel: https://tudominio.com/admin
API Products: https://tudominio.com/api/products
```

### 9.2 Verificar funcionalidades
- [ ] Página principal carga
- [ ] Productos se muestran
- [ ] Imágenes se cargan
- [ ] Admin panel funciona
- [ ] Carrito funciona

---

## 🎯 PASO 10: CONFIGURAR STRIPE

### 10.1 Actualizar claves
1. Ve a tu dashboard de Stripe
2. Obtén las claves de producción
3. Actualiza las variables de entorno en cPanel

### 10.2 Probar checkout
1. Agrega un producto al carrito
2. Ve al checkout
3. Verifica que Stripe funcione

---

## 🔧 SOLUCIÓN DE PROBLEMAS

### Error 500
1. Revisa los logs en "Error Logs" de cPanel
2. Verifica que todas las variables estén configuradas
3. Asegúrate de que los permisos sean correctos

### Imágenes no cargan
1. Verifica permisos de la carpeta `uploads/` (755)
2. Asegúrate de que las imágenes se subieron correctamente
3. Revisa las rutas en el navegador

### Admin no funciona
1. Verifica la configuración de sesiones
2. Asegúrate de que `SESSION_SECRET` esté configurado
3. Revisa los logs de la aplicación

### Stripe no funciona
1. Verifica que las claves sean de producción
2. Asegúrate de que el dominio esté en la lista blanca de Stripe
3. Revisa la configuración de webhooks

---

## 📞 SOPORTE

### Logs útiles
- **Error Logs**: cPanel → Error Logs
- **Node.js Logs**: Setup Node.js App → Logs
- **Application Logs**: Terminal/SSH → `tail -f logs/nodejs.log`

### Contacto
Si tienes problemas, revisa:
1. Los logs de error
2. La configuración de variables
3. Los permisos de archivos
4. La configuración del dominio

---

## 🎉 ¡MIGRACIÓN COMPLETADA!

Una vez que hayas completado todos los pasos, tu tienda Charolais estará funcionando en producción.

**URLs importantes:**
- Tienda: https://tudominio.com
- Admin: https://tudominio.com/admin
- API: https://tudominio.com/api/products

**Próximos pasos:**
1. Probar todas las funcionalidades
2. Configurar monitoreo
3. Hacer backup regular
4. Actualizar contenido según sea necesario 