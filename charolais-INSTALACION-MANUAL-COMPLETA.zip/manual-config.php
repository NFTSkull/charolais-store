<?php
/**
 * CONFIGURACIÓN MANUAL DE CHAROLAIS STORE
 * COPIAR ESTE ARCHIVO COMO includes/config.php
 * CAMBIAR LOS VALORES SEGÚN TU CONFIGURACIÓN
 */

// ========================================
// CONFIGURACIÓN DE BASE DE DATOS
// ========================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'grecovi3_charolais');  // CAMBIAR por tu base de datos
define('DB_USER', 'grecovi3_charolais');  // CAMBIAR por tu usuario
define('DB_PASS', 'TU_CONTRASEÑA_AQUI');  // CAMBIAR por tu contraseña

// ========================================
// CONFIGURACIÓN DE LA APLICACIÓN
// ========================================
define('APP_URL', 'https://charolaishat.com');
define('APP_NAME', 'Charolais Store');
define('APP_VERSION', '1.0.0');

// ========================================
// CONFIGURACIÓN DE STRIPE (OPCIONAL)
// ========================================
define('STRIPE_PUBLISHABLE_KEY', ''); // pk_test_... o pk_live_...
define('STRIPE_SECRET_KEY', '');      // sk_test_... o sk_live_...

// ========================================
// CONFIGURACIÓN DE SESIÓN
// ========================================
define('SESSION_LIFETIME', 86400); // 24 horas

// ========================================
// CONFIGURACIÓN DE ARCHIVOS
// ========================================
define('UPLOAD_DIR', 'uploads/');
define('MAX_FILE_SIZE', 10485760); // 10MB

// ========================================
// CONFIGURACIÓN DE EMAIL (OPCIONAL)
// ========================================
define('SMTP_HOST', '');
define('SMTP_PORT', 587);
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('FROM_EMAIL', 'noreply@charolais.com');
define('FROM_NAME', 'Charolais Store');

// ========================================
// CONFIGURACIÓN DE SEGURIDAD
// ========================================
define('HASH_ALGO', 'sha256');
define('ENCRYPTION_KEY', 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6'); // CAMBIAR por clave única

// ========================================
// CONFIGURACIÓN DE DEBUG
// ========================================
define('DEBUG_MODE', false);  // Cambiar a true solo para debug
define('LOG_ERRORS', true);

// ========================================
// ZONA HORARIA
// ========================================
date_default_timezone_set('America/Mexico_City');

// ========================================
// VERIFICACIÓN DE CONFIGURACIÓN
// ========================================
if (DB_PASS === 'TU_CONTRASEÑA_AQUI') {
    die('ERROR: Debes cambiar la contraseña de la base de datos en includes/config.php');
}
?>