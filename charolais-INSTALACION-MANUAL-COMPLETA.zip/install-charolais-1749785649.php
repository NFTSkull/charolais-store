<?php
/**
 * CHAROLAIS INSTALLER - TIMESTAMP: 1749785649
 * NOMBRE ÚNICO PARA EVITAR CACHÉ DEL SERVIDOR
 * SIN JQUERY - SIN DEPENDENCIAS EXTERNAS
 */

// Anti-caché headers
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Verificar si ya está instalado
if (file_exists('includes/config.php') && !isset($_GET['force'])) {
    die('La aplicación ya está instalada. Agrega ?force=1 para forzar la reinstalación.');
}

$step = $_GET['step'] ?? 1;
$errors = [];
$success = [];

// Procesar formulario de configuración
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $db_host = $_POST['db_host'] ?? '';
    $db_name = $_POST['db_name'] ?? '';
    $db_user = $_POST['db_user'] ?? '';
    $db_pass = $_POST['db_pass'] ?? '';
    $app_url = $_POST['app_url'] ?? '';
    $stripe_pk = $_POST['stripe_pk'] ?? '';
    $stripe_sk = $_POST['stripe_sk'] ?? '';
    $admin_user = $_POST['admin_user'] ?? '';
    $admin_pass = $_POST['admin_pass'] ?? '';
    $admin_email = $_POST['admin_email'] ?? '';
    
    // Validar datos
    if (empty($db_host) || empty($db_name) || empty($db_user)) {
        $errors[] = 'Todos los campos de base de datos son requeridos';
    }
    
    if (empty($app_url)) {
        $errors[] = 'La URL de la aplicación es requerida';
    }
    
    if (empty($admin_user) || empty($admin_pass) || empty($admin_email)) {
        $errors[] = 'Los datos del administrador son requeridos';
    }
    
    if (strlen($admin_pass) < 6) {
        $errors[] = 'La contraseña del administrador debe tener al menos 6 caracteres';
    }
    
    // Si no hay errores, proceder con la instalación
    if (empty($errors)) {
        try {
            // Probar conexión a base de datos
            $pdo = new PDO("mysql:host=$db_host;charset=utf8mb4", $db_user, $db_pass);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // Crear base de datos si no existe
            $pdo->exec("CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            $pdo->exec("USE `$db_name`");
            
            // Crear estructura de tablas
            createTables($pdo);
            
            // Crear archivo de configuración
            createConfigFile($db_host, $db_name, $db_user, $db_pass, $app_url, $stripe_pk, $stripe_sk);
            
            // Crear administrador
            createAdmin($pdo, $admin_user, $admin_pass, $admin_email);
            
            // Crear directorios necesarios
            createDirectories();
            
            $success[] = 'Instalación completada exitosamente';
            $step = 3;
            
        } catch (Exception $e) {
            $errors[] = 'Error durante la instalación: ' . $e->getMessage();
        }
    }
}

function createTables($pdo) {
    $tables = [
        "CREATE TABLE IF NOT EXISTS admins (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            email VARCHAR(100),
            is_active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        "CREATE TABLE IF NOT EXISTS categories (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        "CREATE TABLE IF NOT EXISTS products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            price DECIMAL(10,2) NOT NULL,
            category_id INT,
            stock_quantity INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            rating DECIMAL(3,2) DEFAULT 0,
            reviews_count INT DEFAULT 0,
            sort_order INT DEFAULT 0,
            stripe_price_id VARCHAR(100),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
        )",
        
        "CREATE TABLE IF NOT EXISTS product_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        )",
        
        "CREATE TABLE IF NOT EXISTS product_variants (
            id INT AUTO_INCREMENT PRIMARY KEY,
            product_id INT NOT NULL,
            variant_name VARCHAR(100) NOT NULL,
            sku VARCHAR(100),
            price_override DECIMAL(10,2),
            stock_quantity INT DEFAULT 0,
            is_active BOOLEAN DEFAULT TRUE,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
        )",
        
        "CREATE TABLE IF NOT EXISTS variant_images (
            id INT AUTO_INCREMENT PRIMARY KEY,
            variant_id INT NOT NULL,
            image_url VARCHAR(500) NOT NULL,
            sort_order INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE CASCADE
        )",
        
        "CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            stripe_session_id VARCHAR(255),
            customer_email VARCHAR(100),
            customer_name VARCHAR(100),
            total_amount DECIMAL(10,2) NOT NULL,
            shipping_amount DECIMAL(10,2) DEFAULT 0,
            status ENUM('pending', 'paid', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
            shipping_address TEXT,
            billing_address TEXT,
            is_first_purchase BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )",
        
        "CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            product_id INT,
            variant_id INT,
            product_name VARCHAR(200) NOT NULL,
            variant_name VARCHAR(100),
            quantity INT NOT NULL,
            unit_price DECIMAL(10,2) NOT NULL,
            total_price DECIMAL(10,2) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
            FOREIGN KEY (variant_id) REFERENCES product_variants(id) ON DELETE SET NULL
        )",
        
        "CREATE TABLE IF NOT EXISTS system_settings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            setting_key VARCHAR(100) UNIQUE NOT NULL,
            setting_value TEXT,
            description VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )"
    ];
    
    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }
}

function createConfigFile($db_host, $db_name, $db_user, $db_pass, $app_url, $stripe_pk, $stripe_sk) {
    if (!is_dir('includes')) {
        mkdir('includes', 0755, true);
    }
    
    $config = "<?php
define('DB_HOST', '$db_host');
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASS', '$db_pass');
define('APP_URL', '$app_url');
define('APP_NAME', 'Charolais Store');
define('APP_VERSION', '1.0.0');
define('STRIPE_PUBLISHABLE_KEY', '$stripe_pk');
define('STRIPE_SECRET_KEY', '$stripe_sk');
define('SESSION_LIFETIME', 86400);
define('UPLOAD_DIR', 'uploads/');
define('MAX_FILE_SIZE', 10485760);
define('SMTP_HOST', '');
define('SMTP_PORT', 587);
define('SMTP_USER', '');
define('SMTP_PASS', '');
define('FROM_EMAIL', 'noreply@charolais.com');
define('FROM_NAME', 'Charolais Store');
define('HASH_ALGO', 'sha256');
define('ENCRYPTION_KEY', '" . bin2hex(random_bytes(32)) . "');
define('DEBUG_MODE', false);
define('LOG_ERRORS', true);
date_default_timezone_set('America/Mexico_City');
";

    file_put_contents('includes/config.php', $config);
}

function createAdmin($pdo, $username, $password, $email) {
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash, email) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE password_hash = ?, email = ?");
    $stmt->execute([$username, $password_hash, $email, $password_hash, $email]);
}

function createDirectories() {
    $dirs = ['uploads', 'uploads/products', 'uploads/categories', 'logs', 'cache'];
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
    }
}
?><!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤠 Charolais Installer - ÚNICO</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #8B4513 0%, #D2691E 100%);
            min-height: 100vh; padding: 20px;
        }
        .container { max-width: 800px; margin: 0 auto; }
        .card { 
            background: white; border-radius: 15px; 
            box-shadow: 0 10px 30px rgba(0,0,0,0.3); padding: 40px; 
        }
        .header { text-align: center; margin-bottom: 30px; }
        .header h1 { color: #8B4513; margin-bottom: 10px; font-size: 2.5em; }
        .header p { 
            color: #666; font-size: 1.1em; background: #e8f5e8; 
            padding: 10px; border-radius: 8px; border-left: 4px solid #28a745; 
        }
        .alert { 
            padding: 20px; margin-bottom: 25px; border-radius: 8px; border-left: 5px solid; 
        }
        .alert-danger { 
            background: #f8d7da; color: #721c24; border-left-color: #dc3545; 
        }
        .alert-success { 
            background: #d4edda; color: #155724; border-left-color: #28a745; 
        }
        .form-group { margin-bottom: 25px; }
        .form-label { 
            display: block; margin-bottom: 8px; font-weight: bold; 
            color: #333; font-size: 1.1em; 
        }
        .form-control { 
            width: 100%; padding: 15px; border: 2px solid #ddd; 
            border-radius: 8px; font-size: 16px; 
        }
        .form-control:focus { 
            outline: none; border-color: #8B4513; 
            box-shadow: 0 0 10px rgba(139, 69, 19, 0.3); 
        }
        .btn { 
            padding: 15px 30px; border: none; border-radius: 8px; 
            font-size: 18px; cursor: pointer; text-decoration: none; 
            display: inline-block; text-align: center; font-weight: bold; 
        }
        .btn-primary { background: #8B4513; color: white; }
        .btn-primary:hover { background: #6d3410; }
        .btn-success { background: #28a745; color: white; }
        .btn-success:hover { background: #218838; }
        .btn-lg { padding: 20px 40px; font-size: 20px; }
        .row { display: flex; flex-wrap: wrap; margin: -15px; }
        .col-md-6 { flex: 0 0 50%; padding: 15px; }
        .text-center { text-align: center; }
        .mt-4 { margin-top: 2rem; }
        .success-icon { font-size: 5em; color: #28a745; margin-bottom: 20px; }
        @media (max-width: 768px) {
            .col-md-6 { flex: 0 0 100%; }
            .card { padding: 25px; }
            .header h1 { font-size: 2em; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="header">
                <h1>🤠 Charolais Store</h1>
                <p><strong>✅ INSTALADOR ÚNICO - TIMESTAMP: 1749785649</strong></p>
                <p><strong>🚫 SIN JQUERY - SIN DEPENDENCIAS EXTERNAS</strong></p>
            </div>
            
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <h5>❌ Errores encontrados:</h5>
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?php echo htmlspecialchars($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="alert alert-success">
                    <h5>✅ ¡Instalación exitosa!</h5>
                    <ul>
                        <?php foreach ($success as $msg): ?>
                            <li><?php echo htmlspecialchars($msg); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <?php if ($step == 1): ?>
                <div class="text-center">
                    <h3>🔍 Verificación del Sistema</h3>
                    <p>PHP Version: <?php echo PHP_VERSION; ?></p>
                    <p>PDO: <?php echo extension_loaded('pdo') ? '✅' : '❌'; ?></p>
                    <p>MySQL: <?php echo extension_loaded('pdo_mysql') ? '✅' : '❌'; ?></p>
                    <div class="mt-4">
                        <a href="?step=2" class="btn btn-primary btn-lg">Continuar ➡️</a>
                    </div>
                </div>
                
            <?php elseif ($step == 2): ?>
                <form method="POST" action="?step=2">
                    <h3>⚙️ Configuración de la Aplicación</h3>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <h5>📊 Base de Datos</h5>
                            <div class="form-group">
                                <label class="form-label">Host MySQL</label>
                                <input type="text" class="form-control" name="db_host" value="localhost" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Nombre Base de Datos</label>
                                <input type="text" class="form-control" name="db_name" value="grecovi3_charolais" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Usuario MySQL</label>
                                <input type="text" class="form-control" name="db_user" value="grecovi3_charolais" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Contraseña MySQL</label>
                                <input type="password" class="form-control" name="db_pass" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <h5>🌐 Aplicación</h5>
                            <div class="form-group">
                                <label class="form-label">URL Aplicación</label>
                                <input type="url" class="form-control" name="app_url" value="https://charolaishat.com" required>
                            </div>
                            
                            <h5>👤 Administrador</h5>
                            <div class="form-group">
                                <label class="form-label">Usuario Admin</label>
                                <input type="text" class="form-control" name="admin_user" value="admin" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Contraseña Admin</label>
                                <input type="password" class="form-control" name="admin_pass" value="Admin123!" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Email Admin</label>
                                <input type="email" class="form-control" name="admin_email" required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label">Stripe Public Key (Opcional)</label>
                                <input type="text" class="form-control" name="stripe_pk" placeholder="pk_test_...">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Stripe Secret Key (Opcional)</label>
                                <input type="password" class="form-control" name="stripe_sk" placeholder="sk_test_...">
                            </div>
                        </div>
                    </div>
                    
                    <div class="text-center mt-4">
                        <button type="submit" class="btn btn-success btn-lg">🚀 Instalar Charolais Store</button>
                    </div>
                </form>
                
            <?php elseif ($step == 3): ?>
                <div class="text-center">
                    <div class="success-icon">🎉</div>
                    <h1 style="color: #28a745; margin-bottom: 20px;">¡Instalación Completada!</h1>
                    <p style="font-size: 1.2em; margin-bottom: 30px;">Tu tienda Charolais está lista.</p>
                    
                    <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                        <h5>🔑 Accesos:</h5>
                        <p><strong>🛍️ Tienda:</strong> <a href="index.php" target="_blank">Ver Tienda</a></p>
                        <p><strong>⚙️ Admin:</strong> <a href="admin/" target="_blank">Panel Admin</a></p>
                        <p><strong>👤 Usuario:</strong> admin</p>
                        <p><strong>🔐 Contraseña:</strong> Admin123!</p>
                    </div>
                    
                    <div class="mt-4">
                        <a href="admin/setup-sample-data.php" class="btn btn-primary" style="margin-right: 15px;">📦 Agregar Productos</a>
                        <a href="index.php" class="btn btn-success">🛍️ Ver Tienda</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>