<?php
/**
 * Gestión de Categorías - Panel de Administración
 */

require_once '../includes/config.php';
require_once '../includes/database.php';
require_once '../includes/auth.php';

// Verificar autenticación
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$action = $_GET['action'] ?? 'list';
$categoryId = $_GET['id'] ?? null;
$message = '';
$error = '';

// Procesar acciones
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($action === 'add' || $action === 'edit') {
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $isActive = isset($_POST['is_active']) ? 1 : 0;
        $sortOrder = $_POST['sort_order'] ?? 0;
        
        if (empty($name)) {
            $error = 'El nombre es requerido';
        } else {
            try {
                if ($action === 'add') {
                    $db->insert("INSERT INTO categories (name, description, is_active, sort_order) VALUES (?, ?, ?, ?)", 
                               [$name, $description, $isActive, $sortOrder]);
                    $message = 'Categoría agregada exitosamente';
                    $action = 'list';
                } else {
                    $db->update("UPDATE categories SET name = ?, description = ?, is_active = ?, sort_order = ? WHERE id = ?", 
                               [$name, $description, $isActive, $sortOrder, $categoryId]);
                    $message = 'Categoría actualizada exitosamente';
                    $action = 'list';
                }
            } catch (Exception $e) {
                $error = 'Error al guardar la categoría: ' . $e->getMessage();
            }
        }
    }
}

// Eliminar categoría
if ($action === 'delete' && $categoryId) {
    try {
        // Verificar si hay productos en esta categoría
        $productCount = $db->select("SELECT COUNT(*) as count FROM products WHERE category_id = ?", [$categoryId])[0]['count'] ?? 0;
        
        if ($productCount > 0) {
            $error = 'No se puede eliminar la categoría porque tiene productos asociados';
        } else {
            $db->delete("DELETE FROM categories WHERE id = ?", [$categoryId]);
            $message = 'Categoría eliminada exitosamente';
        }
        $action = 'list';
    } catch (Exception $e) {
        $error = 'Error al eliminar la categoría: ' . $e->getMessage();
    }
}

// Obtener categoría para editar
$category = null;
if ($action === 'edit' && $categoryId) {
    $categories = $db->select("SELECT * FROM categories WHERE id = ?", [$categoryId]);
    $category = $categories[0] ?? null;
    if (!$category) {
        $error = 'Categoría no encontrada';
        $action = 'list';
    }
}

// Obtener lista de categorías
if ($action === 'list') {
    $categories = $db->select("
        SELECT c.*, COUNT(p.id) as product_count 
        FROM categories c 
        LEFT JOIN products p ON c.id = p.category_id 
        GROUP BY c.id 
        ORDER BY c.sort_order, c.name
    ");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Categorías - <?php echo APP_NAME; ?></title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        .sidebar {
            min-height: 100vh;
            background: #343a40;
            width: 250px;
        }
        .sidebar .nav-link {
            color: #adb5bd;
            padding: 0.75rem 1rem;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            color: #fff;
            background: #495057;
        }
        .main-content {
            margin-left: 0;
        }
        @media (min-width: 768px) {
            .main-content {
                margin-left: 250px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <nav class="sidebar position-fixed d-none d-md-block">
        <div class="p-3">
            <h5 class="text-white">
                <i class="fas fa-hat-cowboy"></i>
                <?php echo APP_NAME; ?>
            </h5>
            <small class="text-muted">Panel de Admin</small>
        </div>
        
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="products.php">
                    <i class="fas fa-box"></i> Productos
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" href="categories.php">
                    <i class="fas fa-tags"></i> Categorías
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="orders.php">
                    <i class="fas fa-shopping-cart"></i> Órdenes
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="images.php">
                    <i class="fas fa-images"></i> Imágenes
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="settings.php">
                    <i class="fas fa-cog"></i> Configuración
                </a>
            </li>
            <li class="nav-item mt-3">
                <a class="nav-link" href="../" target="_blank">
                    <i class="fas fa-external-link-alt"></i> Ver Tienda
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light border-bottom">
            <div class="container-fluid">
                <h4 class="mb-0">Gestión de Categorías</h4>
                
                <div class="ms-auto">
                    <?php if ($action === 'list'): ?>
                        <a href="?action=add" class="btn btn-primary">
                            <i class="fas fa-plus"></i> Agregar Categoría
                        </a>
                    <?php else: ?>
                        <a href="categories.php" class="btn btn-secondary">
                            <i class="fas fa-arrow-left"></i> Volver
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </nav>

        <!-- Content -->
        <div class="container-fluid p-4">
            <!-- Messages -->
            <?php if ($message): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i>
                    <?php echo htmlspecialchars($message); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-triangle"></i>
                    <?php echo htmlspecialchars($error); ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if ($action === 'list'): ?>
                <!-- Lista de Categorías -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Lista de Categorías</h5>
                    </div>
                    <div class="card-body">
                        <?php if (empty($categories)): ?>
                            <div class="text-center py-5">
                                <i class="fas fa-tags fa-3x text-muted mb-3"></i>
                                <h5>No hay categorías registradas</h5>
                                <p class="text-muted">Comienza agregando tu primera categoría</p>
                                <a href="?action=add" class="btn btn-primary">
                                    <i class="fas fa-plus"></i> Agregar Primera Categoría
                                </a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nombre</th>
                                            <th>Descripción</th>
                                            <th>Productos</th>
                                            <th>Orden</th>
                                            <th>Estado</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($categories as $cat): ?>
                                        <tr>
                                            <td><?php echo $cat['id']; ?></td>
                                            <td><?php echo htmlspecialchars($cat['name']); ?></td>
                                            <td><?php echo htmlspecialchars($cat['description'] ?? ''); ?></td>
                                            <td>
                                                <span class="badge bg-info">
                                                    <?php echo $cat['product_count']; ?> productos
                                                </span>
                                            </td>
                                            <td><?php echo $cat['sort_order']; ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $cat['is_active'] ? 'success' : 'secondary'; ?>">
                                                    <?php echo $cat['is_active'] ? 'Activa' : 'Inactiva'; ?>
                                                </span>
                                            </td>
                                            <td>
                                                <div class="btn-group btn-group-sm">
                                                    <a href="?action=edit&id=<?php echo $cat['id']; ?>" class="btn btn-outline-primary">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <?php if ($cat['product_count'] == 0): ?>
                                                        <a href="?action=delete&id=<?php echo $cat['id']; ?>" 
                                                           class="btn btn-outline-danger"
                                                           onclick="return confirm('¿Estás seguro de eliminar esta categoría?')">
                                                            <i class="fas fa-trash"></i>
                                                        </a>
                                                    <?php else: ?>
                                                        <button class="btn btn-outline-secondary" disabled title="No se puede eliminar: tiene productos">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

            <?php elseif ($action === 'add' || $action === 'edit'): ?>
                <!-- Formulario de Categoría -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <?php echo $action === 'add' ? 'Agregar Categoría' : 'Editar Categoría'; ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="mb-3">
                                        <label class="form-label">Nombre de la Categoría *</label>
                                        <input type="text" class="form-control" name="name" 
                                               value="<?php echo htmlspecialchars($category['name'] ?? ''); ?>" required>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Descripción</label>
                                        <textarea class="form-control" name="description" rows="3"><?php echo htmlspecialchars($category['description'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                                
                                <div class="col-md-4">
                                    <div class="mb-3">
                                        <label class="form-label">Orden de Visualización</label>
                                        <input type="number" class="form-control" name="sort_order" min="0"
                                               value="<?php echo $category['sort_order'] ?? 0; ?>">
                                        <small class="form-text text-muted">Menor número aparece primero</small>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" name="is_active" 
                                                   <?php echo ($category['is_active'] ?? 1) ? 'checked' : ''; ?>>
                                            <label class="form-check-label">
                                                Categoría activa
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <a href="categories.php" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Cancelar
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i> 
                                    <?php echo $action === 'add' ? 'Agregar Categoría' : 'Actualizar Categoría'; ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 