const express = require('express');
const stripe = require('stripe')('sk_test_51RVtmmQP0z32gxjTmNqfQ6BcabyMnGOm00dEfgViYOY9hQskuD6U0amKFIqfWzR417QGEMYrghGmef2mFxKYhedJ005GIP07W4');
const cors = require('cors');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcryptjs');
const session = require('express-session');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Inicializar base de datos
const db = new sqlite3.Database('charolais.db');

// Configuración de sesiones
app.use(session({
    secret: 'charolais-secret-key-2024',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false, // Set to true in production with HTTPS
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('.'));

// Crear directorio para uploads si no existe
const uploadsDir = './uploads';
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// Configuración de multer para uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadsDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024 // 10MB
    },
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) {
            cb(null, true);
        } else {
            cb(new Error('Solo se permiten archivos de imagen'), false);
        }
    }
});

// Servir archivos de uploads
app.use('/uploads', express.static('uploads'));

// =========================================
// HELPER FUNCTIONS
// =========================================
function runQuery(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.run(sql, params, function(error) {
            if (error) {
                reject(error);
            } else {
                resolve({ lastID: this.lastID, changes: this.changes });
            }
        });
    });
}

function getQuery(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.get(sql, params, (error, row) => {
            if (error) {
                reject(error);
            } else {
                resolve(row);
            }
        });
    });
}

function allQuery(sql, params = []) {
    return new Promise((resolve, reject) => {
        db.all(sql, params, (error, rows) => {
            if (error) {
                reject(error);
            } else {
                resolve(rows);
            }
        });
    });
}

// Middleware de autenticación para admin
function requireAuth(req, res, next) {
    if (req.session && req.session.adminId) {
        next();
    } else {
        res.status(401).json({ error: 'No autorizado' });
    }
}

// =========================================
// RUTAS DE AUTENTICACIÓN ADMIN
// =========================================
app.post('/admin/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ error: 'Usuario y contraseña requeridos' });
        }

        const admin = await getQuery(
            'SELECT * FROM admins WHERE username = ?',
            [username]
        );

        if (!admin) {
            return res.status(401).json({ error: 'Credenciales inválidas' });
        }

        const isValidPassword = await bcrypt.compare(password, admin.password_hash);
        if (!isValidPassword) {
            return res.status(401).json({ error: 'Credenciales inválidas' });
        }

        // Actualizar último login
        await runQuery(
            'UPDATE admins SET last_login = CURRENT_TIMESTAMP WHERE id = ?',
            [admin.id]
        );

        // Crear sesión
        req.session.adminId = admin.id;
        req.session.adminUsername = admin.username;

        res.json({ 
            success: true, 
            admin: { 
                id: admin.id, 
                username: admin.username, 
                email: admin.email 
            } 
        });

    } catch (error) {
        console.error('Error en login:', error);
        res.status(500).json({ error: 'Error interno del servidor' });
    }
});

app.post('/admin/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ error: 'Error cerrando sesión' });
        }
        res.json({ success: true });
    });
});

app.get('/admin/check-auth', requireAuth, async (req, res) => {
    try {
        const admin = await getQuery(
            'SELECT id, username, email FROM admins WHERE id = ?',
            [req.session.adminId]
        );
        res.json(admin);
    } catch (error) {
        console.error('Error checking auth:', error);
        res.status(500).json({ error: 'Error verificando autenticación' });
    }
});

// =========================================
// RUTAS DEL DASHBOARD
// =========================================
app.get('/admin/dashboard-stats', requireAuth, async (req, res) => {
    try {
        const totalProducts = await getQuery('SELECT COUNT(*) as count FROM products WHERE is_active = 1');
        const totalCategories = await getQuery('SELECT COUNT(*) as count FROM categories WHERE is_active = 1');
        
        // Calcular ingresos totales (simulado)
        const products = await allQuery('SELECT price, stock_quantity FROM products WHERE is_active = 1');
        const totalRevenue = products.reduce((sum, product) => {
            return sum + (product.price * Math.floor(product.stock_quantity * 0.1)); // Simular ventas
        }, 0);

        res.json({
            totalProducts: totalProducts.count,
            totalOrders: Math.floor(Math.random() * 100) + 50, // Simulado
            totalRevenue: totalRevenue.toFixed(2),
            totalCustomers: Math.floor(Math.random() * 200) + 100 // Simulado
        });

    } catch (error) {
        console.error('Error loading dashboard stats:', error);
        res.status(500).json({ error: 'Error cargando estadísticas' });
    }
});

app.get('/admin/recent-activity', requireAuth, async (req, res) => {
    try {
        // Simulando actividad reciente
        const activities = [
            {
                type: 'product_added',
                description: 'Nuevo producto agregado al catálogo',
                created_at: new Date().toISOString()
            },
            {
                type: 'order_received',
                description: 'Nueva orden recibida',
                created_at: new Date(Date.now() - 3600000).toISOString()
            }
        ];
        
        res.json(activities);
    } catch (error) {
        console.error('Error loading recent activity:', error);
        res.status(500).json({ error: 'Error cargando actividad reciente' });
    }
});

// =========================================
// RUTAS DE PRODUCTOS ADMIN
// =========================================
app.get('/admin/products', requireAuth, async (req, res) => {
    try {
        const products = await allQuery(`
            SELECT p.*, 
                   (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) as primaryImage
            FROM products p 
            ORDER BY p.created_at DESC
        `);

        res.json(products);
    } catch (error) {
        console.error('Error loading products:', error);
        res.status(500).json({ error: 'Error cargando productos' });
    }
});

app.get('/admin/products/:id', requireAuth, async (req, res) => {
    try {
        const product = await getQuery('SELECT * FROM products WHERE id = ?', [req.params.id]);
        if (!product) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        const images = await allQuery('SELECT * FROM product_images WHERE product_id = ? ORDER BY sort_order', [req.params.id]);
        product.images = images;

        res.json(product);
    } catch (error) {
        console.error('Error loading product:', error);
        res.status(500).json({ error: 'Error cargando producto' });
    }
});

app.post('/admin/products', requireAuth, upload.array('images', 10), async (req, res) => {
    try {
        const { name, category_id, price, stock_quantity, description } = req.body;

        if (!name || !category_id || !price || !stock_quantity) {
            return res.status(400).json({ error: 'Campos requeridos: name, category_id, price, stock_quantity' });
        }

        // Insertar producto
        const result = await runQuery(`
            INSERT INTO products (name, category_id, price, stock_quantity, description)
            VALUES (?, ?, ?, ?, ?)
        `, [name, category_id, parseFloat(price), parseInt(stock_quantity), description || '']);

        const productId = result.lastID;

        // Procesar imágenes
        if (req.files && req.files.length > 0) {
            for (let i = 0; i < req.files.length; i++) {
                const file = req.files[i];
                const imageUrl = `/uploads/${file.filename}`;
                const isFirst = i === 0;

                await runQuery(`
                    INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order)
                    VALUES (?, ?, ?, ?, ?)
                `, [productId, imageUrl, `${name} ${i + 1}`, isFirst ? 1 : 0, i]);
            }
        }

        // Sincronizar con Stripe
        await syncProductWithStripe(productId);

        res.json({ success: true, productId });

    } catch (error) {
        console.error('Error creating product:', error);
        res.status(500).json({ error: 'Error creando producto' });
    }
});

app.put('/admin/products/:id', requireAuth, upload.array('images', 10), async (req, res) => {
    try {
        const productId = req.params.id;
        const { name, category_id, price, stock_quantity, description } = req.body;

        // Actualizar producto
        await runQuery(`
            UPDATE products 
            SET name = ?, category_id = ?, price = ?, stock_quantity = ?, description = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, [name, category_id, parseFloat(price), parseInt(stock_quantity), description || '', productId]);

        // Procesar nuevas imágenes
        if (req.files && req.files.length > 0) {
            // Obtener el siguiente sort_order
            const lastImage = await getQuery('SELECT MAX(sort_order) as max_order FROM product_images WHERE product_id = ?', [productId]);
            let nextOrder = (lastImage.max_order || 0) + 1;

            for (const file of req.files) {
                const imageUrl = `/uploads/${file.filename}`;
                await runQuery(`
                    INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order)
                    VALUES (?, ?, ?, ?, ?)
                `, [productId, imageUrl, `${name} ${nextOrder}`, 0, nextOrder]);
                nextOrder++;
            }
        }

        // Sincronizar con Stripe
        await syncProductWithStripe(productId);

        res.json({ success: true });

    } catch (error) {
        console.error('Error updating product:', error);
        res.status(500).json({ error: 'Error actualizando producto' });
    }
});

app.delete('/admin/products/:id', requireAuth, async (req, res) => {
    try {
        const productId = req.params.id;

        // Obtener imágenes para eliminar archivos
        const images = await allQuery('SELECT image_url FROM product_images WHERE product_id = ?', [productId]);
        
        // Eliminar archivos de imágenes
        for (const img of images) {
            const filePath = path.join(__dirname, img.image_url);
            if (fs.existsSync(filePath)) {
                fs.unlinkSync(filePath);
            }
        }

        // Eliminar producto (las imágenes se eliminan automáticamente por CASCADE)
        await runQuery('DELETE FROM products WHERE id = ?', [productId]);

        res.json({ success: true });

    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ error: 'Error eliminando producto' });
    }
});

app.delete('/admin/product-images/:id', requireAuth, async (req, res) => {
    try {
        const imageId = req.params.id;

        // Obtener info de la imagen
        const image = await getQuery('SELECT * FROM product_images WHERE id = ?', [imageId]);
        if (!image) {
            return res.status(404).json({ error: 'Imagen no encontrada' });
        }

        // Eliminar archivo
        const filePath = path.join(__dirname, image.image_url);
        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
        }

        // Eliminar de la base de datos
        await runQuery('DELETE FROM product_images WHERE id = ?', [imageId]);

        res.json({ success: true });

    } catch (error) {
        console.error('Error deleting image:', error);
        res.status(500).json({ error: 'Error eliminando imagen' });
    }
});

// =========================================
// RUTAS DE CATEGORÍAS
// =========================================
app.get('/admin/categories', async (req, res) => {
    try {
        const categories = await allQuery('SELECT * FROM categories WHERE is_active = 1 ORDER BY sort_order, name');
        res.json(categories);
    } catch (error) {
        console.error('Error loading categories:', error);
        res.status(500).json({ error: 'Error cargando categorías' });
    }
});

// =========================================
// SINCRONIZACIÓN CON STRIPE
// =========================================
async function syncProductWithStripe(productId) {
    try {
        const product = await getQuery('SELECT * FROM products WHERE id = ?', [productId]);
        if (!product) return;

        const primaryImage = await getQuery('SELECT image_url FROM product_images WHERE product_id = ? AND is_primary = 1', [productId]);
        
        // Crear o actualizar producto en Stripe
        let stripeProduct;
        if (product.stripe_price_id) {
            // Actualizar precio existente (crear uno nuevo)
            stripeProduct = await stripe.products.retrieve(product.stripe_price_id);
        } else {
            // Crear nuevo producto
            stripeProduct = await stripe.products.create({
                name: product.name,
                description: product.description,
                images: primaryImage ? [`${process.env.BASE_URL || 'http://localhost:3000'}${primaryImage.image_url}`] : [],
                metadata: {
                    product_id: productId.toString(),
                    category: product.category_id
                }
            });
        }

        // Crear precio
        const price = await stripe.prices.create({
            product: stripeProduct.id,
            unit_amount: Math.round(product.price * 100), // Convertir a centavos
            currency: 'mxn',
        });

        // Actualizar producto con el price_id de Stripe
        await runQuery('UPDATE products SET stripe_price_id = ? WHERE id = ?', [price.id, productId]);

        console.log(`✅ Producto ${product.name} sincronizado con Stripe`);

    } catch (error) {
        console.error('Error syncing with Stripe:', error);
    }
}

// =========================================
// RUTAS ORIGINALES DE STRIPE CHECKOUT
// =========================================

// Obtener productos desde la base de datos
async function getProductsFromDB() {
    const products = await allQuery(`
        SELECT p.*, 
               GROUP_CONCAT(pi.image_url ORDER BY pi.sort_order) as images
        FROM products p
        LEFT JOIN product_images pi ON p.id = pi.product_id
        WHERE p.is_active = 1
        GROUP BY p.id
        ORDER BY p.sort_order, p.name
    `);

    // Formatear productos para compatibilidad con el código existente
    const formattedProducts = {};
    products.forEach(product => {
        const id = `product-${product.id}`;
        formattedProducts[id] = {
            name: product.name,
            price: Math.round(product.price * 100), // Convertir a centavos
            currency: 'mxn',
            images: product.images ? product.images.split(',') : []
        };
    });

    return formattedProducts;
}

// Endpoint para crear sesión de Stripe Checkout (actualizado)
app.post('/create-checkout-session', async (req, res) => {
    try {
        const { items } = req.body;
        
        if (!items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'Items del carrito requeridos' });
        }

        // Obtener productos desde la base de datos
        const PRODUCTS = await getProductsFromDB();

        // Crear line items para Stripe
        const lineItems = items.map(item => {
            const product = PRODUCTS[item.id];
            if (!product) {
                throw new Error(`Producto no encontrado: ${item.id}`);
            }

            return {
                price_data: {
                    currency: product.currency,
                    product_data: {
                        name: product.name,
                        images: product.images.map(img => `${req.protocol}://${req.get('host')}${img}`)
                    },
                    unit_amount: product.price,
                },
                quantity: item.quantity,
            };
        });

        // Crear sesión de Stripe Checkout
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: lineItems,
            mode: 'payment',
            success_url: `${req.protocol}://${req.get('host')}/success.html?session_id={CHECKOUT_SESSION_ID}`,
            cancel_url: `${req.protocol}://${req.get('host')}/cancel.html`,
            locale: 'es',
            billing_address_collection: 'required',
            shipping_address_collection: {
                allowed_countries: ['MX'],
            },
            // CONFIGURACIÓN DE ENVÍO GRATIS
            shipping_options: [
                {
                    shipping_rate_data: {
                        type: 'fixed_amount',
                        fixed_amount: {
                            amount: 0, // 0 pesos = GRATIS
                            currency: 'mxn',
                        },
                        display_name: 'Envío GRATIS 🚚',
                        delivery_estimate: {
                            minimum: {
                                unit: 'business_day',
                                value: 3,
                            },
                            maximum: {
                                unit: 'business_day',
                                value: 7,
                            },
                        },
                    },
                },
            ],
            metadata: {
                store: 'Charolais',
                location: 'Monterrey, NL',
                shipping_cost: '0',
                shipping_type: 'free'
            }
        });

        res.json({ sessionId: session.id, url: session.url });
        
    } catch (error) {
        console.error('Error creando sesión de checkout:', error);
        res.status(500).json({ error: error.message });
    }
});

// Endpoint para obtener productos (para el frontend)
app.get('/api/products', async (req, res) => {
    try {
        const products = await allQuery(`
            SELECT p.*, 
                   GROUP_CONCAT(pi.image_url ORDER BY pi.sort_order) as images,
                   c.name as category_name
            FROM products p
            LEFT JOIN product_images pi ON p.id = pi.product_id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE p.is_active = 1
            GROUP BY p.id
            ORDER BY p.sort_order, p.name
        `);

        // Formatear productos para el frontend
        const formattedProducts = products.map(product => ({
            id: `product-${product.id}`,
            name: product.name,
            price: product.price,
            description: product.description,
            category: product.category_id,
            categoryName: product.category_name,
            rating: product.rating,
            reviews: product.reviews_count,
            stock: product.stock_quantity,
            images: product.images ? product.images.split(',') : [],
            isActive: product.is_active
        }));

        res.json(formattedProducts);

    } catch (error) {
        console.error('Error obteniendo productos:', error);
        res.status(500).json({ error: 'Error obteniendo productos' });
    }
});

// Resto de endpoints originales...
app.get('/checkout-session/:sessionId', async (req, res) => {
    try {
        const session = await stripe.checkout.sessions.retrieve(req.params.sessionId);
        res.json(session);
    } catch (error) {
        console.error('Error obteniendo sesión:', error);
        res.status(500).json({ error: error.message });
    }
});

app.post('/webhook', express.raw({type: 'application/json'}), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    let event;

    try {
        // Obtener webhook secret desde configuración
        const webhookSecret = await getQuery('SELECT setting_value FROM system_settings WHERE setting_key = ?', ['webhook_secret']);
        const endpointSecret = webhookSecret?.setting_value || 'whsec_charolais_2024';
        
        event = stripe.webhooks.constructEvent(req.body, sig, endpointSecret);
    } catch (err) {
        console.log(`❌ Webhook signature verification failed:`, err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    try {
        switch (event.type) {
            case 'checkout.session.completed':
                const session = event.data.object;
                console.log('💰 Pago completado para sesión:', session.id);
                
                // Procesar la orden
                await processCompletedOrder(session);
                break;
                
            case 'payment_intent.succeeded':
                const paymentIntent = event.data.object;
                console.log('✅ Payment Intent succeeded:', paymentIntent.id);
                break;
                
            case 'payment_intent.payment_failed':
                const failedPayment = event.data.object;
                console.log('❌ Payment failed:', failedPayment.id);
                await handleFailedPayment(failedPayment);
                break;
                
            default:
                console.log(`🔔 Evento no manejado: ${event.type}`);
        }
        
        res.json({received: true});
        
    } catch (error) {
        console.error('❌ Error procesando webhook:', error);
        res.status(500).json({error: 'Error procesando webhook'});
    }
});

// Función para procesar órdenes completadas
async function processCompletedOrder(session) {
    try {
        console.log('🛒 Procesando orden completada...');
        
        // Generar número de orden único
        const orderNumber = `CH-${Date.now()}-${Math.random().toString(36).substr(2, 4).toUpperCase()}`;
        
        // Extraer información del cliente
        const customerEmail = session.customer_details?.email || 'no-email@charolais.com';
        const customerName = session.customer_details?.name || 'Cliente';
        const customerPhone = session.customer_details?.phone || '';
        
        // Extraer direcciones
        const shippingAddress = session.shipping?.address || {};
        const billingAddress = session.customer_details?.address || {};
        
        // Crear la orden en la base de datos
        const orderResult = await runQuery(`
            INSERT INTO orders (
                stripe_session_id, stripe_payment_intent_id, order_number,
                customer_email, customer_name, customer_phone,
                total_amount, shipping_cost, currency,
                status, payment_status,
                shipping_address_line1, shipping_address_line2, shipping_city, 
                shipping_state, shipping_postal_code, shipping_country,
                billing_address_line1, billing_address_line2, billing_city,
                billing_state, billing_postal_code, billing_country
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            session.id,
            session.payment_intent,
            orderNumber,
            customerEmail,
            customerName,
            customerPhone,
            session.amount_total / 100, // Convertir de centavos
            session.shipping_cost?.amount_total / 100 || 0,
            session.currency.toUpperCase(),
            'paid',
            'paid',
            shippingAddress.line1 || '',
            shippingAddress.line2 || '',
            shippingAddress.city || '',
            shippingAddress.state || '',
            shippingAddress.postal_code || '',
            shippingAddress.country || 'MX',
            billingAddress.line1 || '',
            billingAddress.line2 || '',
            billingAddress.city || '',
            billingAddress.state || '',
            billingAddress.postal_code || '',
            billingAddress.country || 'MX'
        ]);
        
        const orderId = orderResult.lastID;
        
        // Obtener line items de la sesión
        const lineItems = await stripe.checkout.sessions.listLineItems(session.id, {
            expand: ['data.price.product']
        });
        
        // Procesar cada item y reducir stock
        for (const item of lineItems.data) {
            const productMetadata = item.price.product.metadata;
            const productId = productMetadata.product_id;
            const variantId = productMetadata.variant_id || null;
            
            // Insertar item de orden
            await runQuery(`
                INSERT INTO order_items (
                    order_id, product_id, variant_id, product_name, variant_name,
                    sku, price, quantity, total_price
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `, [
                orderId,
                productId,
                variantId,
                item.description,
                productMetadata.variant_name || null,
                productMetadata.sku || '',
                item.price.unit_amount / 100,
                item.quantity,
                item.amount_total / 100
            ]);
            
            // Reducir stock automáticamente
            const autoReduce = await getQuery('SELECT setting_value FROM system_settings WHERE setting_key = ?', ['auto_stock_reduction']);
            if (autoReduce?.setting_value === '1') {
                if (variantId) {
                    // Reducir stock de variante
                    await runQuery('UPDATE product_variants SET stock_quantity = stock_quantity - ? WHERE id = ?', [item.quantity, variantId]);
                } else {
                    // Reducir stock de producto
                    await runQuery('UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?', [item.quantity, productId]);
                }
            }
        }
        
        // Crear notificación para admin
        await createAdminNotification(
            'new_order',
            '🛒 Nueva Venta Recibida!',
            `Nueva orden ${orderNumber} por $${(session.amount_total / 100).toFixed(2)} MXN de ${customerName} (${customerEmail})`,
            orderId,
            null,
            'high'
        );
        
        console.log(`✅ Orden ${orderNumber} procesada exitosamente`);
        console.log(`💰 Total: $${(session.amount_total / 100).toFixed(2)} MXN`);
        console.log(`👤 Cliente: ${customerName} (${customerEmail})`);
        
    } catch (error) {
        console.error('❌ Error procesando orden:', error);
        
        // Crear notificación de error
        await createAdminNotification(
            'system',
            '⚠️ Error Procesando Orden',
            `Error al procesar orden de sesión ${session.id}: ${error.message}`,
            null,
            null,
            'urgent'
        );
    }
}

// Función para manejar pagos fallidos
async function handleFailedPayment(paymentIntent) {
    await createAdminNotification(
        'system',
        '❌ Pago Fallido',
        `Pago fallido para Payment Intent ${paymentIntent.id}. Monto: $${(paymentIntent.amount / 100).toFixed(2)} ${paymentIntent.currency.toUpperCase()}`,
        null,
        null,
        'medium'
    );
}

// Función para crear notificaciones de admin
async function createAdminNotification(type, title, message, orderId = null, productId = null, priority = 'medium') {
    try {
        await runQuery(`
            INSERT INTO admin_notifications (type, title, message, order_id, product_id, priority)
            VALUES (?, ?, ?, ?, ?, ?)
        `, [type, title, message, orderId, productId, priority]);
        
        console.log(`🔔 Notificación creada: ${title}`);
    } catch (error) {
        console.error('❌ Error creando notificación:', error);
    }
}

// =========================================
// RUTAS ADMIN PARA GESTIÓN DE PRODUCTOS
// =========================================

// Quick update routes for admin panel
app.patch('/api/admin/products/:id/price', async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const { price } = req.body;
        
        if (!price || isNaN(parseFloat(price))) {
            return res.status(400).json({ error: 'Precio válido requerido' });
        }

        await runQuery('UPDATE products SET price = ? WHERE id = ?', [parseFloat(price), productId]);
        
        res.json({ 
            success: true,
            price: parseFloat(price),
            message: `Precio actualizado a $${parseFloat(price)}`
        });
        
    } catch (error) {
        console.error('Error updating price:', error);
        res.status(500).json({ error: 'Error actualizando precio' });
    }
});

app.patch('/api/admin/products/:id/stock', async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const { stock } = req.body;
        
        if (stock === undefined || isNaN(parseInt(stock))) {
            return res.status(400).json({ error: 'Stock válido requerido' });
        }

        await runQuery('UPDATE products SET stock_quantity = ? WHERE id = ?', [parseInt(stock), productId]);
        
        res.json({ 
            success: true,
            stock: parseInt(stock),
            message: `Stock actualizado a ${parseInt(stock)} unidades`
        });
        
    } catch (error) {
        console.error('Error updating stock:', error);
        res.status(500).json({ error: 'Error actualizando stock' });
    }
});

app.post('/api/admin/products', upload.array('images', 10), async (req, res) => {
    try {
        const { name, category, price, stock, description } = req.body;
        
        if (!name || !category || !price || stock === undefined) {
            return res.status(400).json({ 
                error: 'Campos requeridos: name, category, price, stock' 
            });
        }

        // Get category ID
        let categoryId;
        const categoryMap = {
            'gorras': 1,
            'hombre': 2,
            'mujer': 3,
            'accesorios-dama': 4,
            'accesorios-caballero': 5
        };
        categoryId = categoryMap[category] || 1;

        // Insert product
        const result = await runQuery(`
            INSERT INTO products (name, category_id, price, stock_quantity, description, is_active)
            VALUES (?, ?, ?, ?, ?, 1)
        `, [name, categoryId, parseFloat(price), parseInt(stock), description || '']);

        const productId = result.lastID;

        // Process uploaded images
        const imagePaths = [];
        if (req.files && req.files.length > 0) {
            for (let i = 0; i < req.files.length; i++) {
                const file = req.files[i];
                const imageUrl = `/uploads/${file.filename}`;
                imagePaths.push(imageUrl);

                await runQuery(`
                    INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order)
                    VALUES (?, ?, ?, ?, ?)
                `, [productId, imageUrl, name, i === 0 ? 1 : 0, i]);
            }
        } else {
            // Add placeholder image
            imagePaths.push('/placeholder.jpg');
            await runQuery(`
                INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order)
                VALUES (?, ?, ?, 1, 0)
            `, [productId, '/placeholder.jpg', name]);
        }

        const newProduct = {
            id: `product-${productId}`,
            name,
            category,
            categoryName: getCategoryName(category),
            price: parseFloat(price),
            stock: parseInt(stock),
            description: description || '',
            images: imagePaths
        };
        
        res.json({ 
            success: true, 
            product: newProduct,
            message: 'Producto creado exitosamente'
        });
        
    } catch (error) {
        console.error('Error creating product:', error);
        res.status(500).json({ error: 'Error creando producto' });
    }
});

app.put('/api/admin/products/:id', upload.array('images', 10), async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const { name, category, price, stock, description } = req.body;
        
        // Check if product exists
        const existingProduct = await getQuery('SELECT * FROM products WHERE id = ?', [productId]);
        if (!existingProduct) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }

        // Get category ID
        let categoryId = existingProduct.category_id;
        if (category) {
            const categoryMap = {
                'gorras': 1,
                'hombre': 2,
                'mujer': 3,
                'accesorios-dama': 4,
                'accesorios-caballero': 5
            };
            categoryId = categoryMap[category] || categoryId;
        }

        // Update product
        await runQuery(`
            UPDATE products 
            SET name = ?, category_id = ?, price = ?, stock_quantity = ?, description = ?
            WHERE id = ?
        `, [
            name || existingProduct.name,
            categoryId,
            price ? parseFloat(price) : existingProduct.price,
            stock !== undefined ? parseInt(stock) : existingProduct.stock_quantity,
            description !== undefined ? description : existingProduct.description,
            productId
        ]);

        // Process new images if uploaded
        if (req.files && req.files.length > 0) {
            // Remove old images
            await runQuery('DELETE FROM product_images WHERE product_id = ?', [productId]);
            
            // Add new images
            for (let i = 0; i < req.files.length; i++) {
                const file = req.files[i];
                const imageUrl = `/uploads/${file.filename}`;

                await runQuery(`
                    INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order)
                    VALUES (?, ?, ?, ?, ?)
                `, [productId, imageUrl, name || existingProduct.name, i === 0 ? 1 : 0, i]);
            }
        }

        // Get updated product with images
        const updatedProduct = await getQuery('SELECT * FROM products WHERE id = ?', [productId]);
        const images = await allQuery('SELECT image_url FROM product_images WHERE product_id = ? ORDER BY sort_order', [productId]);
        
        const response = {
            id: `product-${productId}`,
            name: updatedProduct.name,
            category: category || getCategoryKeyById(updatedProduct.category_id),
            categoryName: getCategoryName(category || getCategoryKeyById(updatedProduct.category_id)),
            price: updatedProduct.price,
            stock: updatedProduct.stock_quantity,
            description: updatedProduct.description,
            images: images.map(img => img.image_url)
        };
        
        res.json({ 
            success: true, 
            product: response,
            message: 'Producto actualizado exitosamente'
        });
        
    } catch (error) {
        console.error('Error updating product:', error);
        res.status(500).json({ error: 'Error actualizando producto' });
    }
});

app.delete('/api/admin/products/:id', async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        
        // Check if product exists
        const existingProduct = await getQuery('SELECT * FROM products WHERE id = ?', [productId]);
        if (!existingProduct) {
            return res.status(404).json({ error: 'Producto no encontrado' });
        }
        
        // Delete product images first
        await runQuery('DELETE FROM product_images WHERE product_id = ?', [productId]);
        
        // Delete product
        await runQuery('DELETE FROM products WHERE id = ?', [productId]);
        
        res.json({ 
            success: true,
            message: 'Producto eliminado exitosamente'
        });
        
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ error: 'Error eliminando producto' });
    }
});

// Helper functions for admin routes
function getCategoryName(category) {
    const categoryNames = {
        'gorras': 'Gorras',
        'hombre': 'Hombre',
        'mujer': 'Mujer',
        'accesorios-dama': 'Accesorios Dama',
        'accesorios-caballero': 'Accesorios Caballero'
    };
    return categoryNames[category] || category;
}

function getCategoryKeyById(categoryId) {
    const categoryKeys = {
        1: 'gorras',
        2: 'hombre',
        3: 'mujer',
        4: 'accesorios-dama',
        5: 'accesorios-caballero'
    };
    return categoryKeys[categoryId] || 'gorras';
}

// =========================================
// RUTAS ESTÁTICAS
// =========================================
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.get('/admin', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

app.get('/admin/', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin.html'));
});

app.get('/admin-final', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin-final.html'));
});

app.get('/admin-final/', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin-final.html'));
});

app.get('/admin-variants', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin-variants.html'));
});

app.get('/admin-variants/', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin-variants.html'));
});

app.get('/admin-orders', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin-orders.html'));
});

app.get('/admin-orders/', (req, res) => {
    res.sendFile(path.join(__dirname, 'admin-orders.html'));
});

// =========================================
// INICIAR SERVIDOR
// =========================================
app.listen(PORT, '0.0.0.0', () => {
    // Obtener la IP local para mostrar en el mensaje
    const os = require('os');
    const networkInterfaces = os.networkInterfaces();
    let localIP = 'localhost';
    
    // Buscar la IP local (no loopback)
    for (const interfaceName in networkInterfaces) {
        const addresses = networkInterfaces[interfaceName];
        for (const address of addresses) {
            if (address.family === 'IPv4' && !address.internal) {
                localIP = address.address;
                break;
            }
        }
        if (localIP !== 'localhost') break;
    }
    
    console.log(`🤠 Servidor Charolais corriendo en:`);
    console.log(`   • Local: http://localhost:${PORT}`);
    console.log(`   • Red Local: http://${localIP}:${PORT}`);
    console.log(`🛒 Stripe Checkout configurado y listo para procesar pagos`);
    console.log(`🔧 Panel de Admin Local: http://localhost:${PORT}/admin-variants`);
    console.log(`🌐 Panel de Admin Red: http://${localIP}:${PORT}/admin-variants`);
    console.log(`📍 Tienda ubicada en Monterrey, Nuevo León`);
    console.log(`📊 Base de datos SQLite inicializada`);
    console.log(`\n🚀 PARA ADMINISTRADORES REMOTOS:`);
    console.log(`   Comparte esta URL: http://${localIP}:${PORT}/admin-variants`);
});

// =========================================
// RUTAS PARA GESTIÓN DE VARIANTES
// =========================================

// Obtener colores disponibles
app.get('/api/colors', async (req, res) => {
    try {
        const colors = await allQuery(`
            SELECT * FROM color_options 
            WHERE is_active = 1 
            ORDER BY display_order, name
        `);
        res.json(colors);
    } catch (error) {
        console.error('Error loading colors:', error);
        res.status(500).json({ error: 'Error cargando colores' });
    }
});

// Obtener variantes de un producto
app.get('/api/products/:id/variants', async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        
        const variants = await allQuery(`
            SELECT pv.*, 
                   GROUP_CONCAT(va.attribute_type || ':' || va.attribute_value || ':' || va.hex_color, '|') as attributes,
                   GROUP_CONCAT(vi.image_url, ',') as variant_images
            FROM product_variants pv
            LEFT JOIN variant_attributes va ON pv.id = va.variant_id
            LEFT JOIN variant_images vi ON pv.id = vi.variant_id
            WHERE pv.product_id = ? AND pv.is_active = 1
            GROUP BY pv.id
            ORDER BY pv.sort_order, pv.variant_name
        `, [productId]);

        // Formatear variantes
        const formattedVariants = variants.map(variant => {
            const attributes = {};
            if (variant.attributes) {
                variant.attributes.split('|').forEach(attr => {
                    const [type, value, hex] = attr.split(':');
                    if (type && value) {
                        attributes[type] = { value, hex_color: hex || null };
                    }
                });
            }

            return {
                id: variant.id,
                variant_name: variant.variant_name,
                sku: variant.sku,
                price_override: variant.price_override,
                stock_quantity: variant.stock_quantity,
                attributes,
                images: variant.variant_images ? variant.variant_images.split(',').filter(img => img) : []
            };
        });

        res.json(formattedVariants);
    } catch (error) {
        console.error('Error loading variants:', error);
        res.status(500).json({ error: 'Error cargando variantes' });
    }
});

// Crear nueva variante
app.post('/api/admin/products/:id/variants', upload.array('variant_images', 5), async (req, res) => {
    try {
        const productId = parseInt(req.params.id);
        const { variant_name, sku, price_override, stock_quantity, color_id, color_name, color_hex } = req.body;

        if (!variant_name || stock_quantity === undefined) {
            return res.status(400).json({ 
                error: 'Campos requeridos: variant_name, stock_quantity' 
            });
        }

        // Crear variante
        const variantResult = await runQuery(`
            INSERT INTO product_variants (product_id, variant_name, sku, price_override, stock_quantity)
            VALUES (?, ?, ?, ?, ?)
        `, [productId, variant_name, sku || null, price_override || null, parseInt(stock_quantity)]);

        const variantId = variantResult.lastID;

        // Agregar atributo de color
        if (color_id || (color_name && color_hex)) {
            let colorValue = color_name;
            let hexColor = color_hex;

            // Si se proporcionó color_id, obtener los datos del color
            if (color_id) {
                const color = await getQuery('SELECT name, hex_code FROM color_options WHERE id = ?', [color_id]);
                if (color) {
                    colorValue = color.name;
                    hexColor = color.hex_code;
                }
            }

            await runQuery(`
                INSERT INTO variant_attributes (variant_id, attribute_type, attribute_value, attribute_display_name, hex_color)
                VALUES (?, ?, ?, ?, ?)
            `, [variantId, 'color', colorValue, colorValue, hexColor]);
        }

        // Procesar imágenes de la variante
        if (req.files && req.files.length > 0) {
            for (let i = 0; i < req.files.length; i++) {
                const file = req.files[i];
                const imageUrl = `/uploads/${file.filename}`;

                await runQuery(`
                    INSERT INTO variant_images (variant_id, image_url, alt_text, is_primary, sort_order)
                    VALUES (?, ?, ?, ?, ?)
                `, [variantId, imageUrl, `${variant_name} ${i + 1}`, i === 0 ? 1 : 0, i]);
            }
        }

        res.json({
            success: true,
            variant_id: variantId,
            message: 'Variante creada exitosamente'
        });

    } catch (error) {
        console.error('Error creating variant:', error);
        res.status(500).json({ error: 'Error creando variante' });
    }
});

// Actualizar variante
app.put('/api/admin/variants/:id', upload.array('variant_images', 5), async (req, res) => {
    try {
        const variantId = parseInt(req.params.id);
        const { variant_name, sku, price_override, stock_quantity, color_id, color_name, color_hex } = req.body;

        // Verificar que la variante existe
        const existingVariant = await getQuery('SELECT * FROM product_variants WHERE id = ?', [variantId]);
        if (!existingVariant) {
            return res.status(404).json({ error: 'Variante no encontrada' });
        }

        // Actualizar variante
        await runQuery(`
            UPDATE product_variants 
            SET variant_name = ?, sku = ?, price_override = ?, stock_quantity = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, [
            variant_name || existingVariant.variant_name,
            sku || existingVariant.sku,
            price_override !== undefined ? price_override : existingVariant.price_override,
            stock_quantity !== undefined ? parseInt(stock_quantity) : existingVariant.stock_quantity,
            variantId
        ]);

        // Actualizar atributo de color si se proporciona
        if (color_id || (color_name && color_hex)) {
            let colorValue = color_name;
            let hexColor = color_hex;

            if (color_id) {
                const color = await getQuery('SELECT name, hex_code FROM color_options WHERE id = ?', [color_id]);
                if (color) {
                    colorValue = color.name;
                    hexColor = color.hex_code;
                }
            }

            // Eliminar atributo de color existente
            await runQuery('DELETE FROM variant_attributes WHERE variant_id = ? AND attribute_type = ?', [variantId, 'color']);
            
            // Insertar nuevo atributo de color
            await runQuery(`
                INSERT INTO variant_attributes (variant_id, attribute_type, attribute_value, attribute_display_name, hex_color)
                VALUES (?, ?, ?, ?, ?)
            `, [variantId, 'color', colorValue, colorValue, hexColor]);
        }

        // Procesar nuevas imágenes si se subieron
        if (req.files && req.files.length > 0) {
            // Eliminar imágenes existentes
            await runQuery('DELETE FROM variant_images WHERE variant_id = ?', [variantId]);
            
            // Agregar nuevas imágenes
            for (let i = 0; i < req.files.length; i++) {
                const file = req.files[i];
                const imageUrl = `/uploads/${file.filename}`;

                await runQuery(`
                    INSERT INTO variant_images (variant_id, image_url, alt_text, is_primary, sort_order)
                    VALUES (?, ?, ?, ?, ?)
                `, [variantId, imageUrl, `${variant_name} ${i + 1}`, i === 0 ? 1 : 0, i]);
            }
        }

        res.json({
            success: true,
            message: 'Variante actualizada exitosamente'
        });

    } catch (error) {
        console.error('Error updating variant:', error);
        res.status(500).json({ error: 'Error actualizando variante' });
    }
});

// Eliminar variante
app.delete('/api/admin/variants/:id', async (req, res) => {
    try {
        const variantId = parseInt(req.params.id);

        // Verificar que la variante existe
        const existingVariant = await getQuery('SELECT * FROM product_variants WHERE id = ?', [variantId]);
        if (!existingVariant) {
            return res.status(404).json({ error: 'Variante no encontrada' });
        }

        // Eliminar variante (las tablas relacionadas se eliminan automáticamente por CASCADE)
        await runQuery('DELETE FROM product_variants WHERE id = ?', [variantId]);

        res.json({
            success: true,
            message: 'Variante eliminada exitosamente'
        });

    } catch (error) {
        console.error('Error deleting variant:', error);
        res.status(500).json({ error: 'Error eliminando variante' });
    }
});

// Actualización rápida de stock de variante
app.patch('/api/admin/variants/:id/stock', async (req, res) => {
    try {
        const variantId = parseInt(req.params.id);
        const { stock } = req.body;

        if (stock === undefined || isNaN(parseInt(stock))) {
            return res.status(400).json({ error: 'Stock válido requerido' });
        }

        await runQuery('UPDATE product_variants SET stock_quantity = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?', 
                      [parseInt(stock), variantId]);

        res.json({
            success: true,
            stock: parseInt(stock),
            message: `Stock de variante actualizado a ${parseInt(stock)} unidades`
        });

    } catch (error) {
        console.error('Error updating variant stock:', error);
        res.status(500).json({ error: 'Error actualizando stock de variante' });
    }
});

// Helper function to calculate total product stock from variants
async function updateProductStockFromVariants(productId) {
    try {
        const variantStocks = await allQuery(
            'SELECT SUM(stock_quantity) as total_stock FROM product_variants WHERE product_id = ? AND is_active = 1',
            [productId]
        );
        
        const totalStock = variantStocks[0]?.total_stock || 0;
        
        await runQuery('UPDATE products SET stock_quantity = ? WHERE id = ?', [totalStock, productId]);
        
        return totalStock;
    } catch (error) {
        console.error('Error updating product stock from variants:', error);
        return 0;
    }
}

// =========================================
// RUTAS PARA GESTIÓN DE ÓRDENES
// =========================================

// Obtener todas las órdenes (para admin)
app.get('/api/admin/orders', requireAuth, async (req, res) => {
    try {
        const { page = 1, limit = 20, status = 'all' } = req.query;
        const offset = (page - 1) * limit;
        
        let whereClause = '';
        let params = [];
        
        if (status !== 'all') {
            whereClause = 'WHERE o.status = ?';
            params.push(status);
        }
        
        const orders = await allQuery(`
            SELECT o.*, 
                   COUNT(oi.id) as item_count,
                   GROUP_CONCAT(oi.product_name, ', ') as products
            FROM orders o
            LEFT JOIN order_items oi ON o.id = oi.order_id
            ${whereClause}
            GROUP BY o.id
            ORDER BY o.created_at DESC
            LIMIT ? OFFSET ?
        `, [...params, parseInt(limit), offset]);
        
        // Obtener total de órdenes
        const totalResult = await getQuery(`
            SELECT COUNT(*) as total FROM orders o ${whereClause}
        `, params);
        
        res.json({
            orders,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total: totalResult.total,
                pages: Math.ceil(totalResult.total / limit)
            }
        });
        
    } catch (error) {
        console.error('Error loading orders:', error);
        res.status(500).json({ error: 'Error cargando órdenes' });
    }
});

// Obtener detalles de una orden específica
app.get('/api/admin/orders/:id', requireAuth, async (req, res) => {
    try {
        const orderId = parseInt(req.params.id);
        
        const order = await getQuery('SELECT * FROM orders WHERE id = ?', [orderId]);
        if (!order) {
            return res.status(404).json({ error: 'Orden no encontrada' });
        }
        
        const items = await allQuery(`
            SELECT oi.*, p.name as current_product_name, pv.variant_name as current_variant_name
            FROM order_items oi
            LEFT JOIN products p ON oi.product_id = p.id
            LEFT JOIN product_variants pv ON oi.variant_id = pv.id
            WHERE oi.order_id = ?
            ORDER BY oi.id
        `, [orderId]);
        
        order.items = items;
        res.json(order);
        
    } catch (error) {
        console.error('Error loading order details:', error);
        res.status(500).json({ error: 'Error cargando detalles de orden' });
    }
});

// Actualizar estado de orden
app.patch('/api/admin/orders/:id/status', requireAuth, async (req, res) => {
    try {
        const orderId = parseInt(req.params.id);
        const { status, notes } = req.body;
        
        const validStatuses = ['pending', 'paid', 'processing', 'shipped', 'delivered', 'cancelled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ error: 'Estado inválido' });
        }
        
        await runQuery(`
            UPDATE orders 
            SET status = ?, notes = ?, updated_at = CURRENT_TIMESTAMP 
            WHERE id = ?
        `, [status, notes || '', orderId]);
        
        // Crear notificación de cambio de estado
        const order = await getQuery('SELECT order_number, customer_name FROM orders WHERE id = ?', [orderId]);
        await createAdminNotification(
            'system',
            '📦 Estado de Orden Actualizado',
            `Orden ${order.order_number} de ${order.customer_name} cambió a: ${status}`,
            orderId,
            null,
            'low'
        );
        
        res.json({ 
            success: true, 
            message: `Estado actualizado a: ${status}` 
        });
        
    } catch (error) {
        console.error('Error updating order status:', error);
        res.status(500).json({ error: 'Error actualizando estado de orden' });
    }
});

// =========================================
// RUTAS PARA NOTIFICACIONES DE ADMIN
// =========================================

// Obtener notificaciones no leídas
app.get('/api/admin/notifications', requireAuth, async (req, res) => {
    try {
        const { unread_only = 'false', limit = 50 } = req.query;
        
        let whereClause = '';
        if (unread_only === 'true') {
            whereClause = 'WHERE is_read = 0';
        }
        
        const notifications = await allQuery(`
            SELECT * FROM admin_notifications 
            ${whereClause}
            ORDER BY created_at DESC 
            LIMIT ?
        `, [parseInt(limit)]);
        
        // Contar notificaciones no leídas
        const unreadCount = await getQuery('SELECT COUNT(*) as count FROM admin_notifications WHERE is_read = 0');
        
        res.json({
            notifications,
            unread_count: unreadCount.count
        });
        
    } catch (error) {
        console.error('Error loading notifications:', error);
        res.status(500).json({ error: 'Error cargando notificaciones' });
    }
});

// Marcar notificación como leída
app.patch('/api/admin/notifications/:id/read', requireAuth, async (req, res) => {
    try {
        const notificationId = parseInt(req.params.id);
        
        await runQuery('UPDATE admin_notifications SET is_read = 1 WHERE id = ?', [notificationId]);
        
        res.json({ success: true });
        
    } catch (error) {
        console.error('Error marking notification as read:', error);
        res.status(500).json({ error: 'Error marcando notificación como leída' });
    }
});

// Marcar todas las notificaciones como leídas
app.patch('/api/admin/notifications/mark-all-read', requireAuth, async (req, res) => {
    try {
        await runQuery('UPDATE admin_notifications SET is_read = 1 WHERE is_read = 0');
        
        res.json({ success: true, message: 'Todas las notificaciones marcadas como leídas' });
        
    } catch (error) {
        console.error('Error marking all notifications as read:', error);
        res.status(500).json({ error: 'Error marcando todas las notificaciones como leídas' });
    }
});

// =========================================
// RUTAS PARA ESTADÍSTICAS DE VENTAS
// =========================================

// Dashboard de ventas
app.get('/api/admin/sales-stats', requireAuth, async (req, res) => {
    try {
        const { period = 'month' } = req.query;
        
        // Calcular fechas según el período
        let dateFilter = '';
        const now = new Date();
        
        switch (period) {
            case 'today':
                dateFilter = `AND DATE(created_at) = DATE('now')`;
                break;
            case 'week':
                dateFilter = `AND created_at >= datetime('now', '-7 days')`;
                break;
            case 'month':
                dateFilter = `AND created_at >= datetime('now', '-30 days')`;
                break;
            case 'year':
                dateFilter = `AND created_at >= datetime('now', '-365 days')`;
                break;
        }
        
        // Estadísticas generales
        const totalSales = await getQuery(`
            SELECT 
                COUNT(*) as total_orders,
                COALESCE(SUM(total_amount), 0) as total_revenue,
                COALESCE(AVG(total_amount), 0) as avg_order_value
            FROM orders 
            WHERE payment_status = 'paid' ${dateFilter}
        `);
        
        // Ventas por día (últimos 7 días)
        const dailySales = await allQuery(`
            SELECT 
                DATE(created_at) as date,
                COUNT(*) as orders,
                COALESCE(SUM(total_amount), 0) as revenue
            FROM orders 
            WHERE payment_status = 'paid' 
            AND created_at >= datetime('now', '-7 days')
            GROUP BY DATE(created_at)
            ORDER BY date DESC
        `);
        
        // Productos más vendidos
        const topProducts = await allQuery(`
            SELECT 
                oi.product_name,
                SUM(oi.quantity) as total_sold,
                SUM(oi.total_price) as total_revenue
            FROM order_items oi
            JOIN orders o ON oi.order_id = o.id
            WHERE o.payment_status = 'paid' ${dateFilter}
            GROUP BY oi.product_name
            ORDER BY total_sold DESC
            LIMIT 10
        `);
        
        // Estados de órdenes
        const orderStatuses = await allQuery(`
            SELECT 
                status,
                COUNT(*) as count
            FROM orders 
            WHERE 1=1 ${dateFilter}
            GROUP BY status
        `);
        
        res.json({
            period,
            total_sales: totalSales,
            daily_sales: dailySales,
            top_products: topProducts,
            order_statuses: orderStatuses
        });
        
    } catch (error) {
        console.error('Error loading sales stats:', error);
        res.status(500).json({ error: 'Error cargando estadísticas de ventas' });
    }
}); 