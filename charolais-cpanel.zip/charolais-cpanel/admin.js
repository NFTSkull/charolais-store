// =========================================
// CHAROLAIS ADMIN PANEL - JAVASCRIPT
// =========================================

class CharolaisAdmin {
    constructor() {
        this.currentPage = 'dashboard';
        this.selectedImages = [];
        this.editingProductId = null;
        this.categories = [];
        
        console.log('🎯 CharolaisAdmin: Initializing...');
        this.init();
    }

    init() {
        console.log('🎯 CharolaisAdmin: Setting up...');
        this.setupEventListeners();
        this.loadDashboard();
        this.loadCategories();
        // Commented out authentication check for demo
        // this.checkAuthentication();
        
        // Set default admin username for demo
        const usernameEl = document.getElementById('admin-username');
        if (usernameEl) {
            usernameEl.textContent = 'Admin Demo';
        }
        console.log('✅ CharolaisAdmin: Initialized successfully');
    }

    // =========================================
    // AUTHENTICATION - TEMPORARILY DISABLED FOR DEMO
    // =========================================
    async checkAuthentication() {
        try {
            const response = await fetch('/admin/check-auth');
            if (!response.ok) {
                // For demo purposes, continue without authentication
                console.log('Running in demo mode without authentication');
                return;
            }
            const user = await response.json();
            const usernameEl = document.getElementById('admin-username');
            if (usernameEl) {
                usernameEl.textContent = user.username;
            }
        } catch (error) {
            console.error('Error checking authentication:', error);
            // For demo purposes, continue without authentication
            console.log('Running in demo mode without authentication');
        }
    }

    async logout() {
        try {
            await fetch('/admin/logout', { method: 'POST' });
            window.location.href = '/admin/login.html';
        } catch (error) {
            console.error('Error logging out:', error);
        }
    }

    // =========================================
    // EVENT LISTENERS
    // =========================================
    setupEventListeners() {
        console.log('🎯 CharolaisAdmin: Setting up event listeners...');
        
        // Menu navigation
        document.querySelectorAll('.menu-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = link.dataset.page;
                console.log(`🎯 Navigating to page: ${page}`);
                if (page) {
                    this.showPage(page);
                }
            });
        });

        // Image upload
        const imageUpload = document.getElementById('image-upload');
        const imageInput = document.getElementById('image-input');

        if (imageUpload && imageInput) {
            imageUpload.addEventListener('click', () => {
                imageInput.click();
            });

            imageInput.addEventListener('change', (e) => {
                this.handleImageSelection(e.target.files);
            });

            // Drag and drop for images
            imageUpload.addEventListener('dragover', (e) => {
                e.preventDefault();
                imageUpload.classList.add('dragover');
            });

            imageUpload.addEventListener('dragleave', () => {
                imageUpload.classList.remove('dragover');
            });

            imageUpload.addEventListener('drop', (e) => {
                e.preventDefault();
                imageUpload.classList.remove('dragover');
                this.handleImageSelection(e.dataTransfer.files);
            });
        }

        // Product form
        const productForm = document.getElementById('product-form');
        if (productForm) {
            productForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveProduct();
            });
        }
        
        console.log('✅ CharolaisAdmin: Event listeners set up');
    }

    // =========================================
    // PAGE NAVIGATION
    // =========================================
    showPage(page) {
        console.log(`🎯 CharolaisAdmin: Showing page ${page}`);
        
        // Hide all pages
        document.querySelectorAll('.page').forEach(p => {
            p.classList.add('hidden');
        });

        // Show selected page
        const targetPage = document.getElementById(`${page}-page`);
        if (targetPage) {
            targetPage.classList.remove('hidden');
            console.log(`✅ Page ${page} shown`);
        } else {
            console.error(`❌ Page element not found: ${page}-page`);
        }

        // Update menu
        document.querySelectorAll('.menu-link').forEach(link => {
            link.classList.remove('active');
        });
        const activeLink = document.querySelector(`[data-page="${page}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }

        this.currentPage = page;

        // Load page data
        switch(page) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'products':
                console.log('🎯 Loading products page...');
                this.loadProducts();
                break;
            case 'categories':
                this.loadCategories();
                break;
            case 'orders':
                this.loadOrders();
                break;
            case 'settings':
                this.loadSettings();
                break;
        }
    }

    // =========================================
    // DASHBOARD
    // =========================================
    async loadDashboard() {
        console.log('🎯 CharolaisAdmin: Loading dashboard...');
        try {
            // Load basic stats from API products endpoint
            const response = await fetch('/api/products');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const products = await response.json();
            
            const totalProducts = products.length;
            const availableProducts = products.filter(p => p.stock > 0).length;
            
            const totalProductsEl = document.getElementById('total-products');
            const totalOrdersEl = document.getElementById('total-orders');
            const totalRevenueEl = document.getElementById('total-revenue');
            const totalCustomersEl = document.getElementById('total-customers');
            
            if (totalProductsEl) totalProductsEl.textContent = totalProducts;
            if (totalOrdersEl) totalOrdersEl.textContent = '0'; // Placeholder
            if (totalRevenueEl) totalRevenueEl.textContent = '$0'; // Placeholder
            if (totalCustomersEl) totalCustomersEl.textContent = '0'; // Placeholder

            console.log(`✅ Dashboard loaded: ${totalProducts} products`);
            
            // Load recent activity
            this.loadRecentActivity();

        } catch (error) {
            console.error('❌ Error loading dashboard:', error);
            // Set default values
            const totalProductsEl = document.getElementById('total-products');
            const totalOrdersEl = document.getElementById('total-orders');
            const totalRevenueEl = document.getElementById('total-revenue');
            const totalCustomersEl = document.getElementById('total-customers');
            
            if (totalProductsEl) totalProductsEl.textContent = '25';
            if (totalOrdersEl) totalOrdersEl.textContent = '0';
            if (totalRevenueEl) totalRevenueEl.textContent = '$0';
            if (totalCustomersEl) totalCustomersEl.textContent = '0';
        }
    }

    async loadRecentActivity() {
        try {
            // For demo, show static activity
            const activities = [
                {
                    type: 'product_added',
                    description: 'Producto "Wild Stampede" agregado',
                    created_at: new Date().toISOString()
                },
                {
                    type: 'product_added',
                    description: 'Producto "Rodeo Ink" agregado',
                    created_at: new Date().toISOString()
                },
                {
                    type: 'product_updated',
                    description: 'Precios de accesorios actualizados',
                    created_at: new Date().toISOString()
                }
            ];

            const activityContainer = document.getElementById('recent-activity');
            if (!activityContainer) {
                console.error('❌ Recent activity container not found');
                return;
            }
            
            if (activities.length === 0) {
                activityContainer.innerHTML = '<p style="color: var(--gray-600); text-align: center;">No hay actividad reciente</p>';
                return;
            }

            activityContainer.innerHTML = activities.map(activity => `
                <div style="padding: 1rem; border-bottom: 1px solid var(--gray-200); display: flex; align-items: center; gap: 1rem;">
                    <div style="width: 40px; height: 40px; background: var(--primary-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">
                        <i class="fas fa-${this.getActivityIcon(activity.type)}"></i>
                    </div>
                    <div style="flex: 1;">
                        <p style="margin: 0; font-weight: 600;">${activity.description}</p>
                        <small style="color: var(--gray-600);">${this.formatDate(activity.created_at)}</small>
                    </div>
                </div>
            `).join('');

            console.log('✅ Recent activity loaded');

        } catch (error) {
            console.error('❌ Error loading recent activity:', error);
        }
    }

    getActivityIcon(type) {
        const icons = {
            'product_added': 'plus',
            'product_updated': 'edit',
            'product_deleted': 'trash',
            'order_received': 'shopping-cart',
            'settings_updated': 'cog'
        };
        return icons[type] || 'info';
    }

    // =========================================
    // PRODUCTS MANAGEMENT - UPDATED TO USE PUBLIC API
    // =========================================
    async loadProducts() {
        console.log('🎯 CharolaisAdmin: Loading products...');
        try {
            // Use the public products API instead of protected admin API
            const response = await fetch('/api/products');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const products = await response.json();

            console.log(`📦 Fetched ${products.length} products:`, products.slice(0, 3));

            const tbody = document.getElementById('products-table-body');
            if (!tbody) {
                console.error('❌ Products table body not found');
                return;
            }

            tbody.innerHTML = products.map(product => {
                // Extract numeric ID from "product-X" format
                const numericId = product.id.replace('product-', '');
                const mainImage = product.images && product.images.length > 0 ? product.images[0] : '/placeholder.jpg';
                const stockStatus = product.stock > 0 ? 'En Stock' : 'Agotado';
                const stockClass = product.stock > 0 ? 'badge-success' : 'badge-danger';
                
                return `
                    <tr>
                        <td>${numericId}</td>
                        <td>
                            <img src="${mainImage}" 
                                 alt="${product.name}" 
                                 style="width: 50px; height: 50px; object-fit: cover; border-radius: 5px;">
                        </td>
                        <td><strong>${product.name}</strong></td>
                        <td>${product.categoryName || product.category}</td>
                        <td>$${product.price}</td>
                        <td>${product.stock}</td>
                        <td>
                            <span class="badge ${stockClass}">
                                ${stockStatus}
                            </span>
                        </td>
                        <td>
                            <button class="btn btn-primary btn-sm" onclick="window.admin.editProduct(${numericId})" style="margin-right: 0.5rem;">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger btn-sm" onclick="window.admin.deleteProduct(${numericId})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');

            console.log(`✅ Loaded ${products.length} products in admin panel`);

        } catch (error) {
            console.error('❌ Error loading products:', error);
            const tbody = document.getElementById('products-table-body');
            if (tbody) {
                tbody.innerHTML = '<tr><td colspan="8" style="text-align: center; color: var(--gray-600);">Error cargando productos</td></tr>';
            }
        }
    }

    async loadCategories() {
        console.log('🎯 CharolaisAdmin: Loading categories...');
        try {
            // For demo, use static categories based on our database
            this.categories = [
                { id: 'gorras', name: 'Gorras' },
                { id: 'hombre', name: 'Hombre' },
                { id: 'mujer', name: 'Mujer' },
                { id: 'accesorios-dama', name: 'Accesorios Dama' },
                { id: 'accesorios-caballero', name: 'Accesorios Caballero' }
            ];

            // Update category dropdown in product form
            const categorySelect = document.getElementById('product-category');
            if (categorySelect) {
                categorySelect.innerHTML = this.categories.map(cat => 
                    `<option value="${cat.id}">${cat.name}</option>`
                ).join('');
            }

            console.log('✅ Categories loaded');

        } catch (error) {
            console.error('❌ Error loading categories:', error);
        }
    }

    getCategoryName(categoryId) {
        const category = this.categories.find(cat => cat.id === categoryId);
        return category ? category.name : categoryId;
    }

    // =========================================
    // PRODUCT FORM
    // =========================================
    showAddProductForm() {
        this.editingProductId = null;
        this.selectedImages = [];
        
        const modalTitle = document.getElementById('product-modal-title');
        if (modalTitle) {
            modalTitle.textContent = 'Agregar Producto';
        }
        
        const form = document.getElementById('product-form');
        if (form) {
            form.reset();
        }
        
        const preview = document.getElementById('image-preview');
        if (preview) {
            preview.innerHTML = '';
        }
        
        const modal = document.getElementById('product-modal');
        if (modal) {
            modal.classList.remove('hidden');
        }
    }

    hideProductForm() {
        const modal = document.getElementById('product-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
        this.selectedImages = [];
        this.editingProductId = null;
    }

    async editProduct(productId) {
        alert(`Función de edición disponible - Producto ID: ${productId}`);
        // For demo purposes, show alert instead of actual editing
    }

    async deleteProduct(productId) {
        if (!confirm('¿Estás seguro de que quieres eliminar este producto?')) {
            return;
        }
        
        alert(`Función de eliminación disponible - Producto ID: ${productId}`);
        // For demo purposes, show alert instead of actual deletion
    }

    // =========================================
    // IMAGE HANDLING
    // =========================================
    handleImageSelection(files) {
        Array.from(files).forEach(file => {
            if (file.type.startsWith('image/')) {
                this.selectedImages.push(file);
                this.displayImagePreview(file);
            }
        });
    }

    displayImagePreview(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const preview = document.getElementById('image-preview');
            if (preview) {
                const imageItem = document.createElement('div');
                imageItem.className = 'image-item';
                imageItem.innerHTML = `
                    <img src="${e.target.result}" alt="Preview">
                    <button type="button" class="remove-btn" onclick="window.admin.removeSelectedImage('${file.name}')">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                preview.appendChild(imageItem);
            }
        };
        reader.readAsDataURL(file);
    }

    removeSelectedImage(fileName) {
        this.selectedImages = this.selectedImages.filter(file => file.name !== fileName);
        // Regenerate preview
        const preview = document.getElementById('image-preview');
        if (preview) {
            preview.innerHTML = '';
            this.selectedImages.forEach(file => {
                this.displayImagePreview(file);
            });
        }
    }

    async saveProduct() {
        alert('Función de guardado disponible - Los cambios se aplicarían aquí');
        // For demo purposes, show alert instead of actual saving
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('es-MX', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    async loadOrders() {
        const ordersContainer = document.querySelector('#orders-page .card-body');
        if (ordersContainer) {
            ordersContainer.innerHTML = '<p style="text-align: center; color: var(--gray-600);">Gestión de pedidos disponible cuando esté conectado a Stripe en producción</p>';
        }
    }

    async loadSettings() {
        const settingsContainer = document.querySelector('#settings-page .card-body');
        if (settingsContainer) {
            settingsContainer.innerHTML = '<p style="text-align: center; color: var(--gray-600);">Configuraciones de la tienda disponibles</p>';
        }
    }
}

// Global functions for onclick handlers
function logout() {
    if (window.admin) {
        window.admin.logout();
    }
}

function showAddProductForm() {
    if (window.admin) {
        window.admin.showAddProductForm();
    }
}

function hideProductForm() {
    if (window.admin) {
        window.admin.hideProductForm();
    }
}

// Initialize admin when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 DOM loaded, initializing admin...');
    window.admin = new CharolaisAdmin();
    console.log('✅ Admin panel ready!');
}); 