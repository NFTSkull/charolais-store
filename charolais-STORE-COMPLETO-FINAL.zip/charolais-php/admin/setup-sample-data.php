<?php
/**
 * Script para agregar datos de ejemplo
 * Productos y categorías basados en las imágenes disponibles
 */

require_once '../includes/config.php';
require_once '../includes/database.php';

// Verificar que no haya productos existentes
$existingProducts = $db->select("SELECT COUNT(*) as count FROM products")[0]['count'] ?? 0;
if ($existingProducts > 0) {
    die("Ya existen productos en la base de datos. Este script solo debe ejecutarse una vez.");
}

try {
    // Crear categorías
    $categories = [
        ['name' => 'Sombreros', 'description' => 'Sombreros cowboy de alta calidad'],
        ['name' => 'Gorras', 'description' => 'Gorras estilo western'],
        ['name' => 'Conjuntos', 'description' => 'Conjuntos completos cowboy'],
        ['name' => 'Boutique', 'description' => 'Ropa boutique western'],
        ['name' => 'Accesorios', 'description' => 'Accesorios y complementos']
    ];
    
    $categoryIds = [];
    foreach ($categories as $category) {
        $db->insert("INSERT INTO categories (name, description, is_active, sort_order) VALUES (?, ?, 1, 0)", 
                   [$category['name'], $category['description']]);
        $categoryIds[$category['name']] = $db->lastInsertId();
    }
    
    // Crear productos basados en las imágenes disponibles
    $products = [
        // Gorras
        [
            'name' => 'Gorra Western Clásica',
            'description' => 'Gorra estilo western con diseño clásico y ajuste cómodo',
            'price' => 450.00,
            'category' => 'Gorras',
            'stock' => 25,
            'images' => ['Gorra.JPG', 'gorra 2.JPG']
        ],
        [
            'name' => 'Gorra Western Premium',
            'description' => 'Gorra premium con bordados especiales y materiales de alta calidad',
            'price' => 650.00,
            'category' => 'Gorras',
            'stock' => 15,
            'images' => ['Gorra 3.JPG', 'gorra 4.JPG']
        ],
        [
            'name' => 'Gorra Western Sport',
            'description' => 'Gorra deportiva con estilo western para uso diario',
            'price' => 380.00,
            'category' => 'Gorras',
            'stock' => 30,
            'images' => ['Gorra 5.JPG', 'gorra 6.JPG']
        ],
        [
            'name' => 'Gorra Western Deluxe',
            'description' => 'Gorra de lujo con detalles únicos y acabados especiales',
            'price' => 750.00,
            'category' => 'Gorras',
            'stock' => 12,
            'images' => ['gorra 7.JPG', 'gorra 8.JPG']
        ],
        [
            'name' => 'Gorra Western Limited',
            'description' => 'Edición limitada con diseño exclusivo',
            'price' => 850.00,
            'category' => 'Gorras',
            'stock' => 8,
            'images' => ['Gorra 9.JPG', 'Gorra 10.JPG']
        ],
        
        // Conjuntos
        [
            'name' => 'Conjunto Cowboy Skull',
            'description' => 'Conjunto completo con diseño de calavera cowboy, incluye camisa y accesorios',
            'price' => 1250.00,
            'category' => 'Conjuntos',
            'stock' => 10,
            'images' => ['Conjunto Cowboy Skull.JPG', 'Conjunto Cowboy Skull 2.JPG']
        ],
        [
            'name' => 'Conjunto Rodeo Clown',
            'description' => 'Conjunto temático de rodeo con estilo único y divertido',
            'price' => 1150.00,
            'category' => 'Conjuntos',
            'stock' => 8,
            'images' => ['Rodeo Clown Conjuntio.JPG', 'Conjunto Rodeo Clown 2.JPG']
        ],
        [
            'name' => 'Conjunto CowGirl',
            'description' => 'Conjunto femenino estilo cowgirl con diseño elegante',
            'price' => 1350.00,
            'category' => 'Conjuntos',
            'stock' => 12,
            'images' => ['Conjunto CowGirl.JPG']
        ],
        [
            'name' => 'Conjunto Charolais',
            'description' => 'Conjunto exclusivo de la marca Charolais con diseño premium',
            'price' => 1450.00,
            'category' => 'Conjuntos',
            'stock' => 6,
            'images' => ['Charolais conjunto.JPG']
        ],
        
        // Boutique
        [
            'name' => 'Boutique Unitalla Clásica',
            'description' => 'Prenda boutique unitalla con estilo western elegante',
            'price' => 890.00,
            'category' => 'Boutique',
            'stock' => 15,
            'images' => ['Boutique unitalla 1.JPG', 'Boutique mujer unitalla.JPG']
        ],
        [
            'name' => 'Boutique Unitalla Premium',
            'description' => 'Prenda boutique premium con detalles únicos',
            'price' => 1050.00,
            'category' => 'Boutique',
            'stock' => 10,
            'images' => ['Boutique unitalla 3.JPG', 'Boutique Unitalla 4.JPG']
        ],
        [
            'name' => 'Nueva Colección Boutique',
            'description' => 'Lo último en moda western boutique',
            'price' => 1150.00,
            'category' => 'Boutique',
            'stock' => 8,
            'images' => ['Nueca Colección.JPG']
        ],
        
        // Camisetas individuales
        [
            'name' => 'Camiseta Cowboy Skull',
            'description' => 'Camiseta con diseño de calavera cowboy en color negro',
            'price' => 450.00,
            'category' => 'Boutique',
            'stock' => 20,
            'images' => ['Cowboy Skull.JPG', 'Cowboy Skull blanca.JPG']
        ],
        [
            'name' => 'Camiseta CowGirls',
            'description' => 'Camiseta femenina con diseño cowgirl',
            'price' => 420.00,
            'category' => 'Boutique',
            'stock' => 18,
            'images' => ['CowGirls.JPG']
        ],
        [
            'name' => 'Camiseta Bronc Riding',
            'description' => 'Camiseta con diseño de jinete de bronco',
            'price' => 480.00,
            'category' => 'Boutique',
            'stock' => 16,
            'images' => ['Bronc Riding.JPG', 'Bronc Riding 1.JPG']
        ],
        [
            'name' => 'Camiseta Rodeo Clown',
            'description' => 'Camiseta con diseño de payaso de rodeo',
            'price' => 460.00,
            'category' => 'Boutique',
            'stock' => 14,
            'images' => ['Rodeo Clown.JPG', 'Rodeo Clown 1.JPG']
        ],
        [
            'name' => 'Camiseta All Around',
            'description' => 'Camiseta versátil para todo uso con estilo western',
            'price' => 520.00,
            'category' => 'Boutique',
            'stock' => 22,
            'images' => ['all arround.JPG', 'all arround blanca.JPG']
        ],
        [
            'name' => 'Camiseta Wild Stampede',
            'description' => 'Camiseta con diseño de estampida salvaje',
            'price' => 550.00,
            'category' => 'Boutique',
            'stock' => 12,
            'images' => ['Wild Stampede.JPG']
        ],
        [
            'name' => 'Camiseta Rodeo Ink',
            'description' => 'Camiseta con diseño artístico de rodeo',
            'price' => 580.00,
            'category' => 'Boutique',
            'stock' => 10,
            'images' => ['Rodeo Ink.JPG']
        ],
        
        // Accesorios
        [
            'name' => 'Accesorios Western Set 1',
            'description' => 'Set de accesorios western básicos',
            'price' => 320.00,
            'category' => 'Accesorios',
            'stock' => 25,
            'images' => ['Accesorios.JPG']
        ],
        [
            'name' => 'Accesorios Western Set 2',
            'description' => 'Set de accesorios western premium',
            'price' => 450.00,
            'category' => 'Accesorios',
            'stock' => 18,
            'images' => ['Accesorios 2.JPG']
        ]
    ];
    
    // Insertar productos
    foreach ($products as $product) {
        $categoryId = $categoryIds[$product['category']] ?? null;
        
        $db->insert("INSERT INTO products (name, description, price, category_id, stock_quantity, is_active) VALUES (?, ?, ?, ?, ?, 1)", 
                   [$product['name'], $product['description'], $product['price'], $categoryId, $product['stock']]);
        
        $productId = $db->lastInsertId();
        
        // Agregar imágenes del producto
        foreach ($product['images'] as $index => $imageName) {
            $db->insert("INSERT INTO product_images (product_id, image_url, sort_order) VALUES (?, ?, ?)", 
                       [$productId, $imageName, $index]);
        }
        
        // Agregar variantes de color para algunos productos
        if (in_array($product['category'], ['Boutique', 'Conjuntos'])) {
            $colors = ['Negro', 'Blanco', 'Azul', 'Rojo'];
            foreach ($colors as $index => $color) {
                if ($index < 2) { // Solo agregar 2 variantes por producto
                    $db->insert("INSERT INTO product_variants (product_id, variant_name, stock_quantity, is_active, sort_order) VALUES (?, ?, ?, 1, ?)", 
                               [$productId, $color, rand(5, 15), $index]);
                }
            }
        }
    }
    
    echo "✅ Datos de ejemplo agregados exitosamente!\n\n";
    echo "📊 Resumen:\n";
    echo "- " . count($categories) . " categorías creadas\n";
    echo "- " . count($products) . " productos agregados\n";
    echo "- Imágenes y variantes configuradas\n\n";
    echo "🎯 Próximos pasos:\n";
    echo "1. Subir las imágenes a la carpeta uploads/\n";
    echo "2. Configurar Stripe en el panel admin\n";
    echo "3. Probar la tienda\n\n";
    echo "🔗 Panel Admin: https://tudominio.com/admin/\n";
    echo "🔗 Tienda: https://tudominio.com/\n";
    
} catch (Exception $e) {
    echo "❌ Error al agregar datos de ejemplo: " . $e->getMessage() . "\n";
}
?> 